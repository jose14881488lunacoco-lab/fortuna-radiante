// Ejecuta Gradle dentro de android/ en Windows, macOS o Linux.
const { execSync } = require('child_process'), path = require('path');
const task = process.argv.slice(2).join(' ') || 'assembleDebug';
// Firma fija: todos los APK salen con la misma llave, así se instalan encima de la versión anterior.
const fs = require('fs'), os = require('os');
const ks = path.join(__dirname, '..', 'fortuna-debug.keystore');
if (fs.existsSync(ks)) { const d = path.join(os.homedir(), '.android'); fs.mkdirSync(d, { recursive: true }); fs.copyFileSync(ks, path.join(d, 'debug.keystore')); console.log('Usando la llave fija de Fortuna Radiante.'); }
const cmd = process.platform === 'win32' ? `gradlew.bat ${task}` : `./gradlew ${task}`;
execSync(cmd, { cwd: path.join(__dirname, '..', 'android'), stdio: 'inherit' });
console.log('\nAPK listo en android/app/build/outputs/apk/debug/app-debug.apk');
