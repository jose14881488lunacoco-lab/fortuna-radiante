// Ejecuta Gradle dentro de android/ en Windows, macOS o Linux.
const { execSync } = require('child_process'), path = require('path');
const task = process.argv.slice(2).join(' ') || 'assembleDebug';
const cmd = process.platform === 'win32' ? `gradlew.bat ${task}` : `./gradlew ${task}`;
execSync(cmd, { cwd: path.join(__dirname, '..', 'android'), stdio: 'inherit' });
console.log('\nAPK listo en android/app/build/outputs/apk/debug/app-debug.apk');
