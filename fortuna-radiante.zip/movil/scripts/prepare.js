// Prepara la app nativa: copia la app web, apunta al servidor y genera iconos y pantalla de inicio.
// Uso: node scripts/prepare.js web | android | ios
// La dirección del servidor se toma de la variable FR_API_URL (p. ej. https://app.tudominio.com).
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const platform = process.argv[2] || 'web';
const root = path.join(__dirname, '..'), src = path.join(root, '..', 'server', 'public'), dst = path.join(root, 'www');
const run = cmd => { console.log('> ' + cmd); execSync(cmd, { cwd: root, stdio: 'inherit' }); };

fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(src, dst, { recursive: true, filter: f => !f.endsWith('sw.js') });
const api = (process.env.FR_API_URL || '').trim().replace(/\/$/, '');
if (api && !/^https:\/\//.test(api)) { console.error('FR_API_URL debe empezar por https://'); process.exit(1); }
fs.writeFileSync(path.join(dst, 'config.js'), `window.FR_API = ${JSON.stringify(api)};\n`);
console.log(api ? `Servidor: ${api}` : 'Sin FR_API_URL: la app funcionará en modo demo (datos simulados).');
if (platform === 'web') process.exit(0);

if (!fs.existsSync(path.join(root, platform))) run(`npx cap add ${platform}`);
run(`npx capacitor-assets generate --${platform} --iconBackgroundColor "#080705" --splashBackgroundColor "#000000" --splashBackgroundColorDark "#000000"`);
run(`npx cap sync ${platform}`);
