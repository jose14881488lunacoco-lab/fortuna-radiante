// Prepara la app nativa: copia la app web, apunta al servidor y pone iconos y pantalla de inicio.
// Uso: node scripts/prepare.js web | android | ios
// La dirección del servidor se toma de la variable FR_API_URL (p. ej. https://app.tudominio.com).
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const platform = process.argv[2] || 'web';
const root = path.join(__dirname, '..'), src = path.join(root, '..', 'server', 'public'), dst = path.join(root, 'www');
const run = cmd => { console.log('\n> ' + cmd); execSync(cmd, { cwd: root, stdio: 'inherit' }); };

if (!fs.existsSync(src)) { console.error(`No encuentro la app web en ${src}. La carpeta "server" tiene que estar junto a "movil".`); process.exit(1); }
fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(src, dst, { recursive: true, filter: f => !f.endsWith('sw.js') });
const api = (process.env.FR_API_URL || '').trim().replace(/\/$/, '');
if (api && !/^https:\/\//.test(api)) { console.error('FR_API_URL debe empezar por https://'); process.exit(1); }
fs.writeFileSync(path.join(dst, 'config.js'), `window.FR_API = ${JSON.stringify(api)};\nwindow.FR_SUPABASE_URL = ${JSON.stringify(process.env.FR_SUPABASE_URL || '')};\nwindow.FR_SUPABASE_KEY = ${JSON.stringify(process.env.FR_SUPABASE_KEY || '')};\n`);
console.log(api ? `Servidor: ${api}` : 'Sin FR_API_URL: la app funcionará en modo demo (datos simulados).');

// App "siempre al día": si hay FR_WEB_URL, la app nativa abre la web publicada (GitHub Pages)
// y cualquier cambio que subas llega solo, sin reinstalar. Sin conexión muestra offline.html.
const web = (process.env.FR_WEB_URL || '').trim();
const cfgPath = path.join(root, 'capacitor.config.json'), cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
if (web && /^https:\/\//.test(web)) {
  cfg.server = { url: web, errorPath: 'offline.html' };
  console.log(`La app abrirá ${web} (se actualiza sola).`);
} else delete cfg.server;
fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2) + '\n');
fs.writeFileSync(path.join(dst, 'offline.html'), `<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>Sin conexión</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#070605;color:#f7f0e1;font:17px/1.5 system-ui,sans-serif;text-align:center;padding:24px}
img{width:140px;filter:drop-shadow(0 0 18px rgba(245,200,76,.5))}h1{font-size:22px;color:#f2c14e;margin:16px 0 6px}p{color:#b0a690;margin:0 0 20px}
button{font:600 17px system-ui;border:0;border-radius:14px;padding:14px 28px;background:linear-gradient(135deg,#fff3b8,#f7cf55 30%,#d9a21b 62%,#9a6a06);color:#2b1d00}</style></head>
<body><div><img src="icons/logo-512.png" alt=""><h1>Sin conexión</h1><p>Fortuna Radiante necesita internet para mostrar los mercados.</p>
<button onclick="location.href=${JSON.stringify(web || 'index.html')}">Reintentar</button></div></body></html>`);

if (platform === 'web') process.exit(0);

if (!fs.existsSync(path.join(root, platform))) run(`npx cap add ${platform}`);

if (platform === 'android') {
  // Iconos y pantallas de inicio ya generados en res-android: se copian encima de los de Capacitor.
  const res = path.join(root, 'android', 'app', 'src', 'main', 'res');
  fs.cpSync(path.join(root, 'res-android'), res, { recursive: true });
  // El icono adaptable usa el fondo negro de values/ic_launcher_background.xml
  console.log('Iconos y pantalla de inicio de Fortuna Radiante copiados.');
  // Micrófono para los audios del chat
  const man = path.join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
  let mx = fs.readFileSync(man, 'utf8');
  for (const perm of ['android.permission.RECORD_AUDIO', 'android.permission.MODIFY_AUDIO_SETTINGS']) if (!mx.includes(perm)) mx = mx.replace('</manifest>', `    <uses-permission android:name="${perm}" />\n</manifest>`);
  fs.writeFileSync(man, mx);
} else {
  try { run(`npx capacitor-assets generate --ios --iconBackgroundColor "#080705" --splashBackgroundColor "#000000" --splashBackgroundColorDark "#000000"`); }
  catch (e) { console.warn('Aviso: no se pudieron generar los iconos de iPhone; se usarán los de por defecto.'); }
}
run(`npx cap sync ${platform}`);
