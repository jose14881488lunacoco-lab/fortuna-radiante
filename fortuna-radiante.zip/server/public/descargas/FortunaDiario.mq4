﻿//+------------------------------------------------------------------+
//| FortunaDiario.mq4                                                  |
//| Envía tus operaciones cerradas, el balance y la equidad al        |
//| Diario de la app Fortuna Radiante. No abre ni cierra operaciones. |
//+------------------------------------------------------------------+
#property copyright "Fortuna Radiante"
#property version   "1.00"
#property description "Conecta tu cuenta con el Diario de Fortuna Radiante. Solo lee; no opera."
#property strict

input string InpToken = "";       // Tu clave del diario (app: Diario > Conectar MT)
input int    InpDays  = 90;       // Días de historia la primera vez
input string InpUrl   = "https://pobyitzghvmnwrvaqrzy.supabase.co";   // Dirección de Supabase
input string InpKey   = "sb_publishable_nzWv0gwD-jee_LgKwNt5CA_YOuSAafo";   // Clave pública de Supabase

string   status = "", lastLogged = "";
datetime syncFrom = 0;
datetime lastRun = 0;

long goodOff = 0; bool haveOff = false;
long Off()
  {
   long d = (long)MathRound((double)(TimeCurrent() - TimeGMT()) / 1800.0) * 1800;
   if(MathAbs((double)d) <= 14 * 3600) { goodOff = d; haveOff = true; }
   return haveOff ? goodOff : 7200;
  }

bool Post(string body, string &resp)
  {
   char data[], res[];
   string rh;
   int len = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   ArrayResize(data, len - 1);
   string h = "Content-Type: application/json\r\napikey: " + InpKey + "\r\n";
   ResetLastError();
   int code = WebRequest("POST", InpUrl + "/rest/v1/rpc/push_trades", h, 10000, data, res, rh);
   resp = CharArrayToString(res, 0, WHOLE_ARRAY, CP_UTF8);
   if(code == -1)
     {
      int e = GetLastError();
      if(e == 4014 || e == 4060) status = "FALTA PERMISO: Herramientas > Opciones > Asesores Expertos > Permitir WebRequest > añade " + InpUrl;
      else status = "Sin conexión (error " + IntegerToString(e) + ")";
      return false;
     }
   if(code >= 300)
     {
      if(StringFind(resp, "Clave del diario incorrecta") >= 0) status = "CLAVE INCORRECTA: cópiala otra vez desde la app (Diario > Conectar MT)";
      else status = "Supabase respondió " + IntegerToString(code) + ": " + StringSubstr(resp, 0, 160);
      return false;
     }
   return true;
  }

string Esc(string s) { StringReplace(s, "\\", "\\\\"); StringReplace(s, "\"", "\\\""); return s; }
string N(double v, int d) { return DoubleToString(v, d); }

void Show()
  {
   Comment("FORTUNA RADIANTE · DIARIO\n", status, "\nCuenta ", IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)), " · último intento ", TimeToString(TimeLocal(), TIME_MINUTES));
   if(status != lastLogged) { Print("FORTUNA DIARIO - ", status); lastLogged = status; }
  }

string Head()
  {
   return "{\"p_token\":\"" + Esc(InpToken) + "\",\"p_account\":\"" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) +
          "\",\"p_server\":\"" + Esc(AccountInfoString(ACCOUNT_SERVER)) + "\",\"p_balance\":" + N(AccountInfoDouble(ACCOUNT_BALANCE), 2) +
          ",\"p_equity\":" + N(AccountInfoDouble(ACCOUNT_EQUITY), 2) + ",\"p_currency\":\"" + Esc(AccountInfoString(ACCOUNT_CURRENCY)) + "\",\"p_deals\":[";
  }

int OnInit()
  {
   if(StringLen(InpToken) < 10) { status = "FALTA TU CLAVE: cópiala de la app (Diario > Conectar MT) y pégala en «Tu clave del diario»"; Show(); }
   else status = "Conectando...";
   syncFrom = TimeCurrent() - InpDays * 86400;
   EventSetTimer(5);
   return(INIT_SUCCEEDED);
  }
void OnDeinit(const int reason) { EventKillTimer(); Comment(""); }

void OnTimer()
  {
   if(StringLen(InpToken) < 10) return;
   if(TimeLocal() - lastRun < 55 && status != "Conectando...") return;
   lastRun = TimeLocal();
   long off = Off();
   int n = OrdersHistoryTotal(), cnt = 0;
   string s = "";
   for(int i = 0; i < n && cnt < 300; i++)
     {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      int type = OrderType();
      if(type != OP_BUY && type != OP_SELL) continue;
      if(OrderCloseTime() < syncFrom) continue;
      string sym = OrderSymbol();
      int dg = (int)MarketInfo(sym, MODE_DIGITS); if(dg <= 0) dg = 5;
      if(s != "") s += ",";
      s += "{\"k\":" + IntegerToString(OrderTicket()) + ",\"s\":\"" + Esc(sym) + "\",\"d\":\"" + (type == OP_BUY ? "buy" : "sell") + "\",\"v\":" + N(OrderLots(), 2) +
           ",\"ot\":" + IntegerToString((long)OrderOpenTime() - off) + ",\"ct\":" + IntegerToString((long)OrderCloseTime() - off) + ",\"op\":" + N(OrderOpenPrice(), dg) + ",\"cp\":" + N(OrderClosePrice(), dg) +
           ",\"sl\":" + N(OrderStopLoss(), dg) + ",\"tp\":" + N(OrderTakeProfit(), dg) + ",\"p\":" + N(OrderProfit() + OrderSwap() + OrderCommission(), 2) + "}";
      cnt++;
     }
   string resp;
   if(Post(Head() + s + "]}", resp))
     {
      if(cnt >= 300) { syncFrom = syncFrom + 7 * 86400; status = "Enviando historial..."; lastRun = 0; }
      else { syncFrom = TimeCurrent() - 2 * 86400; status = "Diario conectado ✓ (" + IntegerToString(cnt) + " operaciones revisadas)"; }
     }
   Show();
  }
