﻿//+------------------------------------------------------------------+
//| FortunaDiario.mq5                                                  |
//| Envía tus operaciones cerradas, el balance y la equidad al        |
//| Diario de la app Fortuna Radiante. No abre ni cierra operaciones. |
//+------------------------------------------------------------------+
#property copyright "Fortuna Radiante"
#property version   "1.00"
#property description "Conecta tu cuenta con el Diario de Fortuna Radiante. Solo lee; no opera."


input string InpToken = "";       // Tu clave del diario (app: Diario > Conectar MT)
input int    InpDays  = 90;       // Días de historia la primera vez
input string InpUrl   = "https://pobyitzghvmnwrvaqrzy.supabase.co";   // Dirección de Supabase
input string InpKey   = "sb_publishable_nzWv0gwD-jee_LgKwNt5CA_YOuSAafo";   // Clave pública de Supabase

string   status = "", lastLogged = "";
datetime syncFrom = 0;
datetime lastRun = 0;

long Off() { return (long)MathRound((double)(TimeTradeServer() - TimeGMT()) / 1800.0) * 1800; }

bool Post(string body, string &resp)
  {
   char data[], res[];
   string rh;
   int len = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   ArrayResize(data, len - 1);
   string h = "Content-Type: application/json\r\napikey: " + InpKey + "\r\n";
   ResetLastError();
   int code = WebRequest("POST", InpUrl + "/rest/v1/rpc/push_trades", h, 10000, data, res, rh);
   resp = CharArrayToString(res, 0, WHOLE_ARRAY, CP_UTF8);
   if(code == -1)
     {
      int e = GetLastError();
      if(e == 4014 || e == 4060) status = "FALTA PERMISO: Herramientas > Opciones > Asesores Expertos > Permitir WebRequest > añade " + InpUrl;
      else status = "Sin conexión (error " + IntegerToString(e) + ")";
      return false;
     }
   if(code >= 300)
     {
      if(StringFind(resp, "Clave del diario incorrecta") >= 0) status = "CLAVE INCORRECTA: cópiala otra vez desde la app (Diario > Conectar MT)";
      else status = "Supabase respondió " + IntegerToString(code) + ": " + StringSubstr(resp, 0, 160);
      return false;
     }
   return true;
  }

string Esc(string s) { StringReplace(s, "\\", "\\\\"); StringReplace(s, "\"", "\\\""); return s; }
string N(double v, int d) { return DoubleToString(v, d); }

void Show()
  {
   Comment("FORTUNA RADIANTE · DIARIO\n", status, "\nCuenta ", IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)), " · último intento ", TimeToString(TimeLocal(), TIME_MINUTES));
   if(status != lastLogged) { Print("FORTUNA DIARIO - ", status); lastLogged = status; }
  }

string Head()
  {
   return "{\"p_token\":\"" + Esc(InpToken) + "\",\"p_account\":\"" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) +
          "\",\"p_server\":\"" + Esc(AccountInfoString(ACCOUNT_SERVER)) + "\",\"p_balance\":" + N(AccountInfoDouble(ACCOUNT_BALANCE), 2) +
          ",\"p_equity\":" + N(AccountInfoDouble(ACCOUNT_EQUITY), 2) + ",\"p_currency\":\"" + Esc(AccountInfoString(ACCOUNT_CURRENCY)) + "\",\"p_deals\":[";
  }

int OnInit()
  {
   if(StringLen(InpToken) < 10) { status = "FALTA TU CLAVE: cópiala de la app (Diario > Conectar MT) y pégala en «Tu clave del diario»"; Show(); }
   else status = "Conectando...";
   syncFrom = TimeCurrent() - InpDays * 86400;
   EventSetTimer(5);
   return(INIT_SUCCEEDED);
  }
void OnDeinit(const int reason) { EventKillTimer(); Comment(""); }

void OnTimer()
  {
   if(StringLen(InpToken) < 10) return;
   if(TimeLocal() - lastRun < 55 && status != "Conectando...") return;
   lastRun = TimeLocal();
   long off = Off();
   if(!HistorySelect(syncFrom - 30 * 86400, TimeCurrent() + 86400)) { status = "No se pudo leer el historial"; Show(); return; }
   int n = HistoryDealsTotal(), cnt = 0;
   string s = "";
   datetime lastCt = syncFrom;
   for(int i = 0; i < n && cnt < 300; i++)
     {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      long entry = HistoryDealGetInteger(d, DEAL_ENTRY);
      if(entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_OUT_BY && entry != DEAL_ENTRY_INOUT) continue;
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(type != DEAL_TYPE_BUY && type != DEAL_TYPE_SELL) continue;
      datetime ct = (datetime)HistoryDealGetInteger(d, DEAL_TIME);
      if(ct < syncFrom) continue;
      long pos = HistoryDealGetInteger(d, DEAL_POSITION_ID);
      string sym = HistoryDealGetString(d, DEAL_SYMBOL);
      int dg = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS); if(dg <= 0) dg = 5;
      double profit = HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_SWAP) + HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE);
      double op = 0; datetime ot = 0;
      for(int k = 0; k < n; k++)
        {
         ulong e = HistoryDealGetTicket(k);
         if(HistoryDealGetInteger(e, DEAL_POSITION_ID) == pos && HistoryDealGetInteger(e, DEAL_ENTRY) == DEAL_ENTRY_IN)
           { op = HistoryDealGetDouble(e, DEAL_PRICE); ot = (datetime)HistoryDealGetInteger(e, DEAL_TIME); profit += HistoryDealGetDouble(e, DEAL_COMMISSION); break; }
        }
      if(ot == 0) ot = ct;
      string side = (type == DEAL_TYPE_SELL) ? "buy" : "sell";   // el cierre va al revés que la posición
      if(s != "") s += ",";
      s += "{\"k\":" + IntegerToString((long)d) + ",\"s\":\"" + Esc(sym) + "\",\"d\":\"" + side + "\",\"v\":" + N(HistoryDealGetDouble(d, DEAL_VOLUME), 2) +
           ",\"ot\":" + IntegerToString((long)ot - off) + ",\"ct\":" + IntegerToString((long)ct - off) + ",\"op\":" + N(op, dg) + ",\"cp\":" + N(HistoryDealGetDouble(d, DEAL_PRICE), dg) +
           ",\"sl\":" + N(HistoryDealGetDouble(d, DEAL_SL), dg) + ",\"tp\":" + N(HistoryDealGetDouble(d, DEAL_TP), dg) + ",\"p\":" + N(profit, 2) + "}";
      cnt++; lastCt = ct;
     }
   string resp;
   if(Post(Head() + s + "]}", resp))
     {
      if(cnt >= 300) { syncFrom = lastCt; status = "Enviando historial..."; lastRun = 0; }
      else { syncFrom = TimeCurrent() - 2 * 86400; status = "Diario conectado ✓ (" + IntegerToString(cnt) + " operaciones revisadas)"; }
     }
   Show();
  }
