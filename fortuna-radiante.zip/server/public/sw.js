// Service worker: la app abre al instante y funciona sin conexión (los datos de /api siempre van a la red).
const CACHE = 'fortuna-v3';
const SHELL = ['./', 'index.html', 'styles.css', 'app.js', 'chart.js', 'config.js', 'manifest.webmanifest', 'icons/logo-96.png', 'icons/logo-192.png', 'icons/logo-512.png', 'icons/splash.jpg', 'icons/icon-192.png', 'icons/icon-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.pathname.startsWith('/api/') || u.origin !== location.origin) return;
  e.respondWith(fetch(e.request).then(r => { const copy = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); return r; }).catch(() => caches.match(e.request).then(r => r || caches.match('index.html'))));
});
