// Configuración de Fortuna Radiante. En GitHub la rellena el proceso de publicación con tus variables.
window.FR_API = '';            // servidor propio (precios reales, Fortunaty con noticias, liga)
window.FR_SUPABASE_URL = '';   // comunidad: registro, miembros y chat (Supabase → Project URL)
window.FR_SUPABASE_KEY = '';   // comunidad: clave pública "anon" de Supabase
