// Configuración de Fortuna Radiante. Las variables de GitHub, si existen, sustituyen estos valores al publicar.
window.FR_API = '';            // servidor propio (precios reales, Fortunaty con noticias, liga)
window.FR_SUPABASE_URL = 'https://pobyitzghvmnwrvaqrzy.supabase.co';   // comunidad (Supabase → Project URL)
window.FR_SUPABASE_KEY = 'sb_publishable_nzWv0gwD-jee_LgKwNt5CA_YOuSAafo';   // clave pública (publishable)
window.FR_VAPID_PUBLIC = 'BAvgqwb1vxhAFBQt9n72YFA2zYPDheLr2XUTXEkKBzHR6ArFIi_ooFF6CbwQf5lVmakEW-BeRPwZ727kQJPdtR4';   // clave pública de notificaciones (no es secreta)
