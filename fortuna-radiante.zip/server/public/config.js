// Dirección del servidor de Fortuna Radiante.
// Vacía = el mismo servidor que sirve la app (web). En la app de Android/iPhone la rellena el script de compilación.
window.FR_API = '';
