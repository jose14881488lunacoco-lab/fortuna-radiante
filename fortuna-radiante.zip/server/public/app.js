// Fortuna Radiante — app móvil para traders.
// Sin servidor: modo demo (precios simulados; Fortunaty usa la IA de la vista previa si está disponible).
// Servida por server.js: precios reales, Fortunaty con noticias, chat, liga y mentorías compartidos.
{
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = s => parseFloat(String(s ?? '').replace(/\s/g, '').replace(',', '.'));
const dec = (n, d = 2) => Number(n).toLocaleString('es-ES', { minimumFractionDigits: d, maximumFractionDigits: d });
const sg = (n, d = 2) => (n > 0 ? '+' : n < 0 ? '−' : '') + dec(Math.abs(n), d);
const usd = n => (n < 0 ? '−' : '') + dec(Math.abs(n)) + ' $';
const hm = t => new Date(t).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
const r2 = (n, d = 2) => n == null || !isFinite(n) ? null : Math.round(n * 10 ** d) / 10 ** d;
const wait = ms => new Promise(r => setTimeout(r, ms));
const LS = { get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }, del(k) { try { localStorage.removeItem(k); } catch (e) {} } };
let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;

let LIVE = false, FEAT = {}, token = LS.get('fr.token'), user = LS.get('fr.user'), view = 'inicio';
// En la app instalada (Android/iPhone) las llamadas van al servidor indicado en config.js
const API = String(window.FR_API || '').replace(/\/$/, '');
async function api(path, opt = {}) {
  const r = await fetch(API + path, { ...opt, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: opt.body ? JSON.stringify(opt.body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Error ' + r.status);
  return j;
}
function toast(t) { $('#toasts').innerHTML = ''; const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; $('#toasts').append(d); setTimeout(() => d.remove(), 3000); }
function setUser(u, t) { user = u || null; if (t !== undefined) token = t || null; u ? LS.set('fr.user', u) : LS.del('fr.user'); token ? LS.set('fr.token', token) : LS.del('fr.token'); $('#mebtn').innerHTML = u ? avHTML(u, 38) : '?'; }

// =============== navegación ===============
const TAB = { inicio: 'inicio', grafico: 'grafico', fortunaty: 'fortunaty', comunidad: 'comunidad', mas: 'mas', mentorias: 'mas', utiles: 'mas', diario: 'mas', cuenta: 'mas', instalar: 'mas', avisos: 'mas' };
const RENDER = {};
function show(v) {
  if (!TAB[v]) v = 'inicio';
  view = v;
  $$('.view').forEach(s => s.hidden = s.id !== 'v-' + v);
  $$('.tabbar a').forEach(a => a.dataset.t === TAB[v] ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'));
  if (v !== 'grafico') $('#app').classList.remove('full');
  $('#main').scrollTop = 0;
  RENDER[v] && RENDER[v]();
  if (location.hash !== '#' + v) try { history.replaceState(null, '', '#' + v); } catch (e) {}
}
addEventListener('hashchange', () => { const h = location.hash.slice(1); if (h && h !== view) show(h); });
document.addEventListener('click', e => {
  const g = e.target.closest('[data-go]'); if (g) { e.preventDefault(); show(g.dataset.go); return; }
  const c = e.target.closest('[data-chart]'); if (c) { e.preventDefault(); openChart(c.dataset.chart); return; }
  const a = e.target.closest('[data-ask]'); if (a) { e.preventDefault(); show('fortunaty'); ask(a.dataset.ask); return; }
  const t = e.target.closest('[data-tab]'); if (t) { comTab = t.dataset.tab; }
});

// hoja inferior
function sheet(title, html, bind) { $('#sheet-t').textContent = title; $('#sheet-c').innerHTML = html; $('#sheet').hidden = $('#sheet-bg').hidden = false; bind && bind($('#sheet-c')); }
function closeSheet() { $('#sheet').hidden = $('#sheet-bg').hidden = true; }
$('#sheet-bg').onclick = closeSheet;
addEventListener('keydown', e => { if (e.key === 'Escape') closeSheet(); });

// =============== mercados ===============
const SY = {
  XAUUSD: { n: 'Oro', d: 2, p: 4000, v: .00035, ic: 'Au', cls: '' },
  DXY: { n: 'Índice dólar', d: 3, p: 100.2, v: .00007, ic: 'DXY', cls: 'dxy' },
  BTCUSD: { n: 'Bitcoin', d: 1, p: 95000, v: .0009, ic: '₿', cls: 'btc' },
  USOIL: { n: 'Petróleo WTI', d: 2, p: 65, v: .0005, ic: 'WTI', cls: 'oil' },
};
const ORDER = Object.keys(SY);
const TFS = [['1m', 1], ['5m', 5], ['15m', 15], ['1H', 60], ['4H', 240], ['1D', 1440]];
const tfLabel = m => (TFS.find(t => t[1] === m) || ['1H'])[0];
const apiTf = m => ({ 1: '1m', 5: '5m', 15: '15m', 60: '1h', 240: '4h', 1440: '1d' }[m]);
const px = {}, ref = {}, series = {};
// ---------- precios reales de Vantage: el robot de MT5 los guarda en Supabase y la app los lee ----------
const FEED = { real: new Set(), fresh: false, ts: {}, pending: {} };
const isReal = s => FEED.real.has(s);
let ALERTS = [];
function afterRealData(s) {
  const a = series[s + '|15']; if (a && a.length) ref[s] = a[Math.max(0, a.length - 97)].close;
  if (view === 'inicio') { renderHero(); renderMarkets(); renderPulse(); }
}
function checkAlerts(s) {
  const p = px[s]; if (p == null) return;
  for (const al of ALERTS) {
    if (!al.active || al.symbol !== s) continue;
    if ((al.above && p >= al.price) || (!al.above && p <= al.price)) {
      al.active = false; al.triggered_at = new Date().toISOString();
      toast(`🔔 ${s} ${al.above ? 'ha subido a' : 'ha bajado a'} ${dec(al.price, SY[s].d)}`);
      if (navigator.vibrate) try { navigator.vibrate([60, 40, 60]); } catch (e) {}
      if (comm.mode === 'demo') LS.set('fr.alerts', ALERTS);
      if (view === 'avisos') RENDER.avisos();
    }
  }
}
async function feedPoll() {
  if (comm.mode !== 'online' || !comm.prices || document.hidden) return;
  let rows; try { rows = await comm.prices(); } catch (e) { return; }
  const now = Date.now(), nuevos = []; let fresh = false;
  for (const r of rows) {
    if (!SY[r.symbol] || !(r.bid > 0)) continue;
    if (!isReal(r.symbol)) { FEED.real.add(r.symbol); nuevos.push(r.symbol); }
    if (now - new Date(r.ts).getTime() < 120e3) fresh = true;
    if (FEED.ts[r.symbol] !== r.ts || px[r.symbol] !== +r.bid) { FEED.ts[r.symbol] = r.ts; applyPrice(r.symbol, +r.bid); checkAlerts(r.symbol); }
  }
  FEED.fresh = fresh;
  $('#mode').textContent = fresh ? 'Vantage' : FEED.real.size ? 'Cerrado' : (LIVE ? 'En directo' : 'Demo');
  if (nuevos.length) {
    nuevos.forEach(s => { for (const k in series) if (k.startsWith(s + '|')) delete series[k]; delete ref[s]; });
    await Promise.all(nuevos.map(s => getSeries(s, 15)));
    nuevos.forEach(afterRealData); updTicker();
    if (view === 'grafico') loadAll(); else if (RENDER[view]) RENDER[view]();
  }
}
async function resyncCandles() {
  if (!FEED.real.size || document.hidden || !comm.candles) return;
  for (const k of Object.keys(series)) {
    const [s, m] = k.split('|'); if (!isReal(s)) continue;
    try { const rows = await comm.candles(s, +m); if (rows.length) series[k] = rows.map(r => ({ time: r.t * 1000, open: +r.o, high: +r.h, low: +r.l, close: +r.c, vol: +r.v || 0 })); } catch (e) {}
  }
}
ORDER.forEach(s => { px[s] = SY[s].p * (1 + (rnd() - .5) * .01); });
function gen(s, m, n = 500) {
  const step = m * 6e4, vol = SY[s].v * Math.sqrt(m), out = new Array(n); let c = px[s], t = Math.floor(Date.now() / step) * step, drift = 0;
  for (let i = n - 1; i >= 0; i--) {
    if ((n - 1 - i) % 45 === 0) drift = (rnd() - .5) * vol * .35;
    const o = c / (1 + drift + (rnd() - .5) * 2 * vol);
    out[i] = { time: t, open: o, high: Math.max(o, c) * (1 + rnd() * vol * .6), low: Math.min(o, c) * (1 - rnd() * vol * .6), close: c, vol: Math.round(m * 40 * (.4 + rnd() * 1.4 + Math.abs(c - o) / (o * vol || 1) * .6)) };
    c = o; t -= step;
  }
  return out;
}
function seriesSync(s, m) {
  const k = s + '|' + m;
  if (!series[k]) {
    if (isReal(s)) { if (!FEED.pending[k]) { FEED.pending[k] = 1; getSeries(s, m).then(() => { delete FEED.pending[k]; afterRealData(s); }); } return null; }
    if (!(LIVE && FEAT.candles)) series[k] = gen(s, m);
  }
  return series[k];
}
async function getSeries(s, m) {
  const k = s + '|' + m;
  if (isReal(s) && !series[k] && comm.candles) { try { const rows = await comm.candles(s, m); if (rows.length) series[k] = rows.map(r => ({ time: r.t * 1000, open: +r.o, high: +r.h, low: +r.l, close: +r.c, vol: +r.v || 0 })); } catch (e) { console.warn(e); } }
  if (LIVE && FEAT.candles && !series[k]) { try { const j = await api(`/api/candles?symbol=${s}&tf=${apiTf(m)}`); if (j.candles && j.candles.length) series[k] = j.candles.map(c => ({ time: +c.time, open: +c.open, high: +c.high, low: +c.low, close: +c.close })); } catch (e) { console.warn(e); } }
  return series[k] || (series[k] = gen(s, m));
}
function applyPrice(s, p) {
  const old = px[s]; px[s] = p;
  for (const k in series) {
    const [ks, km] = k.split('|'); if (ks !== s) continue;
    const a = series[k], step = km * 6e4, l = a[a.length - 1]; if (!l) continue;
    if (Date.now() >= l.time + step) { a.push({ time: Math.floor(Date.now() / step) * step, open: l.close, high: p, low: p, close: p, vol: 1 }); if (a.length > 1500) a.shift(); }
    else { l.close = p; l.high = Math.max(l.high, p); l.low = Math.min(l.low, p); if (l.vol != null) l.vol += 1; }
  }
  return old;
}
function initRefs() { ORDER.forEach(s => { const a = seriesSync(s, 15); if (a && a.length) ref[s] = a[Math.max(0, a.length - 97)].close; }); }
const chg = s => ref[s] ? (px[s] / ref[s] - 1) * 100 : 0;

// cinta deslizante
const track = $('#tk-track'), tk = $('#ticker');
function buildTicker() {
  const item = s => `<button class="tk" data-chart="${s}"><b>${s === 'BTCUSD' ? 'BTC' : s}</b><small class="sim" data-sim="${s}" hidden>sim</small><span class="p" data-p="${s}"></span><span class="c" data-c="${s}"></span></button>`;
  const one = ORDER.map(item).join(''); track.innerHTML = one + one + one;
  updTicker();
}
const lastShown = {};
function updTicker() {
  ORDER.forEach(s => {
    const p = px[s], c = chg(s), dir = lastShown[s] == null ? '' : p > lastShown[s] ? 'fu' : p < lastShown[s] ? 'fd' : '';
    $$(`[data-p="${s}"]`).forEach(el => { el.textContent = p == null ? '—' : dec(p, SY[s].d); if (dir) { el.classList.remove('fu', 'fd'); void el.offsetWidth; el.classList.add(dir); } });
    $$(`[data-c="${s}"]`).forEach(el => { el.textContent = (c >= 0 ? '▲ ' : '▼ ') + dec(Math.abs(c)) + ' %'; el.className = 'c ' + (c >= 0 ? 'u' : 'd'); });
    lastShown[s] = p;
    $$(`[data-sim="${s}"]`).forEach(el => el.hidden = !(FEED.real.size && !isReal(s)));
  });
}
let tkPos = 0, tkHold = 0, tkLast = 0;
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
function tkLoop(t) {
  const dt = Math.min(64, t - (tkLast || t)); tkLast = t;
  if (!reduce && Date.now() > tkHold && !$('#app').classList.contains('full')) {
    tkPos += dt * .035; const third = track.scrollWidth / 3;
    if (third && tkPos >= third * 2) tkPos -= third;
    tk.scrollLeft = tkPos;
  }
  requestAnimationFrame(tkLoop);
}
['pointerdown', 'touchstart', 'wheel'].forEach(ev => tk.addEventListener(ev, () => { tkHold = Date.now() + 3000; }, { passive: true }));
tk.addEventListener('scroll', () => { if (Date.now() <= tkHold) { tkPos = tk.scrollLeft; const third = track.scrollWidth / 3; if (tkPos < third * .5) { tkPos += third; tk.scrollLeft = tkPos; } else if (tkPos > third * 2.2) { tkPos -= third; tk.scrollLeft = tkPos; } } }, { passive: true });

// =============== INICIO ===============
function sparkPath(a, W, H, pad = 4) { const lo = Math.min(...a), hi = Math.max(...a), k = hi - lo || 1; return a.map((v, i) => `${(i / (a.length - 1) * W).toFixed(1)},${(pad + (hi - v) / k * (H - pad * 2)).toFixed(1)}`); }
function drawRays() { const g = $('#raysg'); if (!g) return; if (g.childElementCount) return; let h = ''; for (let i = 0; i < 24; i++) { const a = i / 24 * Math.PI * 2, b = a + .045; h += `<polygon points="200,200 ${200 + 260 * Math.cos(a)},${200 + 260 * Math.sin(a)} ${200 + 260 * Math.cos(b)},${200 + 260 * Math.sin(b)}" fill="url(#gg)" opacity="${i % 2 ? .25 : .5}"/>`; } g.innerHTML = h + '<circle cx="200" cy="200" r="46" fill="url(#gg)" opacity=".55"/>'; }
function renderHero() {
  const a = seriesSync('XAUUSD', 15); if (!a || !a.length) return;
  const d = a.slice(-96), c = chg('XAUUSD');
  $('#h-price').textContent = dec(px.XAUUSD, 2);
  $('.hero .eyebrow').textContent = 'Oro · XAUUSD' + (isReal('XAUUSD') ? (FEED.fresh ? ' · Vantage en directo' : ' · Vantage · mercado cerrado') : ' · demo');
  const pc = $('#h-chg'); pc.textContent = (c >= 0 ? '▲ ' : '▼ ') + dec(Math.abs(c)) + ' % hoy'; pc.className = 'pill ' + (c >= 0 ? 'u' : 'd');
  $('#h-range').textContent = `Rango 24 h ${dec(Math.min(...d.map(x => x.low)))} – ${dec(Math.max(...d.map(x => x.high)))}`;
  const sv = $('#h-spark'), W = sv.clientWidth || 340, H = 84, pts = sparkPath(d.map(x => x.close), W, H);
  sv.setAttribute('viewBox', `0 0 ${W} ${H}`);
  sv.innerHTML = `<defs><linearGradient id="hf" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f5c84c" stop-opacity=".45"/><stop offset="1" stop-color="#f5c84c" stop-opacity="0"/></linearGradient></defs><polygon points="0,${H} ${pts.join(' ')} ${W},${H}" fill="url(#hf)"/><polyline points="${pts.join(' ')}" fill="none" stroke="url(#gg)" stroke-width="2.5" stroke-linejoin="round"/><circle cx="${pts[pts.length - 1].split(',')[0]}" cy="${pts[pts.length - 1].split(',')[1]}" r="4.5" fill="#fff0b8"/>`;
}
function renderMarkets() {
  $('#markets').innerHTML = ORDER.map(s => {
    const a = (seriesSync(s, 15) || []).slice(-48), c = chg(s), pts = a.length > 1 ? sparkPath(a.map(x => x.close), 72, 32, 3) : [];
    return `<button class="mk" data-chart="${s}"><span class="ic ${SY[s].cls}">${esc(SY[s].ic)}</span><span><b>${SY[s].n}</b><small>${s}${FEED.real.size && !isReal(s) ? ' · simulado' : isReal(s) ? ' · Vantage' : ''}</small></span><svg viewBox="0 0 72 32"><polyline points="${pts.join(' ')}" fill="none" stroke="${c >= 0 ? 'var(--up)' : 'var(--dn)'}" stroke-width="1.8"/></svg><span class="r"><b>${px[s] == null ? '—' : dec(px[s], SY[s].d)}</b><span class="pill ${c >= 0 ? 'u' : 'd'}">${sg(c)} %</span></span></button>`;
  }).join('');
}
function quickRead(a) {
  if (!a) return [];
  const t = a.close > a.ema200 && a.ema50 > a.ema200 ? ['Alcista', 'u'] : a.close < a.ema200 && a.ema50 < a.ema200 ? ['Bajista', 'd'] : ['Lateral', ''];
  const res = Math.min(...[a.pivots.R1, a.swingHigh50].filter(v => v > a.close)), sup = Math.max(...[a.pivots.S1, a.swingLow50].filter(v => v < a.close));
  return [['Tendencia H1', `<b class="${t[1]}">${t[0]}</b>`], ['RSI 14', `<b>${dec(a.rsi14, 1)}</b> · ${a.rsi14 > 70 ? 'sobrecompra' : a.rsi14 < 30 ? 'sobreventa' : 'neutral'}`], ['MACD', `<b class="${a.macd > a.macdSignal ? 'u' : 'd'}">${a.macd > a.macdSignal ? 'Impulso alcista' : 'Impulso bajista'}</b>`], ['Resistencia', isFinite(res) ? `<b>${dec(res)}</b>` : '—'], ['Soporte', isFinite(sup) ? `<b>${dec(sup)}</b>` : '—']];
}
function renderPulse() { const a = FortunaChart.analyze(seriesSync('XAUUSD', 60), 36e5); $('#pulse').innerHTML = quickRead(a).map(([k, v]) => `<li><span>${k}</span><span>${v}</span></li>`).join(''); $('#pulse-src').textContent = LIVE && FEAT.candles ? 'Lectura automática del oro · datos reales' : 'Lectura automática del oro · datos simulados'; }
RENDER.inicio = () => {
  drawRays(); renderHero(); renderMarkets(); renderPulse(); sessMini();
  const all = ranked(), me = all.find(t => t.me), top = all.find(t => t.ok);
  $('#mini-liga').textContent = me ? (me.ok ? me.pos + 'º' : 'Sin clasificar') : top ? '1º ' + top.alias : '–';
  $('#mini-liga2').textContent = me ? `${sg(me.gain, 1)} % · ${me.score} pts` : 'Vincula tu cuenta y compite';
  const nx = MENT && upcoming()[0];
  $('#mini-ment').textContent = nx ? new Date(nx.start).toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric' }) + ' · ' + hm(nx.start) : '–';
  $('#mini-ment2').textContent = nx ? nx.title : '';
};

// =============== GRÁFICOS (hasta 3 a la vez) ===============
const DEF_PANES = [{ sym: 'XAUUSD', tf: 60 }, { sym: 'DXY', tf: 60 }, { sym: 'XAUUSD', tf: 15 }];
let LAY = LS.get('fr.layout') || { n: 1, panes: [] };
LAY.panes = DEF_PANES.map((p, i) => (LAY.panes && LAY.panes[i]) || { ...p });
LAY.panes.forEach(p => { if (!SY[p.sym]) p.sym = 'XAUUSD'; if (!TFS.some(t => t[1] === p.tf)) p.tf = 60; });
if (![1, 2, 3].includes(LAY.n)) LAY.n = 1;
let active = Math.min(LS.get('fr.active') || 0, LAY.n - 1), panes = [];
const saveLay = () => { LS.set('fr.layout', LAY); LS.set('fr.active', active); };
const AP = () => panes[active] || panes[0];
const TOOLS = [
  ['cursor', 'Cursor', '<path d="M6 3l13 7-6 1.8L10.5 19z"/>'],
  ['trend', 'Tendencia', '<path d="M4 19L20 5"/><circle cx="4" cy="19" r="2"/><circle cx="20" cy="5" r="2"/>'],
  ['hline', 'Horizontal', '<path d="M2 12h20"/><circle cx="12" cy="12" r="2"/>'],
  ['rect', 'Rectángulo', '<rect x="4" y="6" width="16" height="12" rx="1"/>'],
  ['fib', 'Fibonacci', '<path d="M3 5h18M3 9.5h18M3 13h18M3 19h18"/>'],
  ['measure', 'Medir', '<path d="M3 17L17 3l4 4L7 21zM7.5 12.5l2 2M10.5 9.5l2 2M13.5 6.5l2 2"/>'],
  ['magnet', 'Imán', '<path d="M6 3v8a6 6 0 0 0 12 0V3h-4v8a2 2 0 0 1-4 0V3zM6 7h4M14 7h4"/>'],
  ['clear', 'Borrar', '<path d="M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13"/>'],
];
// ---------- opciones editables de los indicadores Pine (Radiant Fortune Zones y DXY Panel) ----------
const TFOPT = [[5, 'M5'], [15, 'M15'], [60, 'H1'], [240, 'H4'], [1440, 'D1'], [10080, 'W1']];
const OPT = {
  zones: [
    ['Multi-temporalidad (HTF)'], ['htf', 'Mostrar zonas de temporalidad superior (HTF)', 'b', 'Auto: M5→H1 · M15→H4 · H1 y H4→D1 · D1→W1'], ['htfMode', 'Modo HTF', 's', [['Auto', 'Auto'], ['Manual', 'Manual']]], ['htfTf', 'HTF manual', 's', TFOPT.slice(2)], ['local', 'Mostrar zonas de la temporalidad actual', 'b'],
    ['Detección FVG / Ineficiencias'], ['fvg', 'Fair Value Gaps (FVG)', 'b'], ['vi', 'Volume Imbalance (VI) · solo temporalidad actual', 'b'], ['atrLen', 'Periodo ATR', 'i', 1, 200], ['minGap', 'Tamaño mínimo del gap (x ATR)', 'f', 0, 10, 'Se escala con el ATR: sirve igual en M5 que en W1'], ['minBody', 'Cuerpo mínimo vela central (x ATR, 0 = off)', 'f', 0, 10], ['maxLocal', 'Máx. zonas FVG por lado · TF actual', 'i', 1, 20], ['maxVi', 'Máx. zonas VI por lado · TF actual', 'i', 1, 20], ['maxHtf', 'Máx. zonas por lado · HTF', 'i', 1, 20], ['hideMit', 'Borrar zonas mitigadas', 'b'], ['mit', 'Mitigada cuando rompe por', 's', [['Cierre', 'Cierre'], ['Mecha', 'Mecha']]],
    ['Rango Premium / Descuento (respaldo)'], ['range', 'Zona de VENTA (premium) y de COMPRA (descuento) del rango', 'b'], ['rngLen', 'Velas del rango', 'i', 20, 500], ['rngPct', 'Tamaño de cada zona (% del rango)', 'f', 5, 50],
    ['Liquidez'], ['liq', 'Pools de liquidez (máximos / mínimos iguales)', 'b'], ['pivLen', 'Longitud del pivote', 'i', 2, 30], ['eqTol', 'Tolerancia de igualdad (x ATR)', 'f', .01, 5], ['maxPools', 'Máx. pools activos', 'i', 1, 30], ['pd', 'Máx / Mín del día anterior (PDH / PDL)', 'b'], ['pw', 'Máx / Mín de la semana anterior (PWH / PWL)', 'b'], ['sweepLook', 'Velas para confluencia con sweep', 'i', 1, 500],
    ['RSI'], ['rsiLen', 'Periodo RSI', 'i', 2, 200], ['ob', 'Sobrecompra', 'f', 50, 100], ['os', 'Sobreventa', 'f', 0, 50], ['rsiFilter', 'Filtrar señales: no comprar en sobrecompra / no vender en sobreventa', 'b'], ['tint', 'Colorear velas en sobrecompra / sobreventa', 'b'],
    ['Señales'], ['sig', 'Mostrar señales de retest', 'b'], ['trend', 'Solo operar a favor de la EMA', 'b'], ['emaLen', 'Periodo EMA', 'i', 1, 500], ['minScore', 'Puntuación mínima (1 a 5)', 'i', 1, 5, 'Retest (1) + zona HTF (1) + tendencia EMA (1) + RSI a favor (1) + sweep reciente (1)'],
    ['Estilo'], ['fill', 'Transparencia del relleno (0 = sólido, 100 = invisible)', 'i', 0, 100], ['border', 'Transparencia del borde', 'i', 0, 100], ['bw', 'Grosor del borde', 'i', 1, 4], ['buy', 'Color zonas de COMPRA', 'c'], ['sell', 'Color zonas de VENTA', 'c'], ['liqC', 'Color liquidez', 'c'], ['mid', 'Línea del 50% (CE) dentro de las zonas', 'b'], ['tags', 'Etiquetas laterales (ZONA DE COMPRA / VENTA / LIQUIDEZ)', 'b'],
    ['Panel'], ['panel', 'Mostrar panel', 'b'], ['pos', 'Posición', 's', ['Arriba derecha', 'Arriba izquierda', 'Abajo derecha', 'Abajo izquierda'].map(x => [x, x])], ['size', 'Tamaño', 's', ['Pequeño', 'Normal', 'Grande'].map(x => [x, x])],
    ['Avisos (con la app abierta)'], ['alSweep', 'Avisarme de sweeps de liquidez', 'b'], ['alSig', 'Avisarme de señales de COMPRA / VENTA', 'b'],
  ],
  dxy: [
    ['DXY'], ['ema', 'EMA tendencia DXY', 'i', 2, 500], ['corr', 'Ventana correlación oro/DXY', 'i', 5, 500], ['up', 'Vela alcista', 'c'], ['dn', 'Vela bajista', 'c'], ['emaCol', 'Color EMA', 'c'], ['table', 'Mostrar panel de información', 'b'],
    ['Zonas DXY'], ['cur', 'Zonas de la temporalidad actual', 'b'], ['htf', 'Zonas de temporalidad alta', 'b'], ['htfTf', 'Temporalidad alta', 's', TFOPT.slice(0, 5)], ['len', 'Fuerza del pivote (TF actual)', 'i', 2, 50], ['hlen', 'Fuerza del pivote (TF alta)', 'i', 2, 50], ['max', 'Máx. zonas por lado', 'i', 1, 20], ['minAtr', 'Ancho mínimo (x ATR)', 'f', 0, 10], ['del', 'Borrar zonas rotas', 'b'], ['buy', 'Color ZONA DE COMPRAS', 'c'], ['sell', 'Color ZONA DE VENTAS', 'c'], ['ext', 'Proyectar zonas a la derecha (velas)', 'i', 0, 200],
    ['Avisos (con la app abierta)'], ['alert', 'Avisarme cuando el DXY cruce la EMA', 'b'],
  ],
};
function optHTML(k, cur) {
  return OPT[k].map(r => {
    if (r.length === 1) return `<p class="og">${esc(r[0])}</p>`;
    const [f, l, ty, a, b, tip] = r, v = cur[f], hint = typeof a === 'string' ? a : tip, h = hint ? `<small class="sub">${esc(hint)}</small>` : '';
    if (ty === 'b') return `<div class="orow"><span>${esc(l)}${h}</span><button class="sw-t" role="switch" aria-checked="${!!v}" data-ok="${k}" data-of="${f}" data-ot="b" aria-label="${esc(l)}"></button></div>`;
    if (ty === 'c') return `<label class="orow"><span>${esc(l)}</span><input type="color" value="${esc(v)}" data-ok="${k}" data-of="${f}" data-ot="c"></label>`;
    if (ty === 's') return `<label class="orow"><span>${esc(l)}</span><select data-ok="${k}" data-of="${f}" data-ot="s">${a.map(([x, y]) => `<option value="${x}"${String(x) === String(v) ? ' selected' : ''}>${esc(y)}</option>`).join('')}</select></label>`;
    return `<label class="orow"><span>${esc(l)}${h}</span><input inputmode="decimal" value="${v}" data-ok="${k}" data-of="${f}" data-ot="${ty}" data-min="${a}" data-max="${b}"></label>`;
  }).join('');
}
function optRead(el) {
  const ty = el.dataset.ot; if (ty === 'b') return el.getAttribute('aria-checked') === 'true'; if (ty === 'c') return el.value;
  if (ty === 's') { const x = el.value; return /^\d+$/.test(x) ? +x : x; }
  let v = num(el.value); if (!isFinite(v)) return undefined; v = Math.max(+el.dataset.min, Math.min(+el.dataset.max, v)); return ty === 'i' ? Math.round(v) : v;
}
// datos extra que necesitan los indicadores (temporalidad alta, diario, DXY)
function extraFor(c, ind) {
  const ex = { sym: c.sym };
  if (ind.zones && ind.zones.on && isReal(c.sym)) {
    const z = ind.zones, h = z.htfMode === 'Auto' ? FortunaChart.autoTf(c.tf) : +z.htfTf, src = h >= 10080 ? 1440 : h;
    if (z.htf && h > c.tf && [60, 240, 1440].includes(src)) ex.htf = seriesSync(c.sym, src) || undefined;
    if ((z.pd || z.pw) && c.tf < 1440) ex.day = seriesSync(c.sym, 1440) || undefined;
  }
  if (ind.dxy && ind.dxy.on) { ex.dxy = seriesSync('DXY', c.tf) || undefined; if (isReal('DXY') && ind.dxy.htf && ind.dxy.htfTf > c.tf) ex.dxyHtf = seriesSync('DXY', ind.dxy.htfTf) || undefined; }
  return ex;
}
const EVSEEN = {};
function indEvents(pane) {
  const c = LAY.panes[pane.i];
  pane.chart.events().forEach(ev => {
    const key = c.sym + '|' + c.tf + '|' + ev.k, last = EVSEEN[key];
    EVSEEN[key] = ev.t; if (last === undefined || ev.t <= last) return; // la primera vez solo se apunta
    const title = `${c.sym} ${tfLabel(c.tf)} · ${ev.title}`; toast(title);
    try { if ('Notification' in window && Notification.permission === 'granted' && navigator.serviceWorker) navigator.serviceWorker.ready.then(r => r.showNotification(title, { body: ev.body, icon: 'icon-192.png', tag: key })); } catch (e) {}
  });
}
const COLORS = ['#f2c14e', '#3ddc97', '#ff5f5f', '#4fc3f7', '#c39bff', '#ffffff'];
function buildPanes() {
  const box = $('#c-panes'); box.innerHTML = ''; box.dataset.n = LAY.n; panes = [];
  $$('#c-lay button').forEach(b => b.setAttribute('aria-pressed', +b.dataset.n === LAY.n));
  for (let i = 0; i < LAY.n; i++) {
    const el = document.createElement('div'); el.className = 'pane' + (i === active ? ' act' : '');
    el.innerHTML = `<div class="pane-h"><button class="sym" data-psym="${i}" aria-label="Cambiar mercado del gráfico ${i + 1}"><b></b><span></span><svg viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg></button><div class="tfs" data-ptf="${i}" role="group" aria-label="Temporalidad"></div></div><div class="c-wrap"><div class="c-canvas"></div><div class="c-legend"></div><div class="c-selbar" hidden></div><button class="c-auto" hidden>Ajustar</button></div>`;
    box.append(el);
    const chart = FortunaChart(el.querySelector('.c-canvas')), pane = { chart, el, i };
    const ind = LS.get('fr.ind.' + i); if (ind) chart.setInd(ind); else if (i > 0) chart.setInd({ rsi: { on: false } });
    if (!ind || !ind.dxy) chart.setInd({ dxy: { on: i === 0 && LAY.panes[0].sym !== 'DXY' } });
    if (ind && ind.zones && !('fvg' in ind.zones)) chart.setInd({ zones: { ...FortunaChart.RDEF, on: ind.zones.on !== false } });
    chart.setType(LS.get('fr.type.' + i) || 'candles');
    chart.on('change', () => {
      const s = LAY.panes[i].sym, d = chart.getDrawings(); LS.set('fr.draw.' + s, d);
      panes.forEach(o => { if (o !== pane && LAY.panes[o.i].sym === s) o.chart.setDrawings(JSON.parse(JSON.stringify(d))); });
    });
    chart.on('tool', renderTools);
    chart.on('cross', idx => legend(pane, idx));
    const bar = el.querySelector('.c-selbar'), auto = el.querySelector('.c-auto');
    chart.on('select', d => { if (!d) { bar.hidden = true; return; } bar.innerHTML = COLORS.map(c => `<button class="sw" style="background:${c}" data-col="${c}" aria-label="Color"></button>`).join('') + '<button class="del" data-delsel>Eliminar</button>'; bar.hidden = false; });
    bar.onclick = e => { const c = e.target.closest('[data-col]'); if (c) chart.colorSelected(c.dataset.col); if (e.target.closest('[data-delsel]')) chart.deleteSelected(); };
    el.querySelector('.c-canvas').addEventListener('pointerup', () => setTimeout(() => { auto.hidden = chart.isAuto(); }, 0));
    auto.onclick = () => { chart.resetView(); auto.hidden = true; };
    el.addEventListener('pointerdown', () => setActive(i), true);
    panes.push(pane);
  }
}
function setActive(i) {
  if (i === active || !panes[i]) return;
  const prev = panes[active], t = prev ? prev.chart.getTool() : 'cursor';
  if (prev && t !== 'cursor') { prev.chart.setTool('cursor'); panes[i].chart.setTool(t); }
  active = i; saveLay(); panes.forEach(p => p.el.classList.toggle('act', p.i === i)); renderTools();
}
function legend(pane, i) {
  const c = LAY.panes[pane.i], d = SY[c.sym].d, a = series[c.sym + '|' + c.tf] || [];
  const idx = i == null ? a.length - 1 : i, k = pane.chart.candleAt(idx); if (!k) return;
  const v = pane.chart.values(idx), ind = pane.chart.getInd(), ch = (k.close / k.open - 1) * 100, col = k.close >= k.open ? 'u' : 'd', ec = ['var(--gold)', 'var(--sky)', 'var(--violet)'];
  pane.el.querySelector('.c-legend').classList.toggle('x', i != null);
  pane.el.querySelector('.c-legend').innerHTML = `<b>${c.sym}</b> · ${tfLabel(c.tf)} · ${esc(SY[c.sym].n)}<span class="ohlc"><br><i>A <i class="${col}">${dec(k.open, d)}</i></i> <i>M <i class="${col}">${dec(k.high, d)}</i></i> <i>m <i class="${col}">${dec(k.low, d)}</i></i> <i>C <i class="${col}">${dec(k.close, d)}</i></i> <i class="${col}">${sg(ch)} %</i></span>`
    + (ind.ema.on ? '<span class="ema"><br>' + ind.ema.p.map((p, j) => `<span style="color:${ec[j]}">EMA ${p} ${v.e[j] != null ? dec(v.e[j], d) : ''}</span>`).join(' &nbsp;') + '</span>' : '');
}
function paneHead(pane) {
  const c = LAY.panes[pane.i], ch = chg(c.sym), h = pane.el;
  h.querySelector('.sym b').textContent = c.sym;
  h.querySelector('.sym span').innerHTML = `${dec(px[c.sym], SY[c.sym].d)} <i class="${ch >= 0 ? 'u' : 'd'}" style="font-style:normal">${sg(ch)} %</i>`;
  const tfs = h.querySelector('.tfs');
  if (tfs.dataset.cur !== String(c.tf)) { tfs.dataset.cur = c.tf; tfs.innerHTML = TFS.map(([l, m]) => `<button data-tf="${m}" aria-pressed="${m === c.tf}">${l}</button>`).join(''); }
}
async function loadPane(pane) {
  if (!pane) return; const c = LAY.panes[pane.i]; paneHead(pane);
  const d = await getSeries(c.sym, c.tf);
  pane.chart.setExtra(extraFor(c, pane.chart.getInd()), true);
  pane.chart.setData(d, c.tf * 6e4, SY[c.sym].d, false);
  pane.chart.setDrawings(LS.get('fr.draw.' + c.sym) || []);
  pane.el.querySelector('.c-selbar').hidden = true; pane.el.querySelector('.c-auto').hidden = true; legend(pane, null);
}
function loadAll() { buildPanes(); renderTools(); panes.forEach(p => loadPane(p)); }
function renderTools() {
  const ch = AP() && AP().chart, t = ch ? ch.getTool() : 'cursor', mg = ch && ch.getMagnet();
  $('#tools').innerHTML = TOOLS.map(([k, l, ic]) => `<button data-tool="${k}" aria-pressed="${k === 'magnet' ? !!mg : k === t}"><svg viewBox="0 0 24 24">${ic}</svg>${l}</button>`).join('');
}
$('#tools').onclick = e => {
  const b = e.target.closest('[data-tool]'), chart = AP() && AP().chart; if (!b || !chart) return; const k = b.dataset.tool;
  if (k === 'magnet') { const on = !chart.getMagnet(); panes.forEach(p => p.chart.setMagnet(on)); toast(on ? 'Imán activado: los puntos se pegan a las velas' : 'Imán desactivado'); }
  else if (k === 'clear') { if (!chart.getDrawings().length) return toast('No hay dibujos en este gráfico'); chart.clearDrawings(); toast('Dibujos borrados'); }
  else { chart.setTool(chart.getTool() === k && k !== 'cursor' ? 'cursor' : k); if (k !== 'cursor') toast({ trend: 'Arrastra para trazar la línea de tendencia', hline: 'Toca el precio donde quieres la línea', rect: 'Arrastra para dibujar la zona', fib: 'Arrastra de un extremo al otro del movimiento', measure: 'Arrastra para medir distancia y tiempo' }[k]); }
  renderTools();
};
RENDER.grafico = () => loadAll();
$('#c-lay').onclick = e => { const b = e.target.closest('[data-n]'); if (!b) return; LAY.n = +b.dataset.n; if (active >= LAY.n) active = 0; saveLay(); loadAll(); if (LAY.n > 1) toast('Toca un gráfico para elegirlo: las herramientas y ajustes se aplican al marcado en dorado'); };
$('#c-panes').addEventListener('click', e => {
  const s = e.target.closest('[data-psym]'); if (s) { symSheet(+s.dataset.psym); return; }
  const t = e.target.closest('[data-tf]'); if (t) { const i = +t.closest('[data-ptf]').dataset.ptf; LAY.panes[i].tf = +t.dataset.tf; saveLay(); loadPane(panes[i]); }
});
function symSheet(i) {
  sheet(LAY.n > 1 ? `Mercado · gráfico ${i + 1}` : 'Mercado', ORDER.map(s => { const c = chg(s); return `<button class="opt" data-s="${s}" aria-pressed="${s === LAY.panes[i].sym}"><span><b>${s}</b><br><small class="sub">${SY[s].n}</small></span><span>${dec(px[s], SY[s].d)} <span class="pill ${c >= 0 ? 'u' : 'd'}">${sg(c)} %</span></span></button>`; }).join(''),
    el => el.onclick = e => { const b = e.target.closest('[data-s]'); if (b) { closeSheet(); LAY.panes[i].sym = b.dataset.s; saveLay(); loadPane(panes[i]); } });
}
function openChart(s) { const i = Math.min(active, LAY.n - 1); LAY.panes[i].sym = s; saveLay(); if (view === 'grafico') loadPane(panes[i]); else show('grafico'); }
const nth = () => LAY.n > 1 ? ` · gráfico ${active + 1}` : '';
$('#c-type').onclick = () => { const chart = AP().chart, cur = chart.getType(); sheet('Tipo de gráfico' + nth(), [['candles', 'Velas japonesas'], ['heikin', 'Heikin Ashi'], ['bars', 'Barras OHLC'], ['line', 'Línea'], ['area', 'Área']].map(([k, l]) => `<button class="opt" data-ty="${k}" aria-pressed="${k === cur}"><b>${l}</b>${k === cur ? '<span class="u">✓</span>' : ''}</button>`).join(''), el => el.onclick = e => { const b = e.target.closest('[data-ty]'); if (b) { chart.setType(b.dataset.ty); LS.set('fr.type.' + active, b.dataset.ty); closeSheet(); } }); };
$('#c-ind').onclick = () => {
  const pane = AP(), chart = pane.chart, key = 'fr.ind.' + active, ind = chart.getInd(), sw = (k, on) => `<button class="sw-t" role="switch" aria-checked="${on}" data-sw="${k}" aria-label="Activar"></button>`;
  const inp = (k, f, v, l) => `<label>${l}<input inputmode="decimal" data-k="${k}" data-f="${f}" value="${v}"></label>`;
  sheet('Indicadores' + nth(), `
    <div class="indrow"><div class="hd"><b>Radiant Fortune Zones</b>${sw('zones', ind.zones.on)}</div><p class="sub" style="margin:6px 0 0">Zonas de compra y venta (FVG + VI) multi-temporalidad, liquidez, PDH/PWH, rango premium/descuento y señales de retest con puntuación.</p><details class="opts"><summary>⚙ Opciones del indicador</summary>${optHTML('zones', ind.zones)}</details></div>
    <div class="indrow"><div class="hd"><b>Panel DXY (debajo del gráfico)</b>${sw('dxy', ind.dxy.on)}</div><p class="sub" style="margin:6px 0 0">Velas del DXY + EMA + zonas de compras/ventas del DXY + correlación y sesgo para el oro. El oro suele ir al revés que el DXY.</p><details class="opts"><summary>⚙ Opciones del indicador</summary>${optHTML('dxy', ind.dxy)}</details></div>
    <div class="indrow"><div class="hd"><b>Medias móviles EMA</b>${sw('ema', ind.ema.on)}</div><div class="ps">${ind.ema.p.map((p, i) => inp('ema', 'p' + i, p, 'Periodo ' + (i + 1))).join('')}</div></div>
    <div class="indrow"><div class="hd"><b>Bandas de Bollinger</b>${sw('bb', ind.bb.on)}</div><div class="ps">${inp('bb', 'p', ind.bb.p, 'Periodo')}${inp('bb', 'k', ind.bb.k, 'Desviaciones')}</div></div>
    <div class="indrow"><div class="hd"><b>Divergencias RSI</b>${sw('div', ind.div ? ind.div.on : true)}</div><p class="sub" style="margin:6px 0 0">Alcista: el precio marca un mínimo más bajo pero el RSI uno más alto (posible giro al alza). Bajista: al revés.</p></div>
    <div class="indrow"><div class="hd"><b>Volume Profile</b>${sw('vp', ind.vp ? ind.vp.on : false)}</div><div class="ps">${inp('vp', 'bins', ind.vp ? ind.vp.bins : 40, 'Niveles de precio')}</div><p class="sub" style="margin:6px 0 0">Volumen negociado en cada precio de lo que ves en pantalla. POC = precio con más volumen; VAH/VAL = zona de valor (70 %).</p></div>
    <div class="indrow"><div class="hd"><b>Pivotes diarios</b>${sw('piv', ind.piv.on)}</div></div>
    <div class="indrow"><div class="hd"><b>RSI</b>${sw('rsi', ind.rsi.on)}</div><div class="ps">${inp('rsi', 'p', ind.rsi.p, 'Periodo')}</div></div>
    <div class="indrow"><div class="hd"><b>MACD</b>${sw('macd', ind.macd.on)}</div><div class="ps">${inp('macd', 'f', ind.macd.f, 'Rápida')}${inp('macd', 's', ind.macd.s, 'Lenta')}${inp('macd', 'g', ind.macd.g, 'Señal')}</div></div>
    <button class="btn ghost full" style="margin-top:14px" data-reset>Valores por defecto</button>`, el => {
    el.onclick = e => {
      const ob = e.target.closest('[data-ot="b"]'); if (ob) { const on = ob.getAttribute('aria-checked') !== 'true'; ob.setAttribute('aria-checked', on); chart.setInd({ [ob.dataset.ok]: { [ob.dataset.of]: on } }); chart.setExtra(extraFor(LAY.panes[pane.i], chart.getInd())); LS.set(key, chart.getInd()); return; }
      const s = e.target.closest('[data-sw]'); if (s) { const on = s.getAttribute('aria-checked') !== 'true'; s.setAttribute('aria-checked', on); chart.setInd({ [s.dataset.sw]: { on } }); chart.setExtra(extraFor(LAY.panes[pane.i], chart.getInd())); LS.set(key, chart.getInd()); legend(pane, null); }
      if (e.target.closest('[data-reset]')) { chart.setInd({ ema: { on: true, p: [20, 50, 200] }, bb: { on: false, p: 20, k: 2 }, piv: { on: false }, rsi: { on: true, p: 14 }, macd: { on: false, f: 12, s: 26, g: 9 }, zones: { ...FortunaChart.RDEF, on: true }, vp: { on: false, bins: 40 }, div: { on: true }, dxy: { ...FortunaChart.ZDEF, on: active === 0, ema: 50, corr: 50, table: true, alert: false, up: '#26A69A', dn: '#EF5350', emaCol: '#D4AF37' } }); chart.setExtra(extraFor(LAY.panes[pane.i], chart.getInd())); LS.set(key, chart.getInd()); closeSheet(); legend(pane, null); }
    };
    const optSet = e => { const o = e.target.closest('[data-ok]'); if (!o || o.dataset.ot === 'b') return false; const v = optRead(o); if (v === undefined) return true; chart.setInd({ [o.dataset.ok]: { [o.dataset.of]: v } }); chart.setExtra(extraFor(LAY.panes[pane.i], chart.getInd())); LS.set(key, chart.getInd()); return true; };
    el.onchange = e => { const o = e.target.closest('[data-ok]'); if (o && o.dataset.ot !== 'b' && o.dataset.ot !== 'c' && o.tagName === 'INPUT') { const v = optRead(o); if (v !== undefined) o.value = v; } optSet(e); };
    el.oninput = e => {
      if (e.target.closest('[data-ok]')) { const o = e.target.closest('[data-ok]'); if (o.dataset.ot === 'c' || o.dataset.ot === 's') optSet(e); else if (isFinite(num(o.value))) optSet(e); return; }
      const i = e.target.closest('[data-k]'); if (!i) return; const v = num(i.value), k = i.dataset.k, f = i.dataset.f; if (!(v > 0) || v > 500) return;
      const cur = chart.getInd()[k];
      if (k === 'ema') { const p = [...cur.p]; p[+f.slice(1)] = Math.round(v); chart.setInd({ ema: { p } }); } else chart.setInd({ [k]: { [f]: f === 'k' ? v : Math.round(k === 'vp' ? Math.max(10, Math.min(120, v)) : v) } });
      LS.set(key, chart.getInd()); legend(pane, null);
    };
  });
};
$('#c-full').onclick = () => {
  const on = !$('#app').classList.contains('full'); $('#app').classList.toggle('full', on); $('#c-full').setAttribute('aria-pressed', on);
  try { if (on && document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(() => {}); else if (!on && document.fullscreenElement) document.exitFullscreen().catch(() => {}); } catch (e) {}
  panes.forEach(p => p.chart.redraw());
};

// =============== FORTUNATY ===============
const FT = { msgs: [], busy: false, mode: null };
const CHIPS = ['Análisis técnico del XAUUSD', 'Noticias del oro hoy', 'Niveles clave para hoy', '¿Cómo afecta el DXY al oro ahora?', 'Explícame el RSI actual', 'Revisa mis líneas del gráfico'];
const SYS = `Eres Fortunaty, la inteligencia artificial de la app Fortuna Radiante, especializada en el oro (XAUUSD) y en los mercados relacionados (DXY, Bitcoin, petróleo WTI).
Respondes siempre en español, con tono cercano, claro y profesional, pensado para leerse en el móvil: frases cortas, títulos breves con ###, listas con guiones y cifras concretas tomadas de los DATOS que se te dan. Máximo unas 220 palabras salvo que pidan más.
En los DATOS, zonasCompra/zonasVenta vienen del indicador del usuario «Radiant Fortune Zones» como [desde, hasta, temporalidad, FVG o VI, fuerza]; úsalas como zonas de compra y venta, junto con liquidezArriba/liquidezAbajo, ultimaSenal y el rango premium/descuento. Recuerda que el oro suele moverse al revés que el DXY.
Para un análisis técnico usa esta estructura: ### Resumen · ### Tendencia (H1, H4, D1) · ### Niveles clave (soportes y resistencias con precio) · ### Escenarios (alcista y bajista, con qué confirmaría cada uno) · ### Riesgos.
Nunca garantices resultados ni des órdenes de compra/venta personalizadas; puedes describir escenarios y niveles. Termina los análisis con una línea breve: "Esto es información, no asesoramiento financiero."
Si los DATOS indican que los precios son simulados, dilo con naturalidad al principio ("Con los datos de demostración de la app…").`;
const SYS_NONEWS = `\nEn este modo NO tienes acceso a noticias ni a internet. Si te piden noticias, dilo claramente, no inventes titulares ni datos, y explica qué tipo de eventos suelen mover el oro (datos de empleo e inflación de EE. UU., decisiones de la Reserva Federal, el dólar, tensiones geopolíticas) para que el usuario los consulte.`;
function snapshot() {
  const o = { hora_madrid: new Date().toLocaleString('es-ES', { timeZone: 'Europe/Madrid' }), fuente_de_precios: isReal('XAUUSD') ? (FEED.fresh ? 'precios reales de Vantage (MetaTrader 5) en directo' : 'precios reales de Vantage, últimos disponibles (mercado cerrado o robot parado)') + (ORDER.some(s => !isReal(s)) ? '; simulados: ' + ORDER.filter(s => !isReal(s)).join(', ') : '') : LIVE && FEAT.candles ? 'precios reales del bróker' : 'DATOS SIMULADOS (modo demostración de la app)', precios: {}, xauusd_indicadores: {} };
  ORDER.forEach(s => o.precios[s] = { precio: r2(px[s], SY[s].d), cambio_24h_pct: r2(chg(s)) });
  [['H1', 60], ['H4', 240], ['D1', 1440]].forEach(([l, m]) => { const a = FortunaChart.analyze(seriesSync('XAUUSD', m), m * 6e4); if (a) { const deep = v => typeof v === 'number' ? r2(v) : Array.isArray(v) ? v.map(deep) : v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).map(([kk, vv]) => [kk, deep(vv)])) : v; o.xauusd_indicadores[l] = deep(a); } });
  const lines = (LS.get('fr.draw.XAUUSD') || []).filter(d => d.type === 'hline').map(d => r2(d.p[0].price)); if (lines.length) o.lineas_horizontales_del_usuario_en_xauusd = lines;
  return o;
}
let samplerP = null;
function getSampler() {
  if (!samplerP) samplerP = (async () => {
    for (let k = 0; k < 30 && !(window.claude && window.claude.use); k++) await wait(100);
    if (!(window.claude && window.claude.use)) return null;
    try { return await window.claude.use('sample'); } catch (e) { return null; }
  })();
  return samplerP;
}
async function ftMode() {
  if (LIVE && FEAT.ai) return 'server';
  return (await getSampler()) ? 'sample' : 'offline';
}
function md(t) {
  const lines = esc(t).split('\n'); let h = '', inList = false;
  const inline = s => s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\[([^\]]+)\]\((https:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  for (const raw of lines) {
    const l = raw.trim();
    if (/^([-*•]|\d+\.)\s+/.test(l)) { if (!inList) { h += '<ul>'; inList = true; } h += '<li>' + inline(l.replace(/^([-*•]|\d+\.)\s+/, '')) + '</li>'; continue; }
    if (inList) { h += '</ul>'; inList = false; }
    if (/^#{1,4}\s/.test(l)) h += '<h4>' + inline(l.replace(/^#{1,4}\s/, '')) + '</h4>';
    else if (l) h += '<p>' + inline(l) + '</p>';
  }
  return h + (inList ? '</ul>' : '');
}
function renderFT() {
  const box = $('#ft-msgs'), badge = { server: 'IA con noticias en tiempo real', sample: 'IA · análisis con los datos de la app', offline: 'Modo básico · análisis automático' }[FT.mode] || 'Conectando…';
  const hello = `<div class="ft-hello"><div class="ft-av"><img src="icons/logo-192.png" alt=""></div><h2>Fortunaty</h2><p>Tu analista del oro. Pregúntame por el XAUUSD, el dólar, niveles, noticias o cómo leer un indicador.</p><span class="badge">${badge}</span></div>`;
  box.innerHTML = hello + FT.msgs.map(m => m.role === 'user' ? `<div class="bub user">${esc(m.content)}</div>` : `<div class="bub ai"><div class="who">Fortunaty</div>${m.content ? md(m.content) : '<div class="dots"><span></span><span></span><span></span></div>'}${m.sources && m.sources.length ? `<div class="src"><b>Fuentes</b>${m.sources.filter(s => /^https:\/\//.test(s.url)).map(s => `<a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.title || s.url)}</a>`).join('')}</div>` : ''}</div>`).join('') + (FT.msgs.length ? '<p class="disc">Fortunaty informa y analiza; no es asesoramiento financiero.</p>' : '');
  box.scrollTop = box.scrollHeight;
}
RENDER.fortunaty = async () => {
  $('#ft-chips').innerHTML = CHIPS.map(c => `<button data-chip="${esc(c)}">${esc(c)}</button>`).join('');
  renderFT(); if (!FT.mode) { FT.mode = await ftMode(); renderFT(); }
};
$('#ft-chips').onclick = e => { const b = e.target.closest('[data-chip]'); if (b) ask(b.dataset.chip); };
$('#ft-form').onsubmit = e => { e.preventDefault(); const t = $('#ft-in').value.trim(); if (t) { $('#ft-in').value = ''; ask(t); } };
function offlineAnswer(q) {
  const s = snapshot(), a = s.xauusd_indicadores, out = [`Ahora mismo no tengo conexión con la IA, así que te dejo la **lectura automática** de los indicadores${LIVE && FEAT.candles ? '' : ' (con los datos de demostración)'}:`];
  for (const [l, x] of Object.entries(a)) out.push(`- **${l}**: precio ${dec(x.close)} · ${x.close > x.ema200 ? 'por encima' : 'por debajo'} de la EMA 200 · RSI ${dec(x.rsi14, 1)} · MACD ${x.macd > x.macdSignal ? 'alcista' : 'bajista'}`);
  const h = a.H1; if (h) out.push(`### Niveles H1`, `- Resistencias: ${dec(h.pivots.R1)} y ${dec(h.swingHigh50)}`, `- Soportes: ${dec(h.pivots.S1)} y ${dec(h.swingLow50)}`);
  if (/notic/i.test(q)) out.push('Para noticias necesito la conexión con la IA del servidor.');
  out.push('Esto es información, no asesoramiento financiero.');
  return out.join('\n');
}
async function ask(q) {
  if (FT.busy) return toast('Fortunaty está terminando la respuesta anterior');
  FT.busy = true; if (!FT.mode) FT.mode = await ftMode();
  FT.msgs.push({ role: 'user', content: q }); const msg = { role: 'assistant', content: '' }; FT.msgs.push(msg); renderFT();
  try {
    const snap = snapshot(), hist = FT.msgs.slice(0, -1).filter(m => m.content).slice(-10).map(m => ({ role: m.role, content: m.content }));
    if (FT.mode === 'server') {
      const j = await api('/api/fortunaty', { method: 'POST', body: { messages: hist, snapshot: snap } });
      msg.content = j.text; msg.sources = j.sources;
    } else if (FT.mode === 'sample') {
      const sample = await getSampler();
      const input = hist.map((m, i) => i === hist.length - 1 ? { role: 'user', content: `${SYS}${SYS_NONEWS}\n\nDATOS DE MERCADO ACTUALES (JSON):\n${JSON.stringify(snap)}\n\nPREGUNTA DEL USUARIO: ${m.content}` } : m);
      while (input.length && input[0].role !== 'user') input.shift();
      let last = 0;
      const res = await sample(input, { cache: false, onText: ({ text }) => { msg.content = text; if (Date.now() - last > 120) { last = Date.now(); renderFT(); } } });
      msg.content = res.text;
    } else { await wait(500); msg.content = offlineAnswer(q); }
  } catch (e) {
    const code = e && e.code;
    msg.content = code === 'not_granted' ? 'Necesito tu permiso para usar la IA en esta vista. Vuelve a preguntar y acepta el aviso.' : code === 'rate_limited' ? 'Has hecho muchas preguntas seguidas. Espera un momento y vuelve a intentarlo.' : (e && e.message ? 'No he podido responder: ' + e.message : 'No he podido responder ahora mismo.');
    if (code === 'not_granted') FT.mode = null;
  }
  FT.busy = false; renderFT();
}

// =============== COMUNIDAD: registro, miembros y chat tipo Telegram ===============
// Con Supabase configurado (config.js) la comunidad es real y compartida; si no, modo demo en este móvil.
let comTab = 'chat';
const CHANNELS = [['general', 'General'], ['xauusd', 'XAUUSD'], ['analisis', 'Análisis'], ['mentorias', 'Mentorías']];
let ch = 'general';
const SB_URL = String(window.FR_SUPABASE_URL || '').trim(), SB_KEY = String(window.FR_SUPABASE_KEY || '').trim();
const okUrl = u => typeof u === 'string' && /^(https:\/\/|data:image\/|blob:)/.test(u);
const AVC = ['#c8901a', '#b5652a', '#8a6a1c', '#a0522d', '#7c4dff', '#2e8b57', '#3b6fd8', '#b03a5b'];
const hashN = s => { let h = 0; for (const c of String(s || '')) h = (h * 31 + c.charCodeAt(0)) | 0; return Math.abs(h); };
function avHTML(p, size = 40, online = false) {
  const inner = p && okUrl(p.avatar_url) ? `<img src="${esc(p.avatar_url)}" alt="" loading="lazy">` : `<span style="background:${AVC[hashN(p && p.alias) % AVC.length]};font-size:${Math.round(size * .42)}px">${esc(((p && p.alias) || '?')[0].toUpperCase())}</span>`;
  return `<span class="ava${online ? ' on' : ''}" style="width:${size}px;height:${size}px">${inner}</span>`;
}
async function shrink(file, max, square) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((ok, ko) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => ko(new Error('No se pudo leer la imagen')); i.src = url; });
    let w = img.naturalWidth, h = img.naturalHeight, sx = 0, sy = 0, sw = w, sh = h;
    if (square) { const m = Math.min(w, h); sx = (w - m) / 2; sy = (h - m) / 2; sw = sh = m; w = h = Math.min(max, m); }
    else { const k = Math.min(1, max / Math.max(w, h)); w = Math.round(w * k); h = Math.round(h * k); }
    const c = document.createElement('canvas'); c.width = w; c.height = h; c.getContext('2d').drawImage(img, sx, sy, sw, sh, 0, 0, w, h);
    return await new Promise(ok => c.toBlob(ok, 'image/jpeg', .82));
  } finally { URL.revokeObjectURL(url); }
}
const blobToData = b => new Promise(ok => { const r = new FileReader(); r.onload = () => ok(r.result); r.readAsDataURL(b); });
function loadScript(src) { return new Promise((ok, ko) => { const s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = () => ko(new Error('Sin conexión con la comunidad')); document.head.append(s); }); }

// ---------- modo demo: todo en este dispositivo ----------
function LocalComm() {
  const now = Date.now();
  const people = [['Carmen_FX', 'Opero la apertura de Londres cada mañana.'], ['PipHunter', 'Scalping en M5 · paciencia y stop.'], ['GoldDigger', 'Solo oro, solo H1.'], ['NoaTrades', 'Gestión del riesgo ante todo.'], ['Martina.V', 'Swing trader, me gustan los rangos.'], ['SwingKing', 'Rupturas con volumen.'], ['ToroBravo', 'Agresivo pero siempre con stop.'], ['LoboDeWallSt', 'Price action puro.'], ['Laura Méndez', 'Mentora · price action en oro.', 'mentor']];
  const members = people.map(([alias, bio, role], i) => ({ id: 'u' + i, alias, bio, role: role || 'user', avatar_url: null, created_at: new Date(now - (i + 2) * 864e5 * 3).toISOString() }));
  let me = LS.get('fr.local.me'); const msgs = []; let mid = 1; const subs = [];
  const add = (c, uid, kind, body, ago, x = {}) => msgs.push({ id: mid++, channel: c, user_id: uid, kind, body, media_url: x.media_url || null, duration: x.duration || null, created_at: new Date(now - ago * 6e4).toISOString() });
  const chartPic = (() => { try { const c = document.createElement('canvas'); c.width = 520; c.height = 300; const g = c.getContext('2d'); g.fillStyle = '#110f0b'; g.fillRect(0, 0, 520, 300); let p = 160; for (let i = 0; i < 40; i++) { const o = p, cl = p + (Math.random() - .45) * 22; g.strokeStyle = g.fillStyle = cl < o ? '#3ddc97' : '#ff5f5f'; const x = 14 + i * 12.5; g.beginPath(); g.moveTo(x + 4, Math.min(o, cl) - 8); g.lineTo(x + 4, Math.max(o, cl) + 8); g.stroke(); g.fillRect(x, Math.min(o, cl), 8, Math.max(2, Math.abs(cl - o))); p = cl; } g.strokeStyle = '#f2c14e'; g.setLineDash([6, 5]); g.beginPath(); g.moveTo(0, 120); g.lineTo(520, 120); g.stroke(); g.fillStyle = '#f2c14e'; g.font = '600 18px sans-serif'; g.fillText('XAUUSD H1 · resistencia', 16, 108); return c.toDataURL('image/jpeg', .8); } catch (e) { return null; } })();
  add('general', 'u0', 'text', '¡Buenos días, familia radiante! ☀️ ¿Quién opera hoy Londres?', 95);
  add('general', 'u1', 'text', 'Yo, con media posición. Hay datos de EE. UU. por la tarde.', 90);
  add('general', 'u6', 'text', 'Subí 3 puestos en la liga esta semana 💪', 40);
  add('general', 'u3', 'text', '🔥🔥', 38);
  add('xauusd', 'u2', 'text', 'El oro respetando la EMA 50 en H1 otra vez. Os dejo mi gráfico:', 72);
  if (chartPic) add('xauusd', 'u2', 'image', null, 71, { media_url: chartPic });
  add('xauusd', 'u7', 'text', 'RSI de H4 alto, yo esperaría un retroceso para entrar.', 50);
  add('xauusd', 'u4', 'text', 'Atentos al pivote diario, ayer rebotó justo ahí 🎯', 20);
  add('analisis', 'u5', 'text', 'Mi idea: rango en D1, espero ruptura con fuerza antes de entrar.', 180);
  add('mentorias', 'u8', 'text', 'Esta semana revisamos operaciones de la liga. Traed capturas del gráfico 📊', 300);
  add('mentorias', 'u8', 'text', 'La grabación queda en Mentorías al día siguiente.', 110);
  const emit = m => subs.forEach(s => s.on(m)), save = () => LS.set('fr.local.me', me);
  const REPL = ['Buena observación 👌', 'Lo veo parecido, pero esperaría confirmación en H1.', 'Cuidado con el spread en noticias ⚠️', '¿Dónde pondrías el stop?', 'Gracias por compartir 🙌', 'Fortunaty me marcó el mismo nivel.', '😂😂', '¡Vamos! 🚀'];
  const self = {
    mode: 'demo', init: async () => {}, me: () => me, onAuth() {}, onPresence() {},
    profile: id => id === 'me' ? me : members.find(m => m.id === id),
    async signUp({ alias, email, avatar }) {
      if (members.some(m => m.alias.toLowerCase() === alias.toLowerCase())) throw new Error('Ese alias ya está en uso.');
      me = { id: 'me', alias, bio: '', role: 'user', email, avatar_url: avatar ? await blobToData(avatar) : null, created_at: new Date().toISOString() }; save(); return { needsConfirm: false };
    },
    async signIn({ email }) { const s = LS.get('fr.local.me'); if (!s) throw new Error('No hay ninguna cuenta en este dispositivo. Crea una.'); if (s.email && email && s.email.toLowerCase() !== email.toLowerCase()) throw new Error('Ese correo no coincide con la cuenta de este dispositivo.'); me = s; },
    async signOut() { me = null; },
    async resetPassword() { throw new Error('En modo demo no hay contraseñas que recuperar.'); },
    async setPassword() {},
    async deleteAccount() { LS.del('fr.local.me'); me = null; for (let i = msgs.length - 1; i >= 0; i--) if (msgs[i].user_id === 'me') msgs.splice(i, 1); },
    async updateProfile(p) { Object.assign(me, p); save(); },
    async uploadAvatar(blob) { me.avatar_url = await blobToData(blob); save(); },
    async members() { return me ? [me, ...members] : members.slice(); },
    online: () => new Set(['u0', 'u2', 'u4', 'u8', ...(me ? ['me'] : [])]),
    async messages(c) { return msgs.filter(m => m.channel === c); },
    async send(c, { kind, body, blob, duration }) {
      const m = { id: mid++, channel: c, user_id: 'me', kind, body: body || null, media_url: blob ? URL.createObjectURL(blob) : null, duration: duration || null, created_at: new Date().toISOString() };
      msgs.push(m); emit(m);
      if (Math.random() < .65) setTimeout(() => { const u = members[Math.floor(Math.random() * 8)], r = { id: mid++, channel: c, user_id: u.id, kind: 'text', body: REPL[Math.floor(Math.random() * REPL.length)], created_at: new Date().toISOString() }; msgs.push(r); emit(r); }, 1600 + Math.random() * 2600);
    },
    async remove(id) { const i = msgs.findIndex(m => m.id === id); if (i >= 0) msgs.splice(i, 1); subs.forEach(s => s.del && s.del(id)); },
    subscribe(on, del) { subs.push({ on, del }); },
    async alerts() { return LS.get('fr.alerts') || []; },
    async addAlert(x) { const al = { id: Date.now(), active: true, created_at: new Date().toISOString(), ...x }; const l = LS.get('fr.alerts') || []; l.unshift(al); LS.set('fr.alerts', l); return al; },
    async delAlert(id) { LS.set('fr.alerts', (LS.get('fr.alerts') || []).filter(a => a.id !== id)); },
  };
  return self;
}

// ---------- modo real: Supabase (registro, perfiles, chat en tiempo real, fotos y audios) ----------
function SupaComm() {
  let sb, session = null, me = null, online = new Set(), presenceCb = () => {}, authCb = () => {}, presence = null, rt = null;
  const subs = [], prof = new Map();
  const trad = m => /Invalid login/i.test(m) ? 'Correo o contraseña incorrectos.' : /Email not confirmed/i.test(m) ? 'Confirma tu correo: te enviamos un enlace al registrarte.' : /already registered|already been registered/i.test(m) ? 'Ya hay una cuenta con ese correo. Entra o recupera la contraseña.' : /Password should be|weak/i.test(m) ? 'La contraseña es demasiado corta o sencilla.' : /duplicate key|profiles_alias/i.test(m) ? 'Ese alias ya está en uso.' : /rate limit|too many/i.test(m) ? 'Demasiados intentos. Espera unos minutos.' : /Failed to fetch|NetworkError/i.test(m) ? 'Sin conexión. Revisa internet.' : m;
  const fail = e => { if (e) throw new Error(trad(e.message || String(e))); };
  async function loadMe() {
    me = null; if (!session) return;
    const { data } = await sb.from('profiles').select('*').eq('id', session.user.id).maybeSingle();
    if (data) { me = { ...data, email: session.user.email }; prof.set(me.id, me); }
    const pend = LS.get('fr.pendingAvatar');
    if (me && pend) { try { await self.uploadAvatar(await (await fetch(pend)).blob()); } catch (e) {} LS.del('fr.pendingAvatar'); }
  }
  function wire() {
    if (presence) { sb.removeChannel(presence); presence = null; } if (rt) { sb.removeChannel(rt); rt = null; }
    online = new Set(); presenceCb();
    if (!me) return;
    presence = sb.channel('presencia', { config: { presence: { key: me.id } } });
    presence.on('presence', { event: 'sync' }, () => { online = new Set(Object.keys(presence.presenceState())); presenceCb(); })
      .subscribe(async st => { if (st === 'SUBSCRIBED') { try { await presence.track({ at: Date.now() }); } catch (e) {} } });
    rt = sb.channel('mensajes')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, async p => { if (!prof.has(p.new.user_id)) { try { await self.members(); } catch (e) {} } subs.forEach(s => s.on(p.new)); })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, p => subs.forEach(s => s.del && s.del(p.old.id)))
      .subscribe();
  }
  const here = () => location.href.split('#')[0];
  const self = {
    mode: 'online',
    async init() {
      await loadScript('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js');
      sb = window.supabase.createClient(SB_URL, SB_KEY);
      session = (await sb.auth.getSession()).data.session; await loadMe(); wire();
      sb.auth.onAuthStateChange((ev, s) => setTimeout(async () => {
        if (ev === 'PASSWORD_RECOVERY') { session = s; authCb('recovery'); return; }
        const was = session && session.user.id, now = s && s.user.id; session = s;
        if (was !== now || ev === 'USER_UPDATED') { await loadMe(); wire(); authCb(ev); }
      }, 0));
    },
    me: () => me, onAuth(cb) { authCb = cb; }, onPresence(cb) { presenceCb = cb; }, online: () => online,
    profile: id => prof.get(id),
    async signUp({ alias, email, password, avatar }) {
      const { data: ex } = await sb.from('profiles').select('id').ilike('alias', alias.replace(/[\\%_]/g, m => '\\' + m)).limit(1);
      if (ex && ex.length) throw new Error('Ese alias ya está en uso.');
      if (avatar) LS.set('fr.pendingAvatar', await blobToData(avatar));
      const { data, error } = await sb.auth.signUp({ email, password, options: { data: { alias }, emailRedirectTo: here() } }); fail(error);
      if (data.user && Array.isArray(data.user.identities) && !data.user.identities.length) throw new Error('Ya hay una cuenta con ese correo. Entra o recupera la contraseña.');
      if (data.session) { session = data.session; await loadMe(); wire(); return { needsConfirm: false }; }
      return { needsConfirm: true };
    },
    async signIn({ email, password }) {
      const { data, error } = await sb.auth.signInWithPassword({ email, password }); fail(error);
      session = data.session; await loadMe(); if (!me) throw new Error('Tu perfil no existe. Revisa la instalación de la base de datos.'); wire();
    },
    async signOut() { await sb.auth.signOut(); session = null; me = null; wire(); },
    async resetPassword(email) { const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: here() }); fail(error); },
    async setPassword(pw) { const { error } = await sb.auth.updateUser({ password: pw }); fail(error); },
    async deleteAccount() { const { error } = await sb.rpc('delete_my_account'); fail(error); try { await sb.auth.signOut(); } catch (e) {} session = null; me = null; wire(); },
    async updateProfile(p) { const { error } = await sb.from('profiles').update(p).eq('id', me.id); fail(error); Object.assign(me, p); prof.set(me.id, me); },
    async uploadAvatar(blob) {
      const path = `${session.user.id}/avatar-${Date.now()}.jpg`;
      const { error } = await sb.storage.from('avatars').upload(path, blob, { contentType: 'image/jpeg' }); fail(error);
      await self.updateProfile({ avatar_url: sb.storage.from('avatars').getPublicUrl(path).data.publicUrl });
    },
    async members() {
      const { data, error } = await sb.from('profiles').select('id,alias,avatar_url,bio,role,created_at').order('created_at', { ascending: false }).limit(1000); fail(error);
      data.forEach(p => prof.set(p.id, me && p.id === me.id ? { ...p, email: me.email } : p)); return data;
    },
    async messages(c) {
      if (!session) return [];
      const { data, error } = await sb.from('messages').select('*').eq('channel', c).order('id', { ascending: false }).limit(100); fail(error);
      const ids = [...new Set(data.map(m => m.user_id))].filter(id => !prof.has(id)); if (ids.length) await self.members();
      return data.reverse();
    },
    async send(c, { kind, body, blob, duration, ext, type }) {
      let media_url = null;
      if (blob) {
        const path = `${session.user.id}/${Date.now()}-${Math.random().toString(36).slice(2, 7)}.${ext}`;
        const { error } = await sb.storage.from('chat').upload(path, blob, { contentType: type }); fail(error);
        media_url = sb.storage.from('chat').getPublicUrl(path).data.publicUrl;
      }
      const { data, error } = await sb.from('messages').insert({ channel: c, user_id: me.id, kind, body: body || null, media_url, duration: duration || null }).select().single(); fail(error);
      subs.forEach(s => s.on(data));
    },
    async remove(id) { const { error } = await sb.from('messages').delete().eq('id', id); fail(error); subs.forEach(s => s.del && s.del(id)); },
    subscribe(on, del) { subs.push({ on, del }); },
    // precios y velas de Vantage
    async prices() { const { data, error } = await sb.from('prices').select('symbol,bid,ask,ts'); fail(error); return data; },
    async candles(s, m) { const { data, error } = await sb.from('candles').select('*').eq('symbol', s).eq('tf', m).order('t', { ascending: false }).limit(500); fail(error); return data.reverse(); },
    // alertas de precio
    async alerts() { if (!me) return []; const { data, error } = await sb.from('alerts').select('*').eq('user_id', me.id).order('id', { ascending: false }).limit(50); fail(error); return data; },
    async addAlert(x) { const { data, error } = await sb.from('alerts').insert({ ...x, user_id: me.id }).select().single(); fail(error); return data; },
    async delAlert(id) { const { error } = await sb.from('alerts').delete().eq('id', id); fail(error); },
    // notificaciones push
    async savePush(x) { const { error } = await sb.from('push_subscriptions').upsert({ ...x, user_id: me.id }, { onConflict: 'endpoint' }); fail(error); },
    async pushPref(endpoint) { const { data } = await sb.from('push_subscriptions').select('chat_pref').eq('endpoint', endpoint).maybeSingle(); return data && data.chat_pref; },
    async deletePush(endpoint) { const { error } = await sb.from('push_subscriptions').delete().eq('endpoint', endpoint); fail(error); },
    // Respaldo por si el tiempo real no llega: pide los mensajes nuevos
    async poll(c, afterId) {
      if (!session) return;
      const { data, error } = await sb.from('messages').select('*').eq('channel', c).gt('id', afterId || 0).order('id', { ascending: true }).limit(50);
      if (error || !data.length) return;
      if (data.some(m => !prof.has(m.user_id))) { try { await self.members(); } catch (e) {} }
      data.forEach(m => subs.forEach(s => s.on(m)));
    },
  };
  return self;
}
const comm = SB_URL && SB_KEY ? SupaComm() : LocalComm();
function syncUser() { const m = comm.me(); setUser(m ? { id: m.id, alias: m.alias, avatar_url: m.avatar_url } : null); }

// ---------- pestañas de comunidad ----------
RENDER.comunidad = () => {
  $$('#com-seg button').forEach(b => b.setAttribute('aria-pressed', b.dataset.c === comTab));
  $('#com-chat').hidden = comTab !== 'chat'; $('#com-miembros').hidden = comTab !== 'miembros'; $('#com-liga').hidden = comTab !== 'liga';
  if (comTab === 'chat') openChannel(ch); else if (comTab === 'miembros') renderMembers(); else renderLiga();
};
$('#com-seg').onclick = e => { const b = e.target.closest('[data-c]'); if (b) { comTab = b.dataset.c; RENDER.comunidad(); } };

// ---------- chat ----------
let cmsgs = [], loadingCh = null; const unread = {};
const DAYF = new Intl.DateTimeFormat('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
function dayLabel(d) { const t = new Date(); t.setHours(0, 0, 0, 0); const x = new Date(d); x.setHours(0, 0, 0, 0); const diff = (t - x) / 864e5; return diff === 0 ? 'Hoy' : diff === 1 ? 'Ayer' : DAYF.format(x); }
const fmtDur = s => { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const EMO_ONLY = /^(?:\p{Extended_Pictographic}|\p{Emoji_Component}|‍|️|\s)+$/u;
function richText(t) {
  return esc(t).replace(/https:\/\/[^\s<]+/g, u => `<a href="${u}" target="_blank" rel="noopener">${u}</a>`).replace(/(^|\s)@([\p{L}\p{N}_.\-]{3,20})/gu, '$1<b class="mn">@$2</b>');
}
function waveBars(seedStr) { let h = hashN(seedStr); return Array.from({ length: 28 }, () => { h = (h * 1103515245 + 12345) & 0x7fffffff; return `<i style="height:${25 + (h % 75)}%"></i>`; }).join(''); }
function msgHTML(m, prev, next) {
  if (m.kind === 'sys') return `<div class="sysm">${esc(m.body)}</div>`;
  const meId = comm.me() && comm.me().id, out = m.user_id === meId, p = comm.profile(m.user_id) || { alias: 'Miembro', id: m.user_id };
  const same = x => x && x.kind !== 'sys' && x.user_id === m.user_id && Math.abs(new Date(x.created_at) - new Date(m.created_at)) < 5 * 6e4 && dayLabel(x.created_at) === dayLabel(m.created_at);
  const first = !same(prev), last = !same(next);
  const time = `<span class="meta">${hm(m.created_at)}${out ? ' ✓✓' : ''}</span>`;
  const name = !out && first ? `<div class="nm" data-prof="${esc(m.user_id)}" style="color:${AVC[hashN(p.alias) % AVC.length] === '#7c4dff' ? '#b39dff' : '#f2c14e'}">${esc(p.alias)}${p.role === 'mentor' ? '<small>mentor</small>' : ''}</div>` : '';
  let body = '', cls = '';
  if (m.kind === 'image' && okUrl(m.media_url)) { cls = 'pic'; body = `${name}<img class="ph" src="${esc(m.media_url)}" alt="Foto" loading="lazy" data-full="${esc(m.media_url)}">${m.body ? `<div class="tx" style="padding:4px 7px 0">${richText(m.body)}</div>` : ''}${time}`; }
  else if (m.kind === 'audio' && okUrl(m.media_url)) body = `${name}<div class="au" data-src="${esc(m.media_url)}" data-dur="${Number(m.duration) || 0}"><button class="play" aria-label="Reproducir audio"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></button><div style="flex:1"><div class="wave">${waveBars(m.id)}</div><span class="dur">${fmtDur(m.duration)}</span></div></div>${time}`;
  else { const t = String(m.body || ''); if (t.length <= 12 && EMO_ONLY.test(t) && /\p{Extended_Pictographic}/u.test(t)) cls = 'big'; body = `${name}<div class="tx">${richText(t)}</div>${time}`; }
  const slot = out ? '' : `<span class="slot" data-prof="${esc(m.user_id)}">${last ? avHTML(p, 34) : ''}</span>`;
  return `<div class="bm ${out ? 'out' : 'in'}${first ? ' first' : ''}${last ? ' last' : ''}" data-id="${esc(m.id)}">${slot}<div class="bb ${cls}">${body}</div></div>`;
}
function renderChatList(stick) {
  const box = $('#msgs'), near = box.scrollHeight - box.scrollTop - box.clientHeight < 120;
  let h = '', lastDay = '';
  if (!cmsgs.length) h = `<div class="sysm">Todavía no hay mensajes en #${esc(CHANNELS.find(c => c[0] === ch)[1])}. ¡Rompe el hielo! 👋</div>`;
  cmsgs.forEach((m, i) => { const d = dayLabel(m.created_at); if (d !== lastDay) { h += `<div class="day">${esc(d)}</div>`; lastDay = d; } h += msgHTML(m, cmsgs[i - 1], cmsgs[i + 1]); });
  box.innerHTML = h;
  if (stick || near) box.scrollTop = box.scrollHeight;
}
function renderChans() { $('#chans').innerHTML = CHANNELS.map(([k, n]) => `<button data-ch="${k}" aria-selected="${k === ch}"># ${n}${unread[k] ? `<span class="ub">${unread[k]}</span>` : ''}</button>`).join(''); }
function renderOnline() { const n = comm.online().size; const t = n ? `● ${n} en línea` : ''; $('#online').textContent = t; $('#m-online').textContent = t; }
function renderGate() {
  const me = comm.me();
  $('#send').hidden = !me; $('#gate').hidden = !!me; if (me) return;
  $('#emojis').hidden = true;
  $('#gate').innerHTML = `<p>${comm.mode === 'online' ? 'Únete para leer y escribir en la comunidad.' : 'Crea tu perfil para escribir en el chat.'}</p><button class="btn gold full" data-go="cuenta">Crear cuenta o entrar</button>`;
}
async function openChannel(c) {
  ch = c; unread[c] = 0; renderChans(); renderGate(); renderOnline();
  if (comm.mode === 'online' && !comm.me()) { cmsgs = []; $('#msgs').innerHTML = '<div class="sysm">🔒 El chat es solo para miembros registrados.</div>'; return; }
  loadingCh = c; $('#msgs').innerHTML = '<div class="sysm">Cargando mensajes…</div>';
  try { const list = await comm.messages(c); if (loadingCh !== c) return; cmsgs = list; } catch (e) { cmsgs = []; toast(e.message); }
  renderChatList(true);
}
$('#chans').onclick = e => { const b = e.target.closest('[data-ch]'); if (b) openChannel(b.dataset.ch); };
comm.subscribe(m => {
  const yo = comm.me();
  if (yo && m.user_id !== yo.id && m.body && m.body.toLowerCase().includes('@' + yo.alias.toLowerCase()) && !(view === 'comunidad' && comTab === 'chat' && ch === m.channel)) {
    const p = comm.profile(m.user_id); toast(`💬 ${p ? p.alias : 'Alguien'} te ha mencionado en #${(CHANNELS.find(c => c[0] === m.channel) || [, m.channel])[1]}`);
    if (navigator.vibrate) try { navigator.vibrate(40); } catch (e) {}
  }
  if (m.channel !== ch || !(view === 'comunidad' && comTab === 'chat')) { if (!comm.me() || m.user_id !== comm.me().id) { unread[m.channel] = (unread[m.channel] || 0) + 1; if (view === 'comunidad') renderChans(); } if (m.channel !== ch) return; }
  if (cmsgs.some(x => String(x.id) === String(m.id))) return;
  cmsgs.push(m); if (view === 'comunidad' && comTab === 'chat') renderChatList(comm.me() && m.user_id === comm.me().id);
}, id => { const i = cmsgs.findIndex(x => String(x.id) === String(id)); if (i >= 0) { cmsgs.splice(i, 1); if (view === 'comunidad' && comTab === 'chat') renderChatList(); } });
comm.onPresence(() => { renderOnline(); if (view === 'comunidad' && comTab === 'miembros') renderMembers(true); });
$('#msgs').addEventListener('scroll', () => { const b = $('#msgs'); $('#tobottom').hidden = b.scrollHeight - b.scrollTop - b.clientHeight < 300; }, { passive: true });
setInterval(() => {
  if (comm.mode !== 'online' || !comm.poll || !comm.me() || document.hidden || !(view === 'comunidad' && comTab === 'chat')) return;
  const last = cmsgs.filter(m => typeof m.id === 'number').reduce((x, m) => Math.max(x, m.id), 0);
  comm.poll(ch, last).catch(() => {});
}, 4000);
$('#tobottom').onclick = () => { const b = $('#msgs'); b.scrollTo({ top: b.scrollHeight, behavior: 'smooth' }); };

// componer: texto, emojis, fotos y audios
const ICON_MIC = '<path d="M12 15a3.5 3.5 0 0 0 3.5-3.5v-6a3.5 3.5 0 0 0-7 0v6A3.5 3.5 0 0 0 12 15zm6-3.5h-1.8a4.2 4.2 0 0 1-8.4 0H6a6 6 0 0 0 5 5.9V21h2v-3.6a6 6 0 0 0 5-5.9z"/>';
const ICON_SEND = '<path d="M3 20l18-8L3 4v6l12 2-12 2z"/>';
const ta = $('#msg');
function mainBtn() { const has = ta.value.trim().length > 0; $('#b-main-ic').innerHTML = has ? ICON_SEND : ICON_MIC; $('#b-main').setAttribute('aria-label', has ? 'Enviar' : 'Grabar audio'); }
function grow() { ta.style.height = 'auto'; ta.style.height = Math.min(130, ta.scrollHeight) + 'px'; }
ta.addEventListener('input', () => { grow(); mainBtn(); });
ta.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && matchMedia('(pointer:fine)').matches) { e.preventDefault(); sendText(); } });
$('#send').onsubmit = e => { e.preventDefault(); sendText(); };
$('#b-main').onclick = () => ta.value.trim() ? sendText() : startRec();
mainBtn();
async function sendMsg(o) {
  if (!comm.me()) { toast('Crea tu cuenta para escribir'); show('cuenta'); return false; }
  try { await comm.send(ch, o); return true; } catch (e) { toast(e.message); return false; }
}
async function sendText() {
  const t = ta.value.trim(); if (!t) return;
  if (t === '/precio') { ta.value = ''; grow(); mainBtn(); cmsgs.push({ id: 's' + Date.now(), kind: 'sys', body: `XAUUSD cotiza a ${dec(px.XAUUSD)} (${sg(chg('XAUUSD'))} % en 24 h)`, created_at: new Date().toISOString() }); renderChatList(true); return; }
  ta.value = ''; grow(); mainBtn();
  if (!(await sendMsg({ kind: 'text', body: t }))) { ta.value = t; grow(); mainBtn(); }
}
// emojis
const EMO = {
  'Caras': '😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😎 🤩 🥳 🤔 🤨 😐 🙄 😏 😴 😮 😲 😳 🥺 😢 😭 😤 😠 😡 🤯 😱 🤗 🤭 🤫 🤑 🤠 😬 🫠 🥲',
  'Gestos': '👍 👎 👏 🙌 🙏 💪 🤝 ✌️ 🤞 👌 🤙 👊 ✊ 👋 🫡 👀 🧠 ❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💯 🔥 ✨ ⭐ 🌟 ⚡ 💥 🎉 🎊',
  'Trading': '📈 📉 📊 💹 💰 💵 💶 💸 🪙 🥇 🏆 🎯 🚀 🌕 🐂 🐻 ⏰ 🔔 📣 ⚠️ ✅ ❌ 🛑 🟢 🔴 🟡 💎 🏦 🧾 🕯️ 🧮 🔍',
  'Objetos': '☕ 🍕 🍺 🥂 🎧 📱 💻 ⌚ 📅 📌 🔒 🔑 🎁 🏖️ ✈️ 🌍 🌙 ☀️ 🌧️ ⛈️ 🎮 ⚽ 🏀 🎵',
};
let emoCat = 'Caras';
function renderEmo() { $('#etabs').innerHTML = Object.keys(EMO).map(k => `<button type="button" data-ec="${k}" aria-pressed="${k === emoCat}">${k}</button>`).join(''); $('#egrid').innerHTML = EMO[emoCat].split(' ').map(e => `<button type="button" data-e="${e}">${e}</button>`).join(''); }
$('#b-emoji').onclick = () => { const p = $('#emojis'); p.hidden = !p.hidden; $('#b-emoji').setAttribute('aria-pressed', !p.hidden); if (!p.hidden) renderEmo(); const b = $('#msgs'); b.scrollTop = b.scrollHeight; };
$('#etabs').onclick = e => { const b = e.target.closest('[data-ec]'); if (b) { emoCat = b.dataset.ec; renderEmo(); } };
$('#egrid').onclick = e => { const b = e.target.closest('[data-e]'); if (!b) return; const s = ta.selectionStart ?? ta.value.length, en = ta.selectionEnd ?? ta.value.length; ta.value = ta.value.slice(0, s) + b.dataset.e + ta.value.slice(en); const p = s + b.dataset.e.length; try { ta.setSelectionRange(p, p); } catch (x) {} grow(); mainBtn(); };
// fotos
$('#b-attach').onclick = () => { if (!comm.me()) { toast('Crea tu cuenta para enviar fotos'); show('cuenta'); return; } $('#f-photo').click(); };
$('#f-photo').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  if (!/^image\//.test(f.type)) return toast('Elige una imagen');
  toast('Enviando foto…');
  try { const blob = await shrink(f, 1280, false); await sendMsg({ kind: 'image', blob, ext: 'jpg', type: 'image/jpeg', body: ta.value.trim() || null }); ta.value = ''; grow(); mainBtn(); } catch (x) { toast(x.message); }
};
// audios
let rec = null;
async function startRec() {
  if (!comm.me()) { toast('Crea tu cuenta para enviar audios'); show('cuenta'); return; }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) return toast('Aquí no se puede grabar audio. Usa la app instalada o Safari/Chrome.');
  let stream; try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); } catch (e) { return toast('Sin permiso de micrófono. Actívalo en los ajustes del móvil.'); }
  const type = ['audio/mp4', 'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus'].find(t => MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t)) || '';
  let mr; try { mr = new MediaRecorder(stream, type ? { mimeType: type } : {}); } catch (e) { stream.getTracks().forEach(t => t.stop()); return toast('No se pudo empezar a grabar.'); }
  const chunks = []; mr.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
  rec = { mr, stream, chunks, t0: Date.now(), type: mr.mimeType || type || 'audio/webm' };
  rec.timer = setInterval(() => { const s = (Date.now() - rec.t0) / 1000; $('#rec-t').textContent = fmtDur(s); if (s >= 120) stopRec(true); }, 250);
  mr.start(250); $('#rec').hidden = false; $('#send').hidden = true; $('#emojis').hidden = true; $('#rec-t').textContent = '0:00';
  if (navigator.vibrate) try { navigator.vibrate(15); } catch (e) {}
}
function stopRec(send) {
  const r = rec; if (!r) return; rec = null; clearInterval(r.timer);
  r.mr.onstop = async () => {
    r.stream.getTracks().forEach(t => t.stop()); $('#rec').hidden = true; $('#send').hidden = false;
    if (!send) return;
    const dur = (Date.now() - r.t0) / 1000; if (dur < 1) return toast('Audio demasiado corto');
    const mime = r.type.split(';')[0], blob = new Blob(r.chunks, { type: mime }), ext = /mp4|aac|m4a/.test(mime) ? 'm4a' : /ogg/.test(mime) ? 'ogg' : 'webm';
    await sendMsg({ kind: 'audio', blob, duration: dur, ext, type: mime });
  };
  try { r.mr.stop(); } catch (e) { r.mr.onstop(); }
}
$('#rec-x').onclick = () => stopRec(false); $('#rec-ok').onclick = () => stopRec(true);
// reproducción de audios, fotos y perfiles
const player = new Audio(); let playing = null;
function setPlayIcon(au, on) { au.querySelector('.play').innerHTML = `<svg viewBox="0 0 24 24">${on ? '<path d="M6 5h4v14H6zm8 0h4v14h-4z"/>' : '<path d="M8 5v14l11-7z"/>'}</svg>`; }
player.addEventListener('timeupdate', () => { if (!playing) return; const d = player.duration && isFinite(player.duration) ? player.duration : Number(playing.dataset.dur) || 1, k = player.currentTime / d, bars = playing.querySelectorAll('.wave i'); bars.forEach((b, i) => b.classList.toggle('on', i / bars.length < k)); playing.querySelector('.dur').textContent = fmtDur(player.currentTime) + ' / ' + fmtDur(d); });
player.addEventListener('ended', () => { if (playing) { setPlayIcon(playing, false); playing.querySelectorAll('.wave i').forEach(b => b.classList.remove('on')); playing.querySelector('.dur').textContent = fmtDur(playing.dataset.dur); } playing = null; });
$('#msgs').addEventListener('click', e => {
  const pl = e.target.closest('.au .play');
  if (pl) { const au = pl.closest('.au'); if (playing === au && !player.paused) { player.pause(); setPlayIcon(au, false); return; } if (playing && playing !== au) setPlayIcon(playing, false); if (playing !== au) { player.src = au.dataset.src; playing = au; } player.play().then(() => setPlayIcon(au, true)).catch(() => toast('No se pudo reproducir este audio en este móvil')); return; }
  const ph = e.target.closest('.ph'); if (ph) { $('#lb-img').src = ph.dataset.full; $('#lb').hidden = false; return; }
  const pr = e.target.closest('[data-prof]'); if (pr) { profileSheet(pr.dataset.prof); return; }
});
$('#lb').onclick = () => { $('#lb').hidden = true; $('#lb-img').removeAttribute('src'); };
// mantener pulsado un mensaje propio: copiar o eliminar
let lpT = 0;
$('#msgs').addEventListener('pointerdown', e => { const bm = e.target.closest('.bm'); if (!bm || e.target.closest('.play,.ph')) return; lpT = setTimeout(() => msgMenu(bm.dataset.id), 520); });
['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => $('#msgs').addEventListener(ev, () => clearTimeout(lpT)));
$('#msgs').addEventListener('scroll', () => clearTimeout(lpT), { passive: true });
function msgMenu(id) {
  const m = cmsgs.find(x => String(x.id) === String(id)); if (!m || m.kind === 'sys') return;
  const mine = comm.me() && m.user_id === comm.me().id;
  sheet('Mensaje', `${m.body ? '<button class="opt" data-act="copy"><b>Copiar texto</b></button>' : ''}${!mine ? '<button class="opt" data-act="reply"><b>Mencionar al autor</b></button>' : ''}${mine ? '<button class="opt" data-act="del"><b style="color:var(--dn)">Eliminar mensaje</b></button>' : ''}<button class="opt" data-act="x"><b>Cancelar</b></button>`, el => el.onclick = async e => {
    const a = e.target.closest('[data-act]'); if (!a) return; closeSheet();
    if (a.dataset.act === 'copy') { try { await navigator.clipboard.writeText(m.body); toast('Copiado'); } catch (x) { toast('No se pudo copiar'); } }
    if (a.dataset.act === 'reply') { const p = comm.profile(m.user_id); if (p) { ta.value = `@${p.alias} ` + ta.value; grow(); mainBtn(); ta.focus(); } }
    if (a.dataset.act === 'del') { try { await comm.remove(m.id); toast('Mensaje eliminado'); } catch (x) { toast(x.message); } }
  });
}
function profileSheet(id) {
  const p = comm.profile(id); if (!p) return; const isMe = comm.me() && comm.me().id === id;
  sheet(p.alias, `<div class="psheet">${avHTML(p, 110, comm.online().has(id))}<p>${p.role === 'mentor' ? '<span class="role">Mentor</span> ' : ''}Miembro desde ${new Date(p.created_at || Date.now()).toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}</p>${p.bio ? `<p style="color:var(--ink)">${esc(p.bio)}</p>` : ''}${isMe ? '<button class="btn gold full" data-go="cuenta">Editar mi perfil</button>' : `<button class="btn gold full" data-mention="${esc(p.alias)}">Mencionar en el chat</button>`}</div>`, el => el.onclick = e => {
    const b = e.target.closest('[data-mention]'); if (b) { closeSheet(); comTab = 'chat'; show('comunidad'); ta.value = `@${b.dataset.mention} ` + ta.value; grow(); mainBtn(); }
    if (e.target.closest('[data-go]')) closeSheet();
  });
}
// ---------- miembros ----------
let memberList = [];
async function renderMembers(quiet) {
  if (!quiet) { try { memberList = await comm.members(); } catch (e) { toast(e.message); } }
  const q = $('#m-q').value.trim().toLowerCase(), on = comm.online(), meId = comm.me() && comm.me().id;
  const list = memberList.filter(p => !q || p.alias.toLowerCase().includes(q)).sort((a, b) => (b.id === meId) - (a.id === meId) || on.has(b.id) - on.has(a.id) || (b.role === 'mentor') - (a.role === 'mentor'));
  $('#m-count').textContent = `${memberList.length} miembro${memberList.length === 1 ? '' : 's'}`; renderOnline();
  $('#mgrid').innerHTML = list.map(p => `<div class="mcard" data-prof="${esc(p.id)}" role="button" tabindex="0">${avHTML(p, 64, on.has(p.id))}<b>${esc(p.alias)}</b>${p.id === meId ? '<span class="youb">Tú</span>' : p.role === 'mentor' ? '<span class="role">Mentor</span>' : ''}<p>${esc(p.bio || 'Trader de la comunidad')}</p></div>`).join('') || '<p class="sub">Nadie coincide con la búsqueda.</p>';
}
$('#m-q').oninput = () => renderMembers(true);
$('#mgrid').onclick = e => { const c = e.target.closest('[data-prof]'); if (c) profileSheet(c.dataset.prof); };

const SEASON_END = new Date('2026-12-31T23:59:59+01:00');
const RC = ['#f2c14e', '#4fc3f7', '#3ddc97', '#b388ff', '#ff8a65'];
let traders = [], prevPos = {};
function curve(dr, vo, n = 30) { let v = 1e4; const a = [v]; for (let i = 1; i < n; i++) { v *= 1 + dr + (rnd() - .5) * vo; a.push(v); } return a; }
function stats(t) { if (t.curve && t.curve.length > 1 && !t.fixed) { const c = t.curve; t.gain = (c[c.length - 1] / c[0] - 1) * 100; let pk = c[0], dd = 0; for (const v of c) { pk = Math.max(pk, v); dd = Math.max(dd, (pk - v) / pk * 100); } t.dd = dd; } t.gain = t.gain || 0; t.dd = t.dd || 0; t.score = Math.round(10 * (t.gain - .5 * t.dd)); t.ok = t.trades >= 10; return t; }
function badges(t) { const b = []; if (t.pos <= 3 && t.ok) b.push('Podio'); if (t.win >= 65) b.push('Francotirador'); if (t.dd < 5 && t.ok) b.push('Nervios de acero'); if (t.trades >= 150) b.push('Hiperactivo'); return b; }
const SEED = [['LoboDeWallSt', 'MT5', .006, .03], ['PipHunter', 'MT4', .004, .018], ['Carmen_FX', 'MT5', .005, .012], ['ScalperZen', 'MT5', .003, .04], ['ToroBravo', 'MT4', .007, .055], ['NoaTrades', 'MT5', .002, .01], ['Draco88', 'MT4', -.001, .03], ['GoldDigger', 'MT5', .005, .035], ['Martina.V', 'MT5', .0025, .015], ['SwingKing', 'MT4', .001, .02], ['Iker_Pips', 'MT5', .0035, .025], ['LunaCapital', 'MT5', .004, .02], ['Novato21', 'MT5', .001, .05]];
function demoLeague() { traders = SEED.map(([alias, platform, dr, vo], i) => stats({ id: 'd' + i, alias, platform, curve: curve(dr, vo), trades: i === 12 ? 6 : Math.round(20 + rnd() * 200), win: Math.round(42 + rnd() * 30) })); const m = LS.get('fr.mt'); if (m && user) traders.push(stats({ ...m, me: true, alias: user.alias })); }
function ranked() { const a = [...traders].sort((x, y) => (y.ok - x.ok) || (y.score - x.score)); a.forEach((t, i) => t.pos = i + 1); return a; }
function renderLiga() {
  const s = Math.max(0, SEASON_END - Date.now()) / 1000; $('#clock').textContent = `${Math.floor(s / 86400)} d ${Math.floor(s % 86400 / 3600)} h`;
  const all = ranked(), q = $('#q').value.trim().toLowerCase(), pf = $('#pf').value;
  $('#cta-link').hidden = all.some(t => t.me);
  const top = all.filter(t => t.ok).slice(0, 3), ord = [top[1], top[0], top[2]];
  $('#podium').innerHTML = ord.map((t, i) => t ? `<div class="step p${[2, 1, 3][i]}"><div class="who">${esc(t.alias)}</div><div class="g">${sg(t.gain, 1)} % · ${t.score}</div><div class="blk">${['II', 'I', 'III'][i]}</div></div>` : '<div></div>').join('');
  $('#rows').innerHTML = all.filter(t => (!pf || t.platform === pf) && (!q || t.alias.toLowerCase().includes(q))).map(t => {
    const p = prevPos[t.id], mv = p && p !== t.pos ? `<span class="mv ${p > t.pos ? 'u' : 'd'}">${p > t.pos ? '▲' : '▼'}${Math.abs(p - t.pos)}</span>` : '';
    return `<div class="rk ${t.me ? 'me' : ''} ${t.ok ? '' : 'out'}"><div class="pos">${t.ok ? t.pos : '–'}${mv}</div><div><b>${esc(t.alias)}</b>${t.me ? ' (tú)' : ''}<span class="tag ${t.platform === 'MT5' ? 'mt5' : ''}">${esc(t.platform)}</span><div class="badges">${t.ok ? badges(t).map(x => `<span>${esc(x)}</span>`).join('') : '<span>Sin clasificar</span>'}</div><small>DD ${dec(t.dd, 1)} % · ${Number(t.trades)} ops · ${Number(t.win)} % acierto</small></div><div class="r"><b class="${t.gain >= 0 ? 'u' : 'd'}">${sg(t.gain, 1)} %</b><small>${t.score} pts</small></div></div>`;
  }).join('') || '<p class="sub">Ningún trader coincide.</p>';
  all.forEach(t => prevPos[t.id] = t.pos);
  raceSet = all.filter(t => t.ok).slice(0, 5); drawRace();
}
const race = $('#race'); let raceSet = [];
function drawRace() {
  const W = race.clientWidth, H = race.clientHeight; if (!W) return;
  const se = raceSet.filter(t => t.curve && t.curve.length > 1).map(t => t.curve.map(v => (v / t.curve[0] - 1) * 100));
  if (!se.length) { race.innerHTML = ''; $('#legend').innerHTML = '<span>Aún no hay datos suficientes</span>'; return; }
  const n = Math.max(...se.map(s => s.length)); let lo = Math.min(0, ...se.flat()), hi = Math.max(1, ...se.flat()); const pd = (hi - lo) * .08; lo -= pd; hi += pd;
  const L = 32, R = 8, T = 8, B = 20, x = i => L + i / Math.max(1, n - 1) * (W - L - R), y = v => T + (hi - v) / (hi - lo) * (H - T - B);
  const st = Math.max(1, Math.ceil((hi - lo) / 4 / 5) * 5), ticks = []; for (let v = Math.ceil(lo / st) * st; v <= hi; v += st) ticks.push(v);
  race.innerHTML = ticks.map(v => `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)"/><text x="${L - 5}" y="${y(v) + 4}" font-size="11" text-anchor="end" fill="var(--mute)">${v}%</text>`).join('') + se.map((s, k) => `<polyline fill="none" stroke="${RC[k]}" stroke-width="${k ? 2 : 3}" stroke-linejoin="round" points="${s.map((v, i) => x(i + n - s.length).toFixed(1) + ',' + y(v).toFixed(1)).join(' ')}"/>`).join('');
  $('#legend').innerHTML = raceSet.map((t, k) => `<span><i style="background:${RC[k]}"></i>${t.pos}. ${esc(t.alias)}</span>`).join('');
}
const raceRO = new ResizeObserver(drawRace); raceRO.observe(race);
$('#q').oninput = renderLiga; $('#pf').onchange = renderLiga;
async function loadLeague() { const j = await api('/api/leaderboard'); traders = j.traders.map(t => stats({ ...t, fixed: true })); if (view === 'comunidad' && comTab === 'liga') renderLiga(); }
function leagueTick() { if (LIVE) return; for (const t of traders) if (rnd() < .5) { const c = t.curve; c[c.length - 1] *= 1 + (rnd() - .47) * .006; if (rnd() < .15) t.trades++; stats(t); } const me = traders.find(t => t.me); if (me) LS.set('fr.mt', me); if (view === 'comunidad' && comTab === 'liga') renderLiga(); }

// =============== MENTORÍAS ===============
let MENT = null, booked = new Set(LS.get('fr.book') || []), done = new Set(LS.get('fr.course') || []);
function demoMent() {
  const at = (d, h) => { const x = new Date(); x.setDate(x.getDate() + d); x.setHours(h, 0, 0, 0); return x.toISOString(); };
  MENT = { mentors: [
    { id: 'laura', name: 'Laura Méndez', role: 'Price action en oro', bio: 'Soportes, resistencias y lectura de velas en XAUUSD.', color: '#d9961b' },
    { id: 'diego', name: 'Diego Arce', role: 'Indicadores y sistemas', bio: 'Medias, RSI y MACD aplicados con reglas claras.', color: '#8a6a1c' },
    { id: 'sara', name: 'Sara Vidal', role: 'Riesgo y psicología', bio: 'Gestión del capital, diario y control emocional.', color: '#7c4dff' }],
    sessions: [
    { id: 's1', title: 'Análisis semanal de XAUUSD', mentorId: 'laura', start: at(1, 19), durationMin: 60, capacity: 50, booked: 31 },
    { id: 's2', title: 'Cómo usar el RSI sin engañarte', mentorId: 'diego', start: at(2, 19), durationMin: 45, capacity: 40, booked: 18 },
    { id: 's3', title: 'Revisión de operaciones de la liga', mentorId: 'laura', start: at(4, 20), durationMin: 75, capacity: 30, booked: 27 },
    { id: 's4', title: 'Gestión del riesgo: la regla del 1 %', mentorId: 'sara', start: at(6, 19), durationMin: 60, capacity: 60, booked: 12 }] };
  MENT.sessions.forEach(s => { s.mine = booked.has(s.id); if (s.mine) s.booked++; });
}
const COURSE = [
  { t: 'Fundamentos del oro', l: [
    ['Qué mueve al XAUUSD', 'El oro cotiza en dólares, así que un dólar fuerte suele presionarlo a la baja. También le afectan los tipos de interés reales (cuando suben, el oro, que no paga intereses, pierde atractivo) y su papel de refugio en momentos de miedo.'],
    ['Sesiones y volatilidad', 'El mayor movimiento suele darse en Londres y en el solape con Nueva York; Asia acostumbra a ser más tranquila. Los datos de EE. UU. (empleo, inflación, Reserva Federal) provocan picos de volatilidad.'],
    ['Spread, swap y contrato', 'En la mayoría de brókers 1 lote = 100 onzas: 1 $ de movimiento vale 100 $ por lote. El spread se ensancha con noticias y en el cambio de día; el swap se cobra o paga por mantener posiciones de un día a otro.']] },
  { t: 'Análisis técnico', l: [
    ['Soportes y resistencias', 'Zonas donde el precio reaccionó antes. Piensa en zonas, no en líneas exactas: cuantos más toques y más alta la temporalidad, más relevantes. Dibújalas con la herramienta Horizontal o Rectángulo del gráfico.'],
    ['Medias EMA 20, 50 y 200', 'Precio y EMA 50 por encima de la EMA 200 describen un contexto alcista (y al revés). La EMA 20 sirve de referencia para retrocesos en tendencias fuertes.'],
    ['RSI y MACD', 'RSI por encima de 70 indica sobrecompra y por debajo de 30 sobreventa, pero en tendencias fuertes puede quedarse ahí mucho tiempo. El cruce del MACD con su señal confirma cambios de impulso: úsalos para confirmar, no como única razón para entrar.'],
    ['Fibonacci', 'Traza el Fibonacci desde el inicio hasta el final de un impulso. Los retrocesos del 38,2 %, 50 % y 61,8 % son zonas que muchos traders vigilan para reincorporarse a la tendencia.']] },
  { t: 'Riesgo y psicología', l: [
    ['La regla del 1 %', 'Arriesga como máximo un porcentaje pequeño del capital en cada operación. Con un 1 % hacen falta muchas pérdidas seguidas para dañar seriamente la cuenta.'],
    ['Calcular el lotaje', 'Lotes = (capital × riesgo %) ÷ (distancia al stop en $ × 100). Ejemplo: 10.000 $, 1 % y stop a 5 $ → 100 ÷ 500 = 0,20 lotes. Tienes la calculadora en Más.'],
    ['Drawdown y diario', 'Una caída del 20 % necesita un +25 % para recuperarse; una del 50 %, un +100 %. Apunta cada operación en el diario para detectar los errores que repites.']] },
];
const upcoming = () => [...MENT.sessions].filter(s => new Date(s.start).getTime() + s.durationMin * 6e4 > Date.now()).sort((a, b) => new Date(a.start) - new Date(b.start));
const when = iso => new Date(iso).toLocaleString('es-ES', { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
const safeColor = c => /^#[0-9a-f]{3,6}$/i.test(c || '') ? c : '#0d5c45';
RENDER.mentorias = () => {
  if (!MENT) return; const mentor = id => MENT.mentors.find(m => m.id === id) || { name: '' };
  const ss = upcoming(), nx = ss[0];
  $('#next').innerHTML = nx ? `<div class="date"><b>${new Date(nx.start).getDate()}</b>${new Date(nx.start).toLocaleDateString('es-ES', { month: 'short' })}</div><div><p>Próxima sesión · ${hm(nx.start)} · ${nx.durationMin} min</p><h3>${esc(nx.title)}</h3><p>con ${esc(mentor(nx.mentorId).name)}${nx.mine && nx.link && /^https:\/\//.test(nx.link) ? ` · <a href="${esc(nx.link)}" target="_blank" rel="noopener">Entrar a la sala</a>` : ''}</p></div><button class="btn gold" data-book="${esc(nx.id)}">${nx.mine ? 'Plaza reservada ✓' : 'Reservar plaza'}</button>` : '<div><h3>No hay sesiones programadas</h3></div>';
  $('#sessions').innerHTML = ss.slice(1).map(s => `<div class="ses"><span class="when">${esc(when(s.start))}</span><h3>${esc(s.title)}</h3><span class="sub">${esc(mentor(s.mentorId).name)} · ${s.durationMin} min · ${s.booked}/${s.capacity} plazas</span><div class="meter"><i style="width:${Math.min(100, s.booked / s.capacity * 100)}%"></i></div><button class="btn ${s.mine ? 'ghost' : 'gold'} sm" data-book="${esc(s.id)}" ${!s.mine && s.booked >= s.capacity ? 'disabled' : ''}>${s.mine ? 'Reservada · cancelar' : s.booked >= s.capacity ? 'Completa' : 'Reservar plaza'}</button></div>`).join('');
  const total = COURSE.reduce((a, m) => a + m.l.length, 0); $('#prog').textContent = `${done.size}/${total} lecciones`;
  $('#course').innerHTML = COURSE.map((m, i) => { const d = m.l.filter((_, j) => done.has(i + '.' + j)).length; return `<div class="mod"><h3><span>${i + 1}. ${esc(m.t)}</span><span class="sub">${d}/${m.l.length}</span></h3><div class="meter" style="margin:10px 0"><i style="width:${d / m.l.length * 100}%"></i></div>${m.l.map(([t, x], j) => { const k = i + '.' + j, ok = done.has(k); return `<details><summary><span class="${ok ? 'ok' : ''}">${ok ? '✓' : '○'}</span>${esc(t)}</summary><p>${esc(x)}</p><button class="btn ${ok ? 'ghost' : 'gold'} sm" data-lesson="${k}">${ok ? 'Marcar como pendiente' : 'Marcar como vista'}</button></details>`; }).join('')}</div>`; }).join('');
  $('#mentors').innerHTML = MENT.mentors.map(m => `<div class="mentor"><div class="av" style="background:${safeColor(m.color)}">${esc(m.name[0])}</div><div><b>${esc(m.name)}</b><p>${esc(m.role)}</p><p>${esc(m.bio)}</p></div></div>`).join('');
};
$('#v-mentorias').addEventListener('click', async e => {
  const l = e.target.closest('[data-lesson]');
  if (l) { const k = l.dataset.lesson; done.has(k) ? done.delete(k) : done.add(k); LS.set('fr.course', [...done]); RENDER.mentorias(); const again = $(`[data-lesson="${k}"]`); if (again) again.closest('details').open = true; return; }
  const b = e.target.closest('[data-book]'); if (!b) return;
  if (!user) { toast('Entra con tu alias para reservar'); show('cuenta'); return; }
  const s = MENT.sessions.find(x => x.id === b.dataset.book);
  if (LIVE) { try { Object.assign(s, await api(`/api/mentorias/${encodeURIComponent(s.id)}/reserva`, { method: 'POST' })); } catch (x) { return toast(x.message); } }
  else { s.mine = !s.mine; s.booked += s.mine ? 1 : -1; s.mine ? booked.add(s.id) : booked.delete(s.id); LS.set('fr.book', [...booked]); }
  toast(s.mine ? 'Plaza reservada: ' + s.title : 'Reserva cancelada'); RENDER.mentorias();
});
async function loadMent() { try { MENT = await api('/api/mentorias'); } catch (e) {} }

// =============== ÚTILES ===============
function calc() {
  const bal = num($('#c-bal').value), risk = num($('#c-risk').value), en = num($('#c-in').value), sl = num($('#c-sl').value), rr = num($('#c-rr').value) || 0, out = $('#c-out');
  if (!(bal > 0 && risk > 0 && en > 0 && sl > 0) || en === sl) { out.innerHTML = '<div><span>Rellena capital, riesgo, entrada y stop</span><b>–</b></div>'; return; }
  const dist = Math.abs(en - sl), dir = sl < en ? 1 : -1, lots = Math.floor(bal * risk / 100 / (dist * 100) * 100) / 100, real = lots * dist * 100, tp = en + dir * dist * rr;
  out.innerHTML = `<div><span>${dir > 0 ? 'Compra' : 'Venta'} · tamaño de posición</span><b>${dec(lots)} lotes</b></div><div><span>Riesgo real</span><b class="d">${usd(real)}</b></div><div><span>Take profit ${dec(rr, 1)}R</span><b>${rr > 0 ? dec(tp) : '–'}</b><span>${rr > 0 ? '+' + usd(real * rr) : ''}</span></div>`;
}
['#c-bal', '#c-risk', '#c-in', '#c-sl', '#c-rr'].forEach(s => $(s).addEventListener('input', () => { calc(); LS.set('fr.calc', { bal: $('#c-bal').value, risk: $('#c-risk').value, rr: $('#c-rr').value }); }));
$('#c-now').onclick = () => { $('#c-in').value = px.XAUUSD.toFixed(2); $('#c-sl').value = (px.XAUUSD - 5).toFixed(2); calc(); };
const MK = [['Sídney', 'Australia/Sydney', 7, 16], ['Tokio', 'Asia/Tokyo', 9, 18], ['Londres', 'Europe/London', 8, 17], ['Nueva York', 'America/New_York', 8, 17]];
const FM = {};
function zt(tz, d) { const f = FM[tz] || (FM[tz] = new Intl.DateTimeFormat('en-GB', { timeZone: tz, weekday: 'short', hour: '2-digit', hourCycle: 'h23' })); const p = {}; f.formatToParts(d).forEach(x => p[x.type] = x.value); return { wd: p.weekday, h: +p.hour }; }
function fxOpen(d) { const n = zt('America/New_York', d); return !(n.wd === 'Sat' || (n.wd === 'Fri' && n.h >= 17) || (n.wd === 'Sun' && n.h < 17)); }
function mkOpen(m, d) { if (!fxOpen(d)) return false; const t = zt(m[1], d); return t.wd !== 'Sat' && t.wd !== 'Sun' && t.h >= m[2] && t.h < m[3]; }
function sessMini() { const now = new Date(); $('#sess-mini').innerHTML = MK.map(m => { const on = mkOpen(m, now); return `<div><b>${m[0]}</b><span class="${on ? 'on' : 'off'}">${on ? '● Abierta' : 'Cerrada'}</span></div>`; }).join(''); }
function sessions() {
  const now = new Date(), q = 9e5, start = Math.ceil(now / q) * q;
  $('#sess').innerHTML = MK.map(m => {
    const on = mkOpen(m, now); let t = null; for (let k = 0; k < 8 * 96; k++) { const d = new Date(start + k * q); if (mkOpen(m, d) !== on) { t = d; break; } }
    const mins = t ? Math.round((t - now) / 6e4) : 0, rel = mins < 1440 ? `${Math.floor(mins / 60)} h ${mins % 60} min` : t.toLocaleString('es-ES', { weekday: 'short', hour: '2-digit', minute: '2-digit' });
    return `<div class="mkt"><b>${m[0]}</b><span class="st ${on ? 'on' : ''}">${on ? 'Abierta' : 'Cerrada'}</span><small>${t ? (on ? 'Cierra en ' : 'Abre en ') + rel + ' · ' + hm(t) + ' tu hora' : ''}</small></div>`;
  }).join('') + `<p class="sub" style="margin:10px 0 0">${mkOpen(MK[2], now) && mkOpen(MK[3], now) ? 'Solape Londres–Nueva York activo: suele ser el momento de más movimiento del oro.' : fxOpen(now) ? 'Mercado abierto.' : 'Mercado cerrado por fin de semana.'}</p>`;
}
RENDER.utiles = () => { const c = LS.get('fr.calc'); if (c) { $('#c-bal').value = c.bal; $('#c-risk').value = c.risk; $('#c-rr').value = c.rr; } if (!$('#c-in').value) $('#c-now').click(); calc(); sessions(); };

// =============== DIARIO ===============
let journal = LS.get('fr.journal') || [], jdir = 1;
const pl = j => (j.out - j.in) * j.dir * j.lots * 100;
RENDER.diario = () => {
  const tot = journal.reduce((a, j) => a + pl(j), 0), w = journal.filter(j => pl(j) > 0).length;
  $('#j-sum').innerHTML = `<div><span>Operaciones</span><b>${journal.length}</b></div><div><span>Acierto</span><b>${journal.length ? Math.round(w / journal.length * 100) + ' %' : '–'}</b></div><div><span>Resultado</span><b class="${tot >= 0 ? 'u' : 'd'}">${usd(tot)}</b></div>`;
  $('#j-rows').innerHTML = journal.length ? journal.map((j, i) => `<div class="jr"><div><b>${j.dir > 0 ? 'Compra' : 'Venta'} ${dec(j.lots)} lotes</b><small>${new Date(j.ts).toLocaleDateString('es-ES')} · ${dec(j.in)} → ${dec(j.out)}${j.note ? ' · ' + esc(j.note) : ''}</small></div><b class="${pl(j) >= 0 ? 'u' : 'd'}">${usd(pl(j))}</b><button class="x" data-j="${i}" aria-label="Borrar">×</button></div>`).join('') : '<p class="sub">Sin operaciones. Se guardan en este dispositivo.</p>';
};
$('#j-dir').onclick = e => { const b = e.target.closest('[data-d]'); if (!b) return; jdir = +b.dataset.d; $$('#j-dir button').forEach(x => x.setAttribute('aria-pressed', x === b)); };
$('#j-f').onsubmit = e => { e.preventDefault(); const j = { ts: Date.now(), dir: jdir, in: num($('#j-in').value), out: num($('#j-out').value), lots: num($('#j-lots').value), note: $('#j-note').value.trim().slice(0, 140) }; if (!(j.in > 0 && j.out > 0 && j.lots > 0)) return toast('Rellena entrada, salida y lotes'); journal.unshift(j); LS.set('fr.journal', journal); ['#j-in', '#j-out', '#j-lots', '#j-note'].forEach(s => $(s).value = ''); RENDER.diario(); toast('Operación añadida'); };
$('#j-rows').onclick = e => { const b = e.target.closest('[data-j]'); if (!b) return; journal.splice(+b.dataset.j, 1); LS.set('fr.journal', journal); RENDER.diario(); };

// =============== CUENTA: registro, entrada, perfil y foto ===============
let authMode = 'register', recovery = false, pendingAvatar = null;
const CAM = '<svg viewBox="0 0 24 24"><path d="M9 3 7.2 5H4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-3.2L15 3zm3 15a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-2a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/></svg>';
const NORMAS = ['Respeto: nada de insultos, acoso ni discriminación.', 'Nada de spam, publicidad ni venta de señales o cursos.', 'Comparte análisis, no promesas: nadie garantiza resultados.', 'No pidas ni compartas contraseñas o datos de cuentas.', 'Los mentores pueden borrar mensajes y expulsar a quien no cumpla las normas.'];
RENDER.cuenta = () => {
  const el = $('#acct'), me = comm.me(), back = '<a class="back" href="#mas">‹ Más</a>';
  const demo = comm.mode === 'demo' ? '<div class="demo-note">Modo demo: tu perfil se guarda solo en este móvil. Cuando conectes la comunidad (Supabase), el registro será real y todos os veréis.</div>' : '';
  if (recovery) {
    el.innerHTML = back + `<div class="auth-hero"><img src="icons/logo-192.png" alt=""><h1>Nueva contraseña</h1></div><form class="card authbox" id="newpass"><label>Nueva contraseña<input id="np" type="password" minlength="8" autocomplete="new-password" required></label><p class="err" id="np-err" role="alert"></p><button class="btn gold full">Guardar contraseña</button></form>`;
    return;
  }
  if (!me) {
    const reg = authMode === 'register';
    el.innerHTML = back + `<div class="auth-hero"><img src="icons/logo-192.png" alt=""><h1>${reg ? 'Únete a la comunidad' : 'Bienvenido de nuevo'}</h1><p class="sub" style="margin:0">${reg ? 'Chat, miembros, liga y mentorías de Fortuna Radiante.' : 'Entra con tu correo y contraseña.'}</p></div>
    <div class="segm"><button type="button" data-am="register" aria-pressed="${reg}">Crear cuenta</button><button type="button" data-am="login" aria-pressed="${!reg}">Entrar</button></div>
    <form class="card authbox" id="auth" novalidate>
      ${reg ? `<button type="button" class="avpick" id="avpick" aria-label="Elegir foto de perfil">${pendingAvatar ? `<img src="${esc(pendingAvatar.url)}" alt="">` : 'Añadir<br>foto'}<span class="cam">${CAM}</span></button>
      <label>Alias (tu nombre en la comunidad)<input id="a-alias" maxlength="20" autocomplete="nickname" required></label>` : ''}
      <label>Correo electrónico<input id="a-mail" type="email" inputmode="email" autocomplete="email" required></label>
      <label>Contraseña<input id="a-pass" type="password" minlength="8" autocomplete="${reg ? 'new-password' : 'current-password'}" required></label>
      ${reg ? `<label class="check"><input type="checkbox" id="a-ok"><span>Acepto las <button type="button" class="linkb" id="normas" style="padding:0;min-height:0">normas de la comunidad</button> y que la app es informativa, no asesoramiento financiero.</span></label>` : '<button type="button" class="linkb" id="forgot">¿Has olvidado la contraseña?</button>'}
      <p class="err" id="a-err" role="alert"></p>
      <button class="btn gold full" id="a-go">${reg ? 'Crear mi cuenta' : 'Entrar'}</button>
    </form>${demo}`;
    return;
  }
  ranked(); const mt = traders.find(t => t.me);
  el.innerHTML = back + `<div class="pcard"><span class="pa" id="pa" role="button" aria-label="Cambiar foto de perfil">${avHTML(me, 84)}<span class="pcam">${CAM}</span></span><div style="min-width:0"><h2>${esc(me.alias)}</h2><span class="sub">${esc(me.email || '')}</span><br><span class="sub">Miembro desde ${new Date(me.created_at || Date.now()).toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}</span></div></div>
  <form class="card authbox" id="prof"><label>Alias<input id="p-alias" maxlength="20" value="${esc(me.alias)}" required></label><label>Sobre mí<textarea class="in2" id="p-bio" maxlength="140" placeholder="Qué operas, tu estilo…">${esc(me.bio || '')}</textarea></label><p class="err" id="p-err" role="alert"></p><button class="btn gold full">Guardar perfil</button></form>
  <h2 class="sec">Liga de trading</h2>
  ${mt ? `<div class="kpis"><div><span>Posición</span><b>${mt.ok ? mt.pos + 'º' : '–'}</b></div><div><span>Puntos</span><b>${mt.score}</b></div><div><span>Ganancia</span><b class="${mt.gain >= 0 ? 'u' : 'd'}">${sg(mt.gain, 1)} %</b></div><div><span>Drawdown máx.</span><b>${dec(mt.dd, 1)} %</b></div></div><button class="btn ghost full" id="unlink">Desvincular cuenta MetaTrader</button>`
  : `<form class="card authbox" id="link" novalidate><p class="sub" style="margin:0">Vincula tu MetaTrader con la <b>contraseña de inversor</b> (solo lectura).</p><div class="radio"><label><input type="radio" name="pl" value="MT5" checked>MetaTrader 5</label><label><input type="radio" name="pl" value="MT4">MetaTrader 4</label></div><label>Número de cuenta<input id="f-login" inputmode="numeric" required></label><label>Servidor del bróker<input id="f-server" placeholder="p. ej. ICMarketsSC-Demo" required></label><label>Contraseña de inversor<input id="f-pass" type="password" autocomplete="off" required></label><p class="err" id="f-err" role="alert"></p><ol class="lsteps" id="lsteps" hidden></ol><button class="btn gold full" id="go">Vincular y entrar en la liga</button></form>`}
  ${demo}
  <button class="btn ghost full" id="logout" style="margin-top:12px">Cerrar sesión</button>
  <button class="btn full" id="delacc" style="margin-top:10px;background:none;color:var(--dn);border:1px solid rgba(255,95,95,.4)">Eliminar mi cuenta</button>`;
};
async function pickPhoto(f) {
  if (!f || !/^image\//.test(f.type)) { toast('Elige una imagen'); return null; }
  try { return await shrink(f, 360, true); } catch (e) { toast(e.message); return null; }
}
let avatarTarget = 'profile';
$('#f-avatar').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; const blob = await pickPhoto(f); if (!blob) return;
  if (avatarTarget === 'signup') { if (pendingAvatar) URL.revokeObjectURL(pendingAvatar.url); pendingAvatar = { blob, url: URL.createObjectURL(blob) }; RENDER.cuenta(); return; }
  toast('Subiendo foto…');
  try { await comm.uploadAvatar(blob); syncUser(); RENDER.cuenta(); toast('Foto de perfil actualizada'); } catch (x) { toast(x.message); }
};
$('#acct').addEventListener('click', async e => {
  const am = e.target.closest('[data-am]'); if (am) { authMode = am.dataset.am; RENDER.cuenta(); return; }
  if (e.target.closest('#avpick')) { avatarTarget = 'signup'; $('#f-avatar').click(); return; }
  if (e.target.closest('#pa')) { avatarTarget = 'profile'; $('#f-avatar').click(); return; }
  if (e.target.id === 'normas') { sheet('Normas de la comunidad', `<ol class="steps" style="margin-bottom:14px">${NORMAS.map(n => `<li>${n}</li>`).join('')}</ol>`); return; }
  if (e.target.id === 'forgot') {
    const mail = ($('#a-mail').value || '').trim(), err = $('#a-err');
    if (!/^\S+@\S+\.\S+$/.test(mail)) { err.textContent = 'Escribe arriba tu correo y vuelve a pulsar.'; return; }
    try { await comm.resetPassword(mail); err.textContent = ''; toast('Te hemos enviado un correo para cambiar la contraseña'); } catch (x) { err.textContent = x.message; }
    return;
  }
  if (e.target.id === 'delacc') {
    const b = e.target; if (!b.dataset.sure) { b.dataset.sure = 1; b.textContent = 'Toca otra vez para borrar tu cuenta y tus mensajes'; return; }
    try { await comm.deleteAccount(); } catch (x) { return toast(x.message); }
    ['fr.mt', 'fr.journal', 'fr.book', 'fr.course'].forEach(k => LS.del(k)); traders = traders.filter(t => !t.me); journal = [];
    syncUser(); RENDER.cuenta(); toast('Cuenta eliminada'); return;
  }
  if (e.target.id === 'logout') { try { await comm.signOut(); } catch (x) {} LS.del('fr.mt'); traders = traders.filter(t => !t.me); syncUser(); authMode = 'login'; RENDER.cuenta(); toast('Sesión cerrada'); return; }
  if (e.target.id === 'unlink') { if (LIVE) { try { await api('/api/accounts/mine', { method: 'DELETE' }); await loadLeague(); } catch (x) { return toast(x.message); } } else { traders = traders.filter(t => !t.me); LS.del('fr.mt'); } toast('Cuenta desvinculada'); RENDER.cuenta(); }
});
$('#acct').addEventListener('submit', async e => {
  e.preventDefault();
  const id = e.target.id;
  if (id === 'newpass') {
    const pw = $('#np').value; if (pw.length < 8) { $('#np-err').textContent = 'Mínimo 8 caracteres.'; return; }
    try { await comm.setPassword(pw); recovery = false; toast('Contraseña cambiada'); syncUser(); RENDER.cuenta(); } catch (x) { $('#np-err').textContent = x.message; }
    return;
  }
  if (id === 'auth') {
    const err = $('#a-err'), go = $('#a-go'), mail = $('#a-mail').value.trim(), pass = $('#a-pass').value; err.textContent = '';
    if (!/^\S+@\S+\.\S+$/.test(mail)) return err.textContent = 'Escribe un correo válido.';
    if (pass.length < 8) return err.textContent = 'La contraseña necesita al menos 8 caracteres.';
    go.disabled = true;
    try {
      if (authMode === 'register') {
        const alias = $('#a-alias').value.trim();
        if (!/^[\p{L}\p{N}_.\-]{3,20}$/u.test(alias)) throw new Error('Alias de 3 a 20 caracteres: letras, números, punto o guiones.');
        if (!$('#a-ok').checked) throw new Error('Acepta las normas de la comunidad para continuar.');
        const r = await comm.signUp({ alias, email: mail, password: pass, avatar: pendingAvatar && pendingAvatar.blob });
        pendingAvatar = null;
        if (r.needsConfirm) { authMode = 'login'; RENDER.cuenta(); sheet('Revisa tu correo', `<p>Te hemos enviado un enlace a <b>${esc(mail)}</b>. Púlsalo para activar tu cuenta y después entra aquí.</p><p class="sub">Si no lo ves, mira en la carpeta de spam.</p>`); return; }
        toast('¡Bienvenido a Fortuna Radiante, ' + alias + '!');
      } else { await comm.signIn({ email: mail, password: pass }); toast('¡Hola de nuevo!'); }
      syncUser(); RENDER.cuenta();
    } catch (x) { err.textContent = x.message; go.disabled = false; }
    return;
  }
  if (id === 'prof') {
    const alias = $('#p-alias').value.trim(), bio = $('#p-bio').value.trim().slice(0, 140), err = $('#p-err'); err.textContent = '';
    if (!/^[\p{L}\p{N}_.\-]{3,20}$/u.test(alias)) return err.textContent = 'Alias de 3 a 20 caracteres: letras, números, punto o guiones.';
    try { await comm.updateProfile({ alias, bio }); syncUser(); toast('Perfil guardado'); RENDER.cuenta(); } catch (x) { err.textContent = x.message; }
    return;
  }
  if (id !== 'link') return;
  const err = $('#f-err'), login = $('#f-login').value.trim(), server = $('#f-server').value.trim(), password = $('#f-pass').value, platform = $('input[name=pl]:checked').value; err.textContent = '';
  if (!/^\d{4,12}$/.test(login)) return err.textContent = 'El número de cuenta solo lleva dígitos.';
  if (server.length < 3) return err.textContent = 'Indica el servidor exacto del bróker.';
  if (password.length < 4) return err.textContent = 'Introduce la contraseña de inversor.';
  const go = $('#go'), st = $('#lsteps'); go.disabled = true; st.hidden = false;
  const L = ['Conectando con el bróker', 'Verificando contraseña de inversor', 'Sincronizando historial', 'Calculando puntos'];
  const mark = i => st.innerHTML = L.map((t, k) => `<li class="${k < i ? 'ok' : k === i ? 'now' : ''}">${k < i ? '✓' : k === i ? '…' : '·'} ${t}</li>`).join('');
  try {
    if (LIVE) { mark(0); await api('/api/accounts', { method: 'POST', body: { login, server, password, platform } }); await loadLeague(); }
    else { for (let i = 0; i < 4; i++) { mark(i); await wait(600); } const me = stats({ id: 'me', me: true, alias: user.alias, platform, server, loginMasked: '•••' + login.slice(-3), curve: curve(.004, .022), trades: Math.round(12 + rnd() * 80), win: Math.round(45 + rnd() * 25) }); traders = traders.filter(t => !t.me); traders.push(me); LS.set('fr.mt', me); }
    toast('Cuenta vinculada. ¡Ya estás en la liga!'); RENDER.cuenta();
  } catch (x) { err.textContent = x.message; st.hidden = true; go.disabled = false; $('#f-pass').value = ''; }
});
comm.onAuth(ev => { if (ev === 'recovery') { recovery = true; show('cuenta'); } syncUser(); loadAlerts(); if (view === 'cuenta') RENDER.cuenta(); if (view === 'comunidad') RENDER.comunidad(); });

// =============== NOTIFICACIONES Y ALERTAS DE PRECIO ===============
const VAPID = String(window.FR_VAPID_PUBLIC || '');
const isCap = !!window.Capacitor, isIOS = /iPhone|iPad|iPod/.test(navigator.userAgent);
const standalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
const capPush = () => { try { return isCap && window.Capacitor.isPluginAvailable && window.Capacitor.isPluginAvailable('PushNotifications') ? window.Capacitor.Plugins.PushNotifications : null; } catch (e) { return null; } };
const pushOK = () => !isCap && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
const b64u = s => { const p = '='.repeat((4 - s.length % 4) % 4), b = atob((s + p).replace(/-/g, '+').replace(/_/g, '/')); return Uint8Array.from(b, c => c.charCodeAt(0)); };
const swReady = () => Promise.race([navigator.serviceWorker.ready, wait(6000).then(() => null)]);
async function currentSub() { if (!pushOK()) return null; const reg = await swReady(); return reg ? reg.pushManager.getSubscription() : null; }
async function loadAlerts() { try { ALERTS = await comm.alerts(); } catch (e) { ALERTS = []; } if (view === 'avisos') RENDER.avisos(); }
async function enableCapPush() {
  const P = capPush(); if (!P) throw new Error('Instala el APK nuevo');
  if (!comm.me()) throw new Error('Entra en tu cuenta primero');
  let perm = await P.checkPermissions(); if (perm.receive !== 'granted') perm = await P.requestPermissions();
  if (perm.receive !== 'granted') throw new Error('No has dado permiso para las notificaciones');
  try { await P.createChannel({ id: 'avisos', name: 'Avisos de Fortuna Radiante', importance: 4, visibility: 1, lights: true, vibration: true }); } catch (e) {}
  const token = await new Promise((ok, ko) => {
    const t = setTimeout(() => ko(new Error('Firebase no responde. Revisa la configuración (google-services.json).')), 20000);
    P.addListener('registration', r => { clearTimeout(t); ok(r.value); });
    P.addListener('registrationError', er => { clearTimeout(t); ko(new Error('Error de Firebase: ' + (er && er.error || ''))); });
    P.register().catch(er => { clearTimeout(t); ko(er); });
  });
  await comm.savePush({ endpoint: 'fcm:' + token, p256dh: 'fcm', auth: 'fcm', chat_pref: 'mentions' });
  return token;
}
if (capPush()) { try { capPush().addListener('pushNotificationActionPerformed', a => { const u = a && a.notification && a.notification.data && a.notification.data.url; if (u) show(String(u).replace('#', '')); }); capPush().addListener('pushNotificationReceived', n => { if (n && n.title) toast(n.title + (n.body ? ' · ' + n.body : '')); }); } catch (e) {} }
const PREFS = [['all', 'Todos los mensajes'], ['mentions', 'Solo cuando me mencionan'], ['none', 'Ninguno del chat']];
RENDER.avisos = async () => {
  const box = $('#av-push'), me = comm.me();
  let html = '';
  if (comm.mode === 'demo') html = '<p class="sub" style="margin:0">Las notificaciones en el móvil funcionan cuando la comunidad está conectada (Supabase). Las alertas de precio de abajo sí avisan mientras la app está abierta.</p>';
  else if (!me) html = '<p class="sub" style="margin:0 0 10px">Entra en tu cuenta para activar las notificaciones.</p><button class="btn gold full" data-go="cuenta">Entrar o crear cuenta</button>';
  else if (isCap && !capPush()) html = '<p style="margin:0 0 8px"><b>Instala el APK nuevo para activar las notificaciones.</b></p><p class="sub" style="margin:0">Descárgalo en GitHub → Actions → «Android · instalador APK» → Artifacts e instálalo encima de esta app. Mientras tanto, te avisa dentro de la app cuando la tienes abierta.</p>';
  else if (isCap) {
    const tok = LS.get('fr.fcm');
    if (tok) {
      let pref = 'mentions'; try { pref = (await comm.pushPref('fcm:' + tok)) || pref; } catch (e) {}
      html = `<p style="margin:0 0 10px"><b class="u">● Notificaciones activadas en este móvil</b></p><div class="lbl" style="margin-bottom:6px">Avisos del chat</div><div class="list">${PREFS.map(([k, l]) => `<button class="opt" data-pref="${k}" aria-pressed="${k === pref}" style="padding:10px 12px"><span>${l}</span>${k === pref ? '<span class="u">✓</span>' : ''}</button>`).join('')}</div><p class="sub">Las alertas de precio siempre te avisan.</p><button class="btn ghost full" id="av-off">Desactivar</button>`;
    } else html = `<p style="margin:0 0 12px">Recibe un aviso aunque tengas la app cerrada cuando te mencionen en el chat o se cumpla una alerta de precio.</p><button class="btn gold full" id="av-on">Activar notificaciones</button>`;
  }
  else if (isIOS && !standalone()) html = '<p style="margin:0 0 8px"><b>En iPhone, primero instala la app desde Safari.</b></p><p class="sub" style="margin:0">Compartir → Añadir a pantalla de inicio. Ábrela desde el icono y vuelve aquí para activarlas (iOS 16.4 o superior).</p>';
  else if (!pushOK()) html = '<p class="sub" style="margin:0">Este navegador no admite notificaciones. Prueba con Chrome o Safari.</p>';
  else if (!VAPID) html = '<p class="sub" style="margin:0">Falta configurar las notificaciones en la app (clave VAPID).</p>';
  else if (Notification.permission === 'denied') html = '<p style="margin:0 0 8px"><b>Has bloqueado las notificaciones.</b></p><p class="sub" style="margin:0">Actívalas en los ajustes del móvil: Ajustes → Notificaciones → Fortuna Radiante (o en los permisos del navegador) y vuelve aquí.</p>';
  else {
    const sub = await currentSub();
    if (sub) {
      let pref = 'mentions'; try { pref = (await comm.pushPref(sub.endpoint)) || pref; } catch (e) {}
      html = `<p style="margin:0 0 10px"><b class="u">● Notificaciones activadas en este móvil</b></p><div class="lbl" style="margin-bottom:6px">Avisos del chat</div><div class="list" id="av-pref">${PREFS.map(([k, l]) => `<button class="opt" data-pref="${k}" aria-pressed="${k === pref}" style="padding:10px 12px"><span>${l}</span>${k === pref ? '<span class="u">✓</span>' : ''}</button>`).join('')}</div><p class="sub">Las alertas de precio siempre te avisan.</p><div class="grid2" style="margin-top:10px"><button class="btn ghost" id="av-test">Probar</button><button class="btn ghost" id="av-off">Desactivar</button></div>`;
    } else html = `<p style="margin:0 0 12px">Recibe un aviso aunque tengas la app cerrada cuando te mencionen en el chat o se cumpla una alerta de precio.</p><button class="btn gold full" id="av-on">Activar notificaciones</button>`;
  }
  box.innerHTML = html;
  // alertas
  const sel = $('#al-sym'); if (!sel.options.length) sel.innerHTML = ORDER.map(s => `<option value="${s}">${s} · ${SY[s].n}</option>`).join('');
  if (!$('#al-price').value) $('#al-price').value = px[sel.value] != null ? px[sel.value].toFixed(SY[sel.value].d) : '';
  const act = ALERTS.filter(x => x.active), done = ALERTS.filter(x => !x.active).slice(0, 5);
  $('#al-list').innerHTML = (act.length ? act.map(x => `<div class="jr"><div><b>${esc(x.symbol)} ${x.above ? '▲ si sube a' : '▼ si baja a'} ${dec(x.price, (SY[x.symbol] || { d: 2 }).d)}</b><small>Ahora: ${px[x.symbol] != null ? dec(px[x.symbol], SY[x.symbol].d) : '—'}</small></div><span></span><button class="x" data-al="${esc(x.id)}" aria-label="Borrar alerta">×</button></div>`).join('') : '<p class="sub">No tienes alertas activas.</p>')
    + (done.length ? '<h3 class="sec" style="font-size:15px">Cumplidas</h3>' + done.map(x => `<div class="jr" style="opacity:.6"><div><b>${esc(x.symbol)} ${dec(x.price, (SY[x.symbol] || { d: 2 }).d)}</b><small>${x.triggered_at ? new Date(x.triggered_at).toLocaleString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : ''}</small></div><span class="u">✓</span><button class="x" data-al="${esc(x.id)}" aria-label="Borrar">×</button></div>`).join('') : '');
};
$('#al-sym').onchange = () => { const s = $('#al-sym').value; $('#al-price').value = px[s] != null ? px[s].toFixed(SY[s].d) : ''; };
$('#al-f').onsubmit = async e => {
  e.preventDefault();
  if (comm.mode === 'online' && !comm.me()) { toast('Entra en tu cuenta para guardar alertas'); show('cuenta'); return; }
  const s = $('#al-sym').value, price = num($('#al-price').value), now = px[s];
  if (!(price > 0)) return toast('Escribe un precio');
  if (now != null && Math.abs(price - now) < 10 ** -SY[s].d) return toast('Ese es el precio actual: elige otro');
  try { const al = { active: true, ...(await comm.addAlert({ symbol: s, price, above: now == null ? true : price > now })) }; ALERTS.unshift(al); toast(`Alerta creada: ${s} ${al.above ? 'sube a' : 'baja a'} ${dec(price, SY[s].d)}`); RENDER.avisos(); } catch (x) { toast(x.message); }
};
$('#v-avisos').addEventListener('click', async e => {
  const d = e.target.closest('[data-al]');
  if (d) { const id = isNaN(+d.dataset.al) ? d.dataset.al : +d.dataset.al; try { await comm.delAlert(id); ALERTS = ALERTS.filter(x => x.id !== id); RENDER.avisos(); } catch (x) { toast(x.message); } return; }
  if (e.target.id === 'av-on' && isCap) {
    const b = e.target; b.disabled = true; b.textContent = 'Activando…';
    try { const tok = await enableCapPush(); LS.set('fr.fcm', tok); toast('Notificaciones activadas ✓'); } catch (x) { toast(x.message || 'No se pudieron activar'); }
    RENDER.avisos(); return;
  }
  if (e.target.id === 'av-on') {
    const b = e.target; b.disabled = true; b.textContent = 'Activando…';
    try {
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') throw new Error('No has dado permiso para las notificaciones');
      const reg = await swReady(); if (!reg) throw new Error('La app aún se está instalando. Ciérrala, ábrela otra vez y repite.');
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64u(VAPID) });
      const j = sub.toJSON(); await comm.savePush({ endpoint: j.endpoint, p256dh: j.keys.p256dh, auth: j.keys.auth, chat_pref: 'mentions' });
      toast('Notificaciones activadas ✓');
    } catch (x) { toast(x.message || 'No se pudieron activar'); }
    RENDER.avisos(); return;
  }
  const p = e.target.closest('[data-pref]');
  if (p && isCap) { const tok = LS.get('fr.fcm'); if (!tok) return; try { await comm.savePush({ endpoint: 'fcm:' + tok, p256dh: 'fcm', auth: 'fcm', chat_pref: p.dataset.pref }); toast('Guardado'); } catch (x) { toast(x.message); } RENDER.avisos(); return; }
  if (p) { const sub = await currentSub(); if (!sub) return; const j = sub.toJSON(); try { await comm.savePush({ endpoint: j.endpoint, p256dh: j.keys.p256dh, auth: j.keys.auth, chat_pref: p.dataset.pref }); toast('Guardado'); } catch (x) { toast(x.message); } RENDER.avisos(); return; }
  if (e.target.id === 'av-test') { const reg = await swReady(); if (reg) reg.showNotification('Fortuna Radiante', { body: 'Así verás tus avisos de chat y alertas de precio ✨', icon: 'icons/icon-192.png', badge: 'icons/logo-96.png' }); return; }
  if (e.target.id === 'av-off' && isCap) { const tok = LS.get('fr.fcm'); if (tok) { try { await comm.deletePush('fcm:' + tok); } catch (x) {} } try { await capPush().unregister(); } catch (x) {} LS.del('fr.fcm'); toast('Notificaciones desactivadas'); RENDER.avisos(); return; }
  if (e.target.id === 'av-off') { const sub = await currentSub(); if (sub) { try { await comm.deletePush(sub.endpoint); } catch (x) {} await sub.unsubscribe(); } toast('Notificaciones desactivadas'); RENDER.avisos(); }
});

// =============== INSTALAR (PWA) ===============
let installEvt = null;
addEventListener('beforeinstallprompt', e => { e.preventDefault(); installEvt = e; $('#inst-btn').hidden = false; });
$('#inst-btn').onclick = async () => { if (!installEvt) return; installEvt.prompt(); try { await installEvt.userChoice; } catch (e) {} installEvt = null; $('#inst-btn').hidden = true; };
try { if (!window.Capacitor && 'serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost') && !/claude\.ai|claudeusercontent/.test(location.hostname)) navigator.serviceWorker.register('sw.js').catch(() => {}); } catch (e) {}

// =============== arranque ===============
setTimeout(() => { const sp = $('#splash'); sp.classList.add('out'); setTimeout(() => sp.remove(), 700); }, reduce ? 300 : 1400);
syncUser();
initRefs(); demoLeague(); demoMent(); buildTicker(); requestAnimationFrame(tkLoop);
comm.init().then(() => { syncUser(); loadAlerts(); feedPoll(); if (['comunidad', 'cuenta', 'avisos'].includes(view)) RENDER[view](); }).catch(e => toast('Comunidad: ' + e.message));
if (comm.mode === 'demo') loadAlerts();
setInterval(feedPoll, 2000);
setInterval(resyncCandles, 60000);
show(location.hash.slice(1) || 'inicio');
getSampler().then(s => { if (!FT.mode && !(LIVE && FEAT.ai)) { FT.mode = s ? 'sample' : 'offline'; if (view === 'fortunaty') renderFT(); } });

let tickN = 0;
function demoTick() {
  if (!(LIVE && FEAT.prices)) ORDER.forEach(s => { if (!isReal(s)) { applyPrice(s, px[s] * (1 + (rnd() - .5) * 2 * SY[s].v * .7)); checkAlerts(s); } });
  updTicker(); tickN++;
  if (view === 'inicio') { renderHero(); if (tickN % 3 === 0) renderMarkets(); }
  if (view === 'grafico') panes.forEach(p => { const c = LAY.panes[p.i], k = c.sym + '|' + c.tf; if (series[k]) { p.chart.setExtra(extraFor(c, p.chart.getInd()), true); p.chart.setData(series[k], null, null, true); legend(p, null); indEvents(p); } paneHead(p); });
}
setInterval(demoTick, 1000);
setInterval(leagueTick, 3000);
setInterval(() => { if (view === 'inicio') { renderPulse(); sessMini(); } if (view === 'utiles') sessions(); }, 30000);

fetch(API + '/api/health').then(r => r.ok ? r.json() : null).then(async j => {
  if (!j || !j.ok) return;
  LIVE = true; FEAT = j.features || {}; $('#mode').textContent = 'En directo';
  FT.mode = null;
  if (FEAT.candles) { for (const k in series) delete series[k]; await Promise.all(ORDER.map(s => getSeries(s, 15))); ORDER.forEach(s => { const a = series[s + '|15']; if (a && a.length) { px[s] = a[a.length - 1].close; ref[s] = a[Math.max(0, a.length - 97)].close; } }); await Promise.all([60, 240, 1440].map(m => getSeries('XAUUSD', m))); }
  if (FEAT.prices) { const poll = async () => { try { const p = await api('/api/prices'); for (const s in p.prices) if (SY[s] && p.prices[s]) applyPrice(s, (p.prices[s].bid + p.prices[s].ask) / 2); } catch (e) {} }; await poll(); setInterval(poll, 2000); }
  await Promise.all([loadLeague().catch(() => {}), loadMent()]);
  show(view);
  setInterval(() => loadLeague().catch(() => {}), 60000);
}).catch(() => {});
}
