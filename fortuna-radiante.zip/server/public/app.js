// Fortuna Radiante — app móvil para traders.
// Sin servidor: modo demo (precios simulados; Fortunaty usa la IA de la vista previa si está disponible).
// Servida por server.js: precios reales, Fortunaty con noticias, chat, liga y mentorías compartidos.
{
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = s => parseFloat(String(s ?? '').replace(/\s/g, '').replace(',', '.'));
const dec = (n, d = 2) => Number(n).toLocaleString('es-ES', { minimumFractionDigits: d, maximumFractionDigits: d });
const sg = (n, d = 2) => (n > 0 ? '+' : n < 0 ? '−' : '') + dec(Math.abs(n), d);
const usd = n => (n < 0 ? '−' : '') + dec(Math.abs(n)) + ' $';
const hm = t => new Date(t).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
const r2 = (n, d = 2) => n == null || !isFinite(n) ? null : Math.round(n * 10 ** d) / 10 ** d;
const wait = ms => new Promise(r => setTimeout(r, ms));
const LS = { get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }, del(k) { try { localStorage.removeItem(k); } catch (e) {} } };
let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;

let LIVE = false, FEAT = {}, token = LS.get('fr.token'), user = LS.get('fr.user'), view = 'inicio';
// En la app instalada (Android/iPhone) las llamadas van al servidor indicado en config.js
const API = String(window.FR_API || '').replace(/\/$/, '');
async function api(path, opt = {}) {
  const r = await fetch(API + path, { ...opt, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: opt.body ? JSON.stringify(opt.body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Error ' + r.status);
  return j;
}
function toast(t) { $('#toasts').innerHTML = ''; const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; $('#toasts').append(d); setTimeout(() => d.remove(), 3000); }
function setUser(u, t) { user = u || null; if (t !== undefined) token = t || null; u ? LS.set('fr.user', u) : LS.del('fr.user'); token ? LS.set('fr.token', token) : LS.del('fr.token'); $('#mebtn').innerHTML = u ? avHTML(u, 38) : '?'; }

// =============== navegación ===============
const TAB = { inicio: 'inicio', grafico: 'grafico', fortunaty: 'fortunaty', comunidad: 'comunidad', mas: 'mas', mentorias: 'mas', utiles: 'mas', diario: 'mas', cuenta: 'mas', instalar: 'mas', avisos: 'mas', admin: 'mas', mercado: 'mercado', acceso: 'x', bloqueado: 'x', accesos: 'mas', senales: 'senales', roles: 'mas', noticias: 'mercado' };
const RENDER = {}; let WANT = null;
if (!LS.get('fr.indoff1')) { for (let i = 0; i < 3; i++) { const v = LS.get('fr.ind.' + i); if (v) { Object.keys(v).forEach(k => { if (v[k] && typeof v[k] === 'object') v[k].on = false; }); LS.set('fr.ind.' + i, v); } } LS.set('fr.indoff1', 1); }
function show(v) {
  if (!TAB[v]) v = 'inicio';
  let tabOf = TAB[v]; const req = v;
  if (typeof gate === 'function') {
    const g = gate();
    if (g === 'login') { if (v !== 'cuenta') v = 'cuenta'; }
    else if (g !== 'ok') v = 'acceso';
    else if (v === 'acceso') v = 'inicio';
    else if (VIEW_SEC[v] && !canSec(VIEW_SEC[v])) { blockedSec = VIEW_SEC[v]; v = 'bloqueado'; }
    tabOf = TAB[v] === 'x' ? tabOf : TAB[v];
    WANT = v === req ? null : req;
  }
  view = v;
  $$('.view').forEach(s => s.hidden = s.id !== 'v-' + v);
  $$('.tabbar a').forEach(a => a.dataset.t === tabOf ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'));
  if (v !== 'grafico') $('#app').classList.remove('full');
  $('#main').scrollTop = 0;
  RENDER[v] && RENDER[v]();
  if (v === req && location.hash !== '#' + v) try { history.replaceState(null, '', '#' + v); } catch (e) {}
}
addEventListener('hashchange', () => { const h = location.hash.slice(1); if (h && h !== view) show(h); });
document.addEventListener('click', e => {
  const g = e.target.closest('[data-go]'); if (g) { e.preventDefault(); show(g.dataset.go); return; }
  const c = e.target.closest('[data-chart]'); if (c) { e.preventDefault(); openChart(c.dataset.chart); return; }
  const a = e.target.closest('[data-ask]'); if (a) { e.preventDefault(); show('fortunaty'); if (canSec('fortunaty')) ask(a.dataset.ask); return; }
  const t = e.target.closest('[data-tab]'); if (t) { comTab = t.dataset.tab; }
});

// hoja inferior
function sheet(title, html, bind) { $('#sheet-t').textContent = title; $('#sheet-c').innerHTML = html; $('#sheet').hidden = $('#sheet-bg').hidden = false; bind && bind($('#sheet-c')); }
function closeSheet() { $('#sheet').hidden = $('#sheet-bg').hidden = true; }
$('#sheet-bg').onclick = closeSheet;
addEventListener('keydown', e => { if (e.key === 'Escape') closeSheet(); });

// =============== mercados ===============
const SY = {
  XAUUSD: { n: 'Oro', d: 2, p: 4000, v: .00035, ic: 'Au', cls: '' },
  DXY: { n: 'Índice dólar', d: 3, p: 100.2, v: .00007, ic: 'DXY', cls: 'dxy' },
  BTCUSD: { n: 'Bitcoin', d: 1, p: 95000, v: .0009, ic: '₿', cls: 'btc' },
  USOIL: { n: 'Petróleo WTI', d: 2, p: 65, v: .0005, ic: 'WTI', cls: 'oil' },
};
const ORDER = Object.keys(SY);
// mercados visibles: los 4 principales siempre; los extra solo si llegan precios reales del bróker
const VIS = () => ORDER;
const TFS = [['1m', 1], ['5m', 5], ['15m', 15], ['1H', 60], ['4H', 240], ['1D', 1440]];
const tfLabel = m => (TFS.find(t => t[1] === m) || ['1H'])[0];
const apiTf = m => ({ 1: '1m', 5: '5m', 15: '15m', 60: '1h', 240: '4h', 1440: '1d' }[m]);
const px = {}, ref = {}, series = {};
// ---------- precios reales de Vantage: el robot de MT5 los guarda en Supabase y la app los lee ----------
const FEED = { real: new Set(), fresh: false, ts: {}, pending: {} };
const isReal = s => FEED.real.has(s);
let ALERTS = [];
let MODE_TXT = null;
function modeBadge() { let b = 'Beta'; try { b = CFG.badge || 'Beta'; } catch (e) {} $('#mode').textContent = MODE_TXT || b; }
function afterRealData(s) {
  const a = series[s + '|15']; if (a && a.length) ref[s] = a[Math.max(0, a.length - 97)].close;
  if (view === 'inicio') { renderHero(); renderMarkets(); renderPulse(); }
}
function checkAlerts(s) {
  const p = px[s]; if (p == null) return;
  for (const al of ALERTS) {
    if (!al.active || al.symbol !== s) continue;
    if ((al.above && p >= al.price) || (!al.above && p <= al.price)) {
      al.active = false; al.triggered_at = new Date().toISOString();
      toast(`🔔 ${s} ${al.above ? 'ha subido a' : 'ha bajado a'} ${dec(al.price, SY[s].d)}`);
      if (navigator.vibrate) try { navigator.vibrate([60, 40, 60]); } catch (e) {}
      if (comm.mode === 'demo') LS.set('fr.alerts', ALERTS);
      if (view === 'avisos') RENDER.avisos();
    }
  }
}
async function feedPoll() {
  if (comm.mode !== 'online' || !comm.prices || document.hidden) return;
  let rows; try { rows = await comm.prices(); } catch (e) { return; }
  const now = Date.now(), nuevos = []; let fresh = false;
  for (const r of rows) {
    if (!SY[r.symbol] || !(r.bid > 0)) continue;
    if (!isReal(r.symbol)) { FEED.real.add(r.symbol); nuevos.push(r.symbol); }
    if (now - new Date(r.ts).getTime() < 120e3) fresh = true;
    if (FEED.ts[r.symbol] !== r.ts || px[r.symbol] !== +r.bid) { FEED.ts[r.symbol] = r.ts; applyPrice(r.symbol, +r.bid); checkAlerts(r.symbol); }
  }
  FEED.fresh = fresh;
  MODE_TXT = fresh ? 'Vantage' : FEED.real.size ? 'Cerrado' : (LIVE ? 'En directo' : null); modeBadge();
  if (nuevos.length) {
    nuevos.forEach(s => { for (const k in series) if (k.startsWith(s + '|')) delete series[k]; delete ref[s]; });
    await Promise.all(nuevos.map(s => getSeries(s, 15)));
    nuevos.forEach(afterRealData); buildTicker();
    if (view === 'grafico') loadAll(); else if (RENDER[view]) RENDER[view]();
  }
}
async function resyncCandles() {
  if (!FEED.real.size || document.hidden || !comm.candles) return;
  for (const k of Object.keys(series)) {
    const [s, m] = k.split('|'); if (!isReal(s)) continue;
    try { const rows = await comm.candles(s, +m); if (rows.length) series[k] = rows.map(r => ({ time: r.t * 1000, open: +r.o, high: +r.h, low: +r.l, close: +r.c, vol: +r.v || 0 })); } catch (e) {}
  }
}
ORDER.forEach(s => { px[s] = SY[s].p * (1 + (rnd() - .5) * .01); });
function gen(s, m, n = 500) {
  const step = m * 6e4, vol = SY[s].v * Math.sqrt(m), out = new Array(n); let c = px[s], t = Math.floor(Date.now() / step) * step, drift = 0;
  for (let i = n - 1; i >= 0; i--) {
    if ((n - 1 - i) % 45 === 0) drift = (rnd() - .5) * vol * .35;
    const o = c / (1 + drift + (rnd() - .5) * 2 * vol);
    out[i] = { time: t, open: o, high: Math.max(o, c) * (1 + rnd() * vol * .6), low: Math.min(o, c) * (1 - rnd() * vol * .6), close: c, vol: Math.round(m * 40 * (.4 + rnd() * 1.4 + Math.abs(c - o) / (o * vol || 1) * .6)) };
    c = o; t -= step;
  }
  return out;
}
function seriesSync(s, m) {
  const k = s + '|' + m;
  if (!series[k]) {
    if (isReal(s)) { if (!FEED.pending[k]) { FEED.pending[k] = 1; getSeries(s, m).then(() => { delete FEED.pending[k]; afterRealData(s); }); } return null; }
    if (!(LIVE && FEAT.candles)) series[k] = gen(s, m);
  }
  return series[k];
}
async function getSeries(s, m) {
  const k = s + '|' + m;
  if (isReal(s) && !series[k] && comm.candles) { try { const rows = await comm.candles(s, m); if (rows.length) series[k] = rows.map(r => ({ time: r.t * 1000, open: +r.o, high: +r.h, low: +r.l, close: +r.c, vol: +r.v || 0 })); } catch (e) { console.warn(e); } }
  if (LIVE && FEAT.candles && !series[k]) { try { const j = await api(`/api/candles?symbol=${s}&tf=${apiTf(m)}`); if (j.candles && j.candles.length) series[k] = j.candles.map(c => ({ time: +c.time, open: +c.open, high: +c.high, low: +c.low, close: +c.close })); } catch (e) { console.warn(e); } }
  return series[k] || (series[k] = gen(s, m));
}
function applyPrice(s, p) {
  const old = px[s]; px[s] = p;
  for (const k in series) {
    const [ks, km] = k.split('|'); if (ks !== s) continue;
    const a = series[k], step = km * 6e4, l = a[a.length - 1]; if (!l) continue;
    if (Date.now() >= l.time + step) { a.push({ time: Math.floor(Date.now() / step) * step, open: l.close, high: p, low: p, close: p, vol: 1 }); if (a.length > 1500) a.shift(); }
    else { l.close = p; l.high = Math.max(l.high, p); l.low = Math.min(l.low, p); if (l.vol != null) l.vol += 1; }
  }
  return old;
}
function initRefs() { ORDER.forEach(s => { const a = seriesSync(s, 15); if (a && a.length) ref[s] = a[Math.max(0, a.length - 97)].close; }); }
const chg = s => ref[s] ? (px[s] / ref[s] - 1) * 100 : 0;

// cinta deslizante
const track = $('#tk-track'), tk = $('#ticker');
function buildTicker() {
  const item = s => `<button class="tk" data-chart="${s}"><b>${s === 'BTCUSD' ? 'BTC' : s === 'ETHUSD' ? 'ETH' : s}</b><small class="sim" data-sim="${s}" hidden>sim</small><span class="p" data-p="${s}"></span><span class="c" data-c="${s}"></span></button>`;
  const one = VIS().map(item).join(''); track.innerHTML = one + one + one;
  updTicker();
}
const lastShown = {};
function updTicker() {
  ORDER.forEach(s => {
    const p = px[s], c = chg(s), dir = lastShown[s] == null ? '' : p > lastShown[s] ? 'fu' : p < lastShown[s] ? 'fd' : '';
    $$(`[data-p="${s}"]`).forEach(el => { el.textContent = p == null ? '—' : dec(p, SY[s].d); if (dir) { el.classList.remove('fu', 'fd'); void el.offsetWidth; el.classList.add(dir); } });
    $$(`[data-c="${s}"]`).forEach(el => { el.textContent = (c >= 0 ? '▲ ' : '▼ ') + dec(Math.abs(c)) + ' %'; el.className = 'c ' + (c >= 0 ? 'u' : 'd'); });
    lastShown[s] = p;
    $$(`[data-sim="${s}"]`).forEach(el => el.hidden = !(FEED.real.size && !isReal(s)));
  });
}
let tkPos = 0, tkHold = 0, tkLast = 0;
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
function tkLoop(t) {
  const dt = Math.min(64, t - (tkLast || t)); tkLast = t;
  if (!reduce && Date.now() > tkHold && !$('#app').classList.contains('full')) {
    tkPos += dt * .035; const third = track.scrollWidth / 3;
    if (third && tkPos >= third * 2) tkPos -= third;
    tk.scrollLeft = tkPos;
  }
  requestAnimationFrame(tkLoop);
}
['pointerdown', 'touchstart', 'wheel'].forEach(ev => tk.addEventListener(ev, () => { tkHold = Date.now() + 3000; }, { passive: true }));
tk.addEventListener('scroll', () => { if (Date.now() <= tkHold) { tkPos = tk.scrollLeft; const third = track.scrollWidth / 3; if (tkPos < third * .5) { tkPos += third; tk.scrollLeft = tkPos; } else if (tkPos > third * 2.2) { tkPos -= third; tk.scrollLeft = tkPos; } } }, { passive: true });

// =============== INICIO ===============
function sparkPath(a, W, H, pad = 4) { const lo = Math.min(...a), hi = Math.max(...a), k = hi - lo || 1; return a.map((v, i) => `${(i / (a.length - 1) * W).toFixed(1)},${(pad + (hi - v) / k * (H - pad * 2)).toFixed(1)}`); }
function drawRays() { const g = $('#raysg'); if (!g) return; if (g.childElementCount) return; let h = ''; for (let i = 0; i < 24; i++) { const a = i / 24 * Math.PI * 2, b = a + .045; h += `<polygon points="200,200 ${200 + 260 * Math.cos(a)},${200 + 260 * Math.sin(a)} ${200 + 260 * Math.cos(b)},${200 + 260 * Math.sin(b)}" fill="url(#gg)" opacity="${i % 2 ? .25 : .5}"/>`; } g.innerHTML = h + '<circle cx="200" cy="200" r="46" fill="url(#gg)" opacity=".55"/>'; }
function renderHero() {
  const a = seriesSync('XAUUSD', 15); if (!a || !a.length) return;
  const d = a.slice(-96), c = chg('XAUUSD');
  $('#h-price').textContent = dec(px.XAUUSD, 2);
  $('.hero .eyebrow').textContent = 'Oro · XAUUSD' + (isReal('XAUUSD') ? (FEED.fresh ? ' · Vantage en directo' : ' · Vantage · mercado cerrado') : ' · demo');
  const pc = $('#h-chg'); pc.textContent = (c >= 0 ? '▲ ' : '▼ ') + dec(Math.abs(c)) + ' % hoy'; pc.className = 'pill ' + (c >= 0 ? 'u' : 'd');
  $('#h-range').textContent = `Rango 24 h ${dec(Math.min(...d.map(x => x.low)))} – ${dec(Math.max(...d.map(x => x.high)))}`;
  const sv = $('#h-spark'), W = sv.clientWidth || 340, H = 84, pts = sparkPath(d.map(x => x.close), W, H);
  sv.setAttribute('viewBox', `0 0 ${W} ${H}`);
  sv.innerHTML = `<defs><linearGradient id="hf" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f5c84c" stop-opacity=".45"/><stop offset="1" stop-color="#f5c84c" stop-opacity="0"/></linearGradient></defs><polygon points="0,${H} ${pts.join(' ')} ${W},${H}" fill="url(#hf)"/><polyline points="${pts.join(' ')}" fill="none" stroke="url(#gg)" stroke-width="2.5" stroke-linejoin="round"/><circle cx="${pts[pts.length - 1].split(',')[0]}" cy="${pts[pts.length - 1].split(',')[1]}" r="4.5" fill="#fff0b8"/>`;
}
function renderMarkets() {
  $('#markets').innerHTML = VIS().map(s => {
    const a = (seriesSync(s, 15) || []).slice(-48), c = chg(s), pts = a.length > 1 ? sparkPath(a.map(x => x.close), 72, 32, 3) : [];
    return `<button class="mk" data-chart="${s}"><span class="ic ${SY[s].cls}">${esc(SY[s].ic)}</span><span><b>${SY[s].n}</b><small>${s}${FEED.real.size && !isReal(s) ? ' · simulado' : isReal(s) ? ' · Vantage' : ''}</small></span><svg viewBox="0 0 72 32"><polyline points="${pts.join(' ')}" fill="none" stroke="${c >= 0 ? 'var(--up)' : 'var(--dn)'}" stroke-width="1.8"/></svg><span class="r"><b>${px[s] == null ? '—' : dec(px[s], SY[s].d)}</b><span class="pill ${c >= 0 ? 'u' : 'd'}">${sg(c)} %</span></span></button>`;
  }).join('');
}
function quickRead(a) {
  if (!a) return [];
  const t = a.close > a.ema200 && a.ema50 > a.ema200 ? ['Alcista', 'u'] : a.close < a.ema200 && a.ema50 < a.ema200 ? ['Bajista', 'd'] : ['Lateral', ''];
  const res = Math.min(...[a.pivots.R1, a.swingHigh50].filter(v => v > a.close)), sup = Math.max(...[a.pivots.S1, a.swingLow50].filter(v => v < a.close));
  return [['Tendencia H1', `<b class="${t[1]}">${t[0]}</b>`], ['RSI 14', `<b>${dec(a.rsi14, 1)}</b> · ${a.rsi14 > 70 ? 'sobrecompra' : a.rsi14 < 30 ? 'sobreventa' : 'neutral'}`], ['MACD', `<b class="${a.macd > a.macdSignal ? 'u' : 'd'}">${a.macd > a.macdSignal ? 'Impulso alcista' : 'Impulso bajista'}</b>`], ['Resistencia', isFinite(res) ? `<b>${dec(res)}</b>` : '—'], ['Soporte', isFinite(sup) ? `<b>${dec(sup)}</b>` : '—']];
}
function renderPulse() { const a = FortunaChart.analyze(seriesSync('XAUUSD', 60), 36e5); $('#pulse').innerHTML = quickRead(a).map(([k, v]) => `<li><span>${k}</span><span>${v}</span></li>`).join(''); $('#pulse-src').textContent = LIVE && FEAT.candles ? 'Lectura automática del oro · datos reales' : 'Lectura automática del oro · datos simulados'; }
const _homeNews = () => setTimeout(homeNews, 0);
RENDER.inicio = () => {
  _homeNews();
  drawRays(); renderHero(); renderMarkets(); renderPulse(); sessMini();
  const all = ranked(), me = all.find(t => t.me), top = all.find(t => t.ok);
  $('#mini-liga').textContent = me ? (me.ok ? me.pos + 'º' : 'Sin clasificar') : top ? '1º ' + top.alias : '–';
  $('#mini-liga2').textContent = me ? `${sg(me.gain, 1)} % · ${me.score} pts` : 'Vincula tu cuenta y compite';
  const nx = !mentLocked() && MENT && upcoming()[0];
  if (mentLocked()) { $('#mini-ment').textContent = '🔒 Muy pronto'; $('#mini-ment2').textContent = 'Mentorías en directo'; return; }
  $('#mini-ment').textContent = nx ? new Date(nx.start).toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric' }) + ' · ' + hm(nx.start) : '–';
  $('#mini-ment2').textContent = nx ? nx.title : '';
};

// =============== GRÁFICOS (hasta 3 a la vez) ===============
const DEF_PANES = [{ sym: 'XAUUSD', tf: 60 }, { sym: 'DXY', tf: 60 }, { sym: 'XAUUSD', tf: 15 }];
let LAY = LS.get('fr.layout') || { n: 1, panes: [] };
LAY.panes = DEF_PANES.map((p, i) => (LAY.panes && LAY.panes[i]) || { ...p });
LAY.panes.forEach(p => { if (!SY[p.sym]) p.sym = 'XAUUSD'; if (!TFS.some(t => t[1] === p.tf)) p.tf = 60; });
if (![1, 2, 3].includes(LAY.n)) LAY.n = 1;
let active = Math.min(LS.get('fr.active') || 0, LAY.n - 1), panes = [];
const saveLay = () => { LS.set('fr.layout', LAY); LS.set('fr.active', active); };
const AP = () => panes[active] || panes[0];
const TOOLS = [
  ['cursor', 'Cursor', '<path d="M6 3l13 7-6 1.8L10.5 19z"/>'],
  ['trend', 'Tendencia', '<path d="M4 19L20 5"/><circle cx="4" cy="19" r="2"/><circle cx="20" cy="5" r="2"/>'],
  ['hline', 'Horizontal', '<path d="M2 12h20"/><circle cx="12" cy="12" r="2"/>'],
  ['rect', 'Rectángulo', '<rect x="4" y="6" width="16" height="12" rx="1"/>'],
  ['fib', 'Fibonacci', '<path d="M3 5h18M3 9.5h18M3 13h18M3 19h18"/>'],
  ['measure', 'Medir', '<path d="M3 17L17 3l4 4L7 21zM7.5 12.5l2 2M10.5 9.5l2 2M13.5 6.5l2 2"/>'],
  ['magnet', 'Imán', '<path d="M6 3v8a6 6 0 0 0 12 0V3h-4v8a2 2 0 0 1-4 0V3zM6 7h4M14 7h4"/>'],
  ['clear', 'Borrar', '<path d="M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13"/>'],
];
// ---------- opciones editables de los indicadores Pine (Radiant Fortune Zones y DXY Panel) ----------
const TFOPT = [[5, 'M5'], [15, 'M15'], [60, 'H1'], [240, 'H4'], [1440, 'D1'], [10080, 'W1']];
const OPT = {
  zones: [
    ['Multi-temporalidad (HTF)'], ['htf', 'Mostrar zonas de temporalidad superior (HTF)', 'b', 'Auto: M5→H1 · M15→H4 · H1 y H4→D1 · D1→W1'], ['htfMode', 'Modo HTF', 's', [['Auto', 'Auto'], ['Manual', 'Manual']]], ['htfTf', 'HTF manual', 's', TFOPT.slice(2)], ['local', 'Mostrar zonas de la temporalidad actual', 'b'],
    ['Detección FVG / Ineficiencias'], ['fvg', 'Fair Value Gaps (FVG)', 'b'], ['vi', 'Volume Imbalance (VI) · solo temporalidad actual', 'b'], ['atrLen', 'Periodo ATR', 'i', 1, 200], ['minGap', 'Tamaño mínimo del gap (x ATR)', 'f', 0, 10, 'Se escala con el ATR: sirve igual en M5 que en W1'], ['minBody', 'Cuerpo mínimo vela central (x ATR, 0 = off)', 'f', 0, 10], ['maxLocal', 'Máx. zonas FVG por lado · TF actual', 'i', 1, 20], ['maxVi', 'Máx. zonas VI por lado · TF actual', 'i', 1, 20], ['maxHtf', 'Máx. zonas por lado · HTF', 'i', 1, 20], ['hideMit', 'Borrar zonas mitigadas', 'b'], ['mit', 'Mitigada cuando rompe por', 's', [['Cierre', 'Cierre'], ['Mecha', 'Mecha']]],
    ['Estilo'], ['fill', 'Transparencia del relleno (0 = sólido, 100 = invisible)', 'i', 0, 100], ['border', 'Transparencia del borde', 'i', 0, 100], ['bw', 'Grosor del borde', 'i', 1, 4], ['buy', 'Color zonas de COMPRA', 'c'], ['sell', 'Color zonas de VENTA', 'c'], ['mid', 'Línea del 50% (CE) dentro de las zonas', 'b'], ['tags', 'Etiquetas laterales (ZONA DE COMPRA / VENTA / LIQUIDEZ)', 'b'],
  ],
  dxy: [
    ['Velas del DXY'], ['up', 'Vela alcista', 'c'], ['dn', 'Vela bajista', 'c'],
    ['Zonas DXY'], ['cur', 'Zonas de la temporalidad actual', 'b'], ['htf', 'Zonas de temporalidad alta', 'b'], ['htfTf', 'Temporalidad alta', 's', TFOPT.slice(0, 5)], ['len', 'Fuerza del pivote (TF actual)', 'i', 2, 50], ['hlen', 'Fuerza del pivote (TF alta)', 'i', 2, 50], ['max', 'Máx. zonas por lado', 'i', 1, 20], ['minAtr', 'Ancho mínimo (x ATR)', 'f', 0, 10], ['del', 'Borrar zonas rotas', 'b'], ['buy', 'Color ZONA DE COMPRAS', 'c'], ['sell', 'Color ZONA DE VENTAS', 'c'], ['ext', 'Proyectar zonas a la derecha (velas)', 'i', 0, 200],
  ],
};
function optHTML(k, cur) {
  return OPT[k].map(r => {
    if (r.length === 1) return `<p class="og">${esc(r[0])}</p>`;
    const [f, l, ty, a, b, tip] = r, v = cur[f], hint = typeof a === 'string' ? a : tip, h = hint ? `<small class="sub">${esc(hint)}</small>` : '';
    if (ty === 'b') return `<div class="orow"><span>${esc(l)}${h}</span><button class="sw-t" role="switch" aria-checked="${!!v}" data-ok="${k}" data-of="${f}" data-ot="b" aria-label="${esc(l)}"></button></div>`;
    if (ty === 'c') return `<label class="orow"><span>${esc(l)}</span><input type="color" value="${esc(v)}" data-ok="${k}" data-of="${f}" data-ot="c"></label>`;
    if (ty === 's') return `<label class="orow"><span>${esc(l)}</span><select data-ok="${k}" data-of="${f}" data-ot="s">${a.map(([x, y]) => `<option value="${x}"${String(x) === String(v) ? ' selected' : ''}>${esc(y)}</option>`).join('')}</select></label>`;
    return `<label class="orow"><span>${esc(l)}${h}</span><input inputmode="decimal" value="${v}" data-ok="${k}" data-of="${f}" data-ot="${ty}" data-min="${a}" data-max="${b}"></label>`;
  }).join('');
}
function optRead(el) {
  const ty = el.dataset.ot; if (ty === 'b') return el.getAttribute('aria-checked') === 'true'; if (ty === 'c') return el.value;
  if (ty === 's') { const x = el.value; return /^\d+$/.test(x) ? +x : x; }
  let v = num(el.value); if (!isFinite(v)) return undefined; v = Math.max(+el.dataset.min, Math.min(+el.dataset.max, v)); return ty === 'i' ? Math.round(v) : v;
}
// datos extra que necesitan los indicadores (temporalidad alta, diario, DXY)
function extraFor(c, ind) {
  const ex = { sym: c.sym };
  if (ind.zones && ind.zones.on && isReal(c.sym)) {
    const z = ind.zones, h = z.htfMode === 'Auto' ? FortunaChart.autoTf(c.tf) : +z.htfTf, src = h >= 10080 ? 1440 : h;
    if (z.htf && h > c.tf && [60, 240, 1440].includes(src)) ex.htf = seriesSync(c.sym, src) || undefined;
    if ((z.pd || z.pw) && c.tf < 1440) ex.day = seriesSync(c.sym, 1440) || undefined;
  }
  if (ind.dxy && ind.dxy.on) { ex.dxy = seriesSync('DXY', c.tf) || undefined; if (isReal('DXY') && ind.dxy.htf && ind.dxy.htfTf > c.tf) ex.dxyHtf = seriesSync('DXY', ind.dxy.htfTf) || undefined; }
  return ex;
}
const EVSEEN = {};
function indEvents(pane) {
  const c = LAY.panes[pane.i];
  pane.chart.events().forEach(ev => {
    const key = c.sym + '|' + c.tf + '|' + ev.k, last = EVSEEN[key];
    EVSEEN[key] = ev.t; if (last === undefined || ev.t <= last) return; // la primera vez solo se apunta
    const title = `${c.sym} ${tfLabel(c.tf)} · ${ev.title}`; toast(title);
    try { if ('Notification' in window && Notification.permission === 'granted' && navigator.serviceWorker) navigator.serviceWorker.ready.then(r => r.showNotification(title, { body: ev.body, icon: 'icon-192.png', tag: key })); } catch (e) {}
  });
}
const COLORS = ['#f2c14e', '#3ddc97', '#ff5f5f', '#4fc3f7', '#c39bff', '#ffffff'];
function buildPanes() {
  const box = $('#c-panes'); box.innerHTML = ''; box.dataset.n = LAY.n; panes = [];
  $$('#c-lay button').forEach(b => b.setAttribute('aria-pressed', +b.dataset.n === LAY.n));
  for (let i = 0; i < LAY.n; i++) {
    const el = document.createElement('div'); el.className = 'pane' + (i === active ? ' act' : '');
    el.innerHTML = `<div class="pane-h"><button class="sym" data-psym="${i}" aria-label="Cambiar mercado del gráfico ${i + 1}"><b></b><span></span><svg viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg></button><div class="tfs" data-ptf="${i}" role="group" aria-label="Temporalidad"></div></div><div class="c-wrap"><div class="c-canvas"></div><div class="c-legend"></div><div class="c-selbar" hidden></div><button class="c-auto" hidden>Ajustar</button></div>`;
    box.append(el);
    const chart = FortunaChart(el.querySelector('.c-canvas')), pane = { chart, el, i };
    const ind = LS.get('fr.ind.' + i); if (ind) chart.setInd(ind); else if (i > 0) chart.setInd({ rsi: { on: false } });
    if (ind && ind.zones && !('fvg' in ind.zones)) chart.setInd({ zones: { ...FortunaChart.RDEF, on: ind.zones.on !== false } });
    chart.setType(LS.get('fr.type.' + i) || 'candles');
    chart.on('change', () => {
      const s = LAY.panes[i].sym, d = chart.getDrawings(); LS.set('fr.draw.' + s, d);
      panes.forEach(o => { if (o !== pane && LAY.panes[o.i].sym === s) o.chart.setDrawings(JSON.parse(JSON.stringify(d))); });
    });
    chart.on('tool', renderTools);
    chart.on('cross', idx => legend(pane, idx));
    const bar = el.querySelector('.c-selbar'), auto = el.querySelector('.c-auto');
    chart.on('select', d => { if (!d) { bar.hidden = true; return; } bar.innerHTML = COLORS.map(c => `<button class="sw" style="background:${c}" data-col="${c}" aria-label="Color"></button>`).join('') + '<button class="del" data-delsel>Eliminar</button>'; bar.hidden = false; });
    bar.onclick = e => { const c = e.target.closest('[data-col]'); if (c) chart.colorSelected(c.dataset.col); if (e.target.closest('[data-delsel]')) chart.deleteSelected(); };
    el.querySelector('.c-canvas').addEventListener('pointerup', () => setTimeout(() => { auto.hidden = chart.isAuto(); }, 0));
    auto.onclick = () => { chart.resetView(); auto.hidden = true; };
    el.addEventListener('pointerdown', () => setActive(i), true);
    panes.push(pane);
  }
}
function setActive(i) {
  if (i === active || !panes[i]) return;
  const prev = panes[active], t = prev ? prev.chart.getTool() : 'cursor';
  if (prev && t !== 'cursor') { prev.chart.setTool('cursor'); panes[i].chart.setTool(t); }
  active = i; saveLay(); panes.forEach(p => p.el.classList.toggle('act', p.i === i)); renderTools();
}
function legend(pane, i) {
  const c = LAY.panes[pane.i], d = SY[c.sym].d, a = series[c.sym + '|' + c.tf] || [];
  const idx = i == null ? a.length - 1 : i, k = pane.chart.candleAt(idx); if (!k) return;
  const v = pane.chart.values(idx), ind = pane.chart.getInd(), ch = (k.close / k.open - 1) * 100, col = k.close >= k.open ? 'u' : 'd', ec = ['var(--gold)', 'var(--sky)', 'var(--violet)'];
  pane.el.querySelector('.c-legend').classList.toggle('x', i != null);
  pane.el.querySelector('.c-legend').innerHTML = `<b>${c.sym}</b> · ${tfLabel(c.tf)} · ${esc(SY[c.sym].n)}<span class="ohlc"><br><i>A <i class="${col}">${dec(k.open, d)}</i></i> <i>M <i class="${col}">${dec(k.high, d)}</i></i> <i>m <i class="${col}">${dec(k.low, d)}</i></i> <i>C <i class="${col}">${dec(k.close, d)}</i></i> <i class="${col}">${sg(ch)} %</i></span>`
    + (ind.ema.on ? '<span class="ema"><br>' + ind.ema.p.map((p, j) => `<span style="color:${ec[j]}">EMA ${p} ${v.e[j] != null ? dec(v.e[j], d) : ''}</span>`).join(' &nbsp;') + '</span>' : '');
}
function paneHead(pane) {
  const c = LAY.panes[pane.i], ch = chg(c.sym), h = pane.el;
  h.querySelector('.sym b').textContent = c.sym;
  h.querySelector('.sym span').innerHTML = `${dec(px[c.sym], SY[c.sym].d)} <i class="${ch >= 0 ? 'u' : 'd'}" style="font-style:normal">${sg(ch)} %</i>`;
  const tfs = h.querySelector('.tfs');
  if (tfs.dataset.cur !== String(c.tf)) { tfs.dataset.cur = c.tf; tfs.innerHTML = TFS.map(([l, m]) => `<button data-tf="${m}" aria-pressed="${m === c.tf}">${l}</button>`).join(''); }
}
async function loadPane(pane) {
  if (!pane) return; const c = LAY.panes[pane.i]; paneHead(pane);
  const d = await getSeries(c.sym, c.tf);
  pane.chart.setExtra(extraFor(c, pane.chart.getInd()), true);
  pane.chart.setData(d, c.tf * 6e4, SY[c.sym].d, false);
  pane.chart.setDrawings(LS.get('fr.draw.' + c.sym) || []);
  pane.el.querySelector('.c-selbar').hidden = true; pane.el.querySelector('.c-auto').hidden = true; legend(pane, null);
  applyIndGate();
}
function loadAll() { buildPanes(); renderTools(); panes.forEach(p => loadPane(p)); }
function renderTools() {
  const ch = AP() && AP().chart, t = ch ? ch.getTool() : 'cursor', mg = ch && ch.getMagnet();
  $('#tools').innerHTML = TOOLS.map(([k, l, ic]) => `<button data-tool="${k}" aria-pressed="${k === 'magnet' ? !!mg : k === t}"><svg viewBox="0 0 24 24">${ic}</svg>${l}</button>`).join('');
}
$('#tools').onclick = e => {
  const b = e.target.closest('[data-tool]'), chart = AP() && AP().chart; if (!b || !chart) return; const k = b.dataset.tool;
  if (k === 'magnet') { const on = !chart.getMagnet(); panes.forEach(p => p.chart.setMagnet(on)); toast(on ? 'Imán activado: los puntos se pegan a las velas' : 'Imán desactivado'); }
  else if (k === 'clear') { if (!chart.getDrawings().length) return toast('No hay dibujos en este gráfico'); chart.clearDrawings(); toast('Dibujos borrados'); }
  else { chart.setTool(chart.getTool() === k && k !== 'cursor' ? 'cursor' : k); if (k !== 'cursor') toast({ trend: 'Arrastra para trazar la línea de tendencia', hline: 'Toca el precio donde quieres la línea', rect: 'Arrastra para dibujar la zona', fib: 'Arrastra de un extremo al otro del movimiento', measure: 'Arrastra para medir distancia y tiempo' }[k]); }
  renderTools();
};
RENDER.grafico = () => { loadAll(); applyIndGate(); };
$('#c-lay').onclick = e => { const b = e.target.closest('[data-n]'); if (!b) return; LAY.n = +b.dataset.n; if (active >= LAY.n) active = 0; saveLay(); loadAll(); if (LAY.n > 1) toast('Toca un gráfico para elegirlo: las herramientas y ajustes se aplican al marcado en dorado'); };
$('#c-panes').addEventListener('click', e => {
  const s = e.target.closest('[data-psym]'); if (s) { symSheet(+s.dataset.psym); return; }
  const t = e.target.closest('[data-tf]'); if (t) { const i = +t.closest('[data-ptf]').dataset.ptf; LAY.panes[i].tf = +t.dataset.tf; saveLay(); loadPane(panes[i]); }
});
function symSheet(i) {
  sheet(LAY.n > 1 ? `Mercado · gráfico ${i + 1}` : 'Mercado', VIS().map(s => { const c = chg(s); return `<button class="opt" data-s="${s}" aria-pressed="${s === LAY.panes[i].sym}"><span><b>${s}</b><br><small class="sub">${SY[s].n}</small></span><span>${dec(px[s], SY[s].d)} <span class="pill ${c >= 0 ? 'u' : 'd'}">${sg(c)} %</span></span></button>`; }).join(''),
    el => el.onclick = e => { const b = e.target.closest('[data-s]'); if (b) { closeSheet(); LAY.panes[i].sym = b.dataset.s; saveLay(); loadPane(panes[i]); } });
}
function openChart(s) { const i = Math.min(active, LAY.n - 1); LAY.panes[i].sym = s; saveLay(); if (view === 'grafico') loadPane(panes[i]); else show('grafico'); }
const nth = () => LAY.n > 1 ? ` · gráfico ${active + 1}` : '';
$('#c-type').onclick = () => { const chart = AP().chart, cur = chart.getType(); sheet('Tipo de gráfico' + nth(), [['candles', 'Velas japonesas'], ['heikin', 'Heikin Ashi'], ['bars', 'Barras OHLC'], ['line', 'Línea'], ['area', 'Área']].map(([k, l]) => `<button class="opt" data-ty="${k}" aria-pressed="${k === cur}"><b>${l}</b>${k === cur ? '<span class="u">✓</span>' : ''}</button>`).join(''), el => el.onclick = e => { const b = e.target.closest('[data-ty]'); if (b) { chart.setType(b.dataset.ty); LS.set('fr.type.' + active, b.dataset.ty); closeSheet(); } }); };
// =============== v3 · utilidades comunes ===============
const pipSize = s => { s = String(s || '').toUpperCase(); if (/^(XAU|GOLD)/.test(s)) return .1; if (/^(XAG|SILVER)/.test(s)) return .01; if (/^(BTC|ETH)/.test(s)) return 1; if (/OIL|^XTI|^WTI|^XBR/.test(s)) return .01; if (/^(DXY|USDX)/.test(s)) return .01; if (/JPY/.test(s)) return .01; if (/^(US30|US500|NAS|SPX|GER|DE40|UK100|JP225|US100)/.test(s)) return 1; return .0001; };
const pipsOf = (sym, a, b, side) => a == null || b == null || a === '' || b === '' ? null : Math.round((b - a) / pipSize(sym) * (side === 'venta' ? -1 : 1) * 10) / 10;
const agoTxt = t => { if (!t) return '—'; const m = Math.round((Date.now() - new Date(t)) / 6e4); return m < 1 ? 'ahora' : m < 60 ? `hace ${m} min` : m < 1440 ? `hace ${Math.floor(m / 60)} h` : m < 43200 ? `hace ${Math.floor(m / 1440)} d` : new Date(t).toLocaleDateString('es-ES'); };
const nf = (v, d = 2) => v == null || !isFinite(v) ? '—' : Number(v).toLocaleString('es-ES', { minimumFractionDigits: d, maximumFractionDigits: d });
const money = v => v == null || !isFinite(v) ? '—' : (v < 0 ? '−' : v > 0 ? '+' : '') + Math.abs(v).toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' $';

// =============== SESIONES DE MERCADO (Asia separada, con horarios exactos y cambio de hora) ===============
const SESS = [
  { k: 'sydney', n: 'Sídney', reg: 'Asia-Pacífico', tz: 'Australia/Sydney', o: 7, c: 16, col: '#4fc3f7' },
  { k: 'tokyo', n: 'Tokio', reg: 'Asia-Pacífico', tz: 'Asia/Tokyo', o: 9, c: 18, col: '#b388ff' },
  { k: 'hk', n: 'Hong Kong · Singapur', reg: 'Asia-Pacífico', tz: 'Asia/Hong_Kong', o: 9, c: 17, col: '#ff8a65' },
  { k: 'frankfurt', n: 'Fráncfort', reg: 'Europa', tz: 'Europe/Berlin', o: 8, c: 17, col: '#80cbc4' },
  { k: 'london', n: 'Londres', reg: 'Europa', tz: 'Europe/London', o: 8, c: 17, col: '#3ddc97' },
  { k: 'ny', n: 'Nueva York', reg: 'América', tz: 'America/New_York', o: 8, c: 17, col: '#f2c14e' },
];
const DTF = {};
function tzParts(tz, t) { const f = DTF[tz] || (DTF[tz] = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', weekday: 'short' })); const p = {}; f.formatToParts(new Date(t)).forEach(x => p[x.type] = x.value); return p; }
function tzOff(tz, t) { const p = tzParts(tz, t); return Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour % 24, +p.minute, +p.second) - Math.floor(t / 1000) * 1000; }
function zoned(tz, y, m, d, h) { const g = Date.UTC(y, m, d, h); let r = g - tzOff(tz, g); const o2 = tzOff(tz, r); if (g - o2 !== r) r = g - o2; return r; }
function sessDay(s, t) { const p = tzParts(s.tz, t); if (p.weekday === 'Sat' || p.weekday === 'Sun') return null; return [zoned(s.tz, +p.year, +p.month - 1, +p.day, s.o), zoned(s.tz, +p.year, +p.month - 1, +p.day, s.c)]; }
function sessWindow(s, now) { for (let k = -1; k < 9; k++) { const w = sessDay(s, now + k * 864e5); if (w && now < w[1] && (k >= 0 || now >= w[0])) return { a: w[0], b: w[1], open: now >= w[0] }; } return null; }
function sessionsHTML() {
  const now = Date.now(), d0 = new Date(); d0.setHours(0, 0, 0, 0); const t0 = +d0, t1 = t0 + 864e5;
  const pct = t => Math.max(0, Math.min(100, (t - t0) / 864e5 * 100)), hmL = t => new Date(t).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
  const rel = ms => { const m = Math.max(0, Math.round(ms / 6e4)); return m >= 1440 ? `${Math.floor(m / 1440)} d ${Math.floor(m % 1440 / 60)} h` : `${m >= 60 ? Math.floor(m / 60) + ' h ' : ''}${m % 60} min`; };
  const todayWins = s => { const out = []; for (let k = -1; k <= 1; k++) { const w = sessDay(s, now + k * 864e5); if (w && w[1] > t0 && w[0] < t1 && !out.some(x => x[0] === w[0])) out.push(w); } return out; };
  const regs = [...new Set(SESS.map(s => s.reg))];
  const lon = todayWins(SESS[4])[0], ny = todayWins(SESS[5])[0], ov = lon && ny ? [Math.max(lon[0], ny[0]), Math.min(lon[1], ny[1])] : null;
  const anyOpen = SESS.some(s => { const w = sessWindow(s, now); return w && w.open; });
  return `<div class="sx"><div class="sx-h"><span>0h</span><span>6h</span><span>12h</span><span>18h</span><span>24h</span></div>
    ${regs.map(r => `<p class="sx-reg">${r}</p>` + SESS.filter(s => s.reg === r).map(s => { const w = sessWindow(s, now), tw = todayWins(s);
      return `<div class="sx-r ${w && w.open ? 'on' : ''}"><div class="sx-n"><i style="background:${s.col}"></i><b>${s.n}</b></div>
        <div class="sx-t">${tw.map(x => `<span class="seg" style="left:${pct(x[0])}%;width:${pct(x[1]) - pct(x[0])}%;background:${s.col}"></span>`).join('')}<span class="nowl" style="left:${pct(now)}%"></span></div>
        <div class="sx-i"><small>${w ? hmL(w.a) + ' – ' + hmL(w.b) : '—'}</small><span class="${w && w.open ? 'op' : ''}">${!w ? '—' : w.open ? 'Abierta · cierra en ' + rel(w.b - now) : 'Abre en ' + rel(w.a - now)}</span></div></div>`; }).join('')).join('')}
    ${ov && ov[1] > ov[0] ? `<div class="sx-ov">🔥 <b>Solape Londres + Nueva York:</b> ${hmL(ov[0])} – ${hmL(ov[1])}. Es cuando el oro suele moverse más.</div>` : ''}
    <p class="fine" style="margin:6px 0 0">${anyOpen ? 'Horas en tu hora local. Ya incluyen el cambio de hora de cada país.' : 'Fin de semana: el mercado abre el lunes con la sesión de Sídney.'}</p></div>`;
}

// =============== MENÚ DE INDICADORES (más fácil) ===============
const IND_INFO = {
  zones: ['🟩', 'ProZones', 'Zonas de compra y venta de esta temporalidad y de una superior', 'Zonas y niveles'],
  dxy: ['💵', 'Panel DXY', 'Velas del dólar con sus zonas, en un panel debajo', 'Zonas y niveles'],
  ses: ['🕒', 'Sesiones de mercado', 'Inicio, final, máximo y mínimo de Asia, Londres y Nueva York', 'Zonas y niveles'],
  piv: ['📍', 'Pivotes diarios', 'Niveles P, R1, R2, S1 y S2 del día', 'Zonas y niveles'],
  vp: ['📊', 'Volume Profile', 'Volumen por precio: POC, VAH y VAL', 'Zonas y niveles'],
  ema: ['〰️', 'Medias móviles EMA', 'Tres medias para ver la tendencia', 'Tendencia'],
  bb: ['🎯', 'Bandas de Bollinger', 'Volatilidad y extremos del precio', 'Tendencia'],
  rsi: ['⚡', 'RSI', 'Fuerza del movimiento, en un panel debajo', 'Osciladores'],
  macd: ['📉', 'MACD', 'Impulso y cruces, en un panel debajo', 'Osciladores'],
  div: ['🔀', 'Divergencias RSI', 'Avisa cuando el precio y el RSI no coinciden', 'Osciladores'],
};
Object.assign(OPT, {
  ema: [['p0', 'Media rápida', 'i', 2, 500], ['p1', 'Media intermedia', 'i', 2, 500], ['p2', 'Media lenta', 'i', 2, 500]],
  bb: [['p', 'Periodo', 'i', 2, 300], ['k', 'Desviaciones', 'f', .5, 5]],
  rsi: [['p', 'Periodo', 'i', 2, 200]],
  macd: [['f', 'Media rápida', 'i', 2, 200], ['s', 'Media lenta', 'i', 2, 300], ['g', 'Señal', 'i', 2, 100]],
  vp: [['bins', 'Niveles de precio', 'i', 10, 120]],
  ses: [['Qué sesiones'], ['sydney', 'Sídney', 'b'], ['tokyo', 'Tokio (Asia)', 'b'], ['london', 'Londres', 'b'], ['ny', 'Nueva York', 'b'], ['Dibujo'], ['boxes', 'Caja con el máximo y el mínimo', 'b'], ['labels', 'Nombre y horario de cada sesión', 'b']],
});
const indView = (k, v) => k === 'ema' ? { ...v, p0: v.p[0], p1: v.p[1], p2: v.p[2] } : v;
function indSetField(chart, k, f, v) { if (k === 'ema' && /^p\d$/.test(f)) { const p = [...chart.getInd().ema.p]; p[+f[1]] = v; chart.setInd({ ema: { p } }); } else chart.setInd({ [k]: { [f]: v } }); }
$('#c-ind').onclick = () => {
  const pane = AP(), chart = pane.chart, key = 'fr.ind.' + active;
  const save = () => { chart.setExtra(extraFor(LAY.panes[pane.i], chart.getInd())); LS.set(key, chart.getInd()); legend(pane, null); };
  const cats = [...new Set(Object.values(IND_INFO).map(x => x[3]))];
  const tile = k => { const ind = chart.getInd(), [ic, nm, ds] = IND_INFO[k], lock = !canInd(k), on = !!(ind[k] && ind[k].on);
    return `<div class="itile${on ? ' on' : ''}${lock ? ' lock' : ''}" data-ik="${k}"><button class="itb" type="button" data-tg="${k}"${lock ? ' aria-disabled="true"' : ''} aria-pressed="${on}"><span class="ic">${ic}</span><span class="tx"><b>${nm}</b><small>${ds}</small></span><span class="st">${lock ? '🔒' : on ? 'ACTIVO' : 'APAGADO'}</span></button>${!lock && OPT[k] ? `<details class="opts"><summary>⚙ Ajustes de ${nm}</summary>${optHTML(k, indView(k, ind[k]))}</details>` : ''}</div>`; };
  const head = () => { const ind = chart.getInd(), on = Object.keys(IND_INFO).filter(k => ind[k] && ind[k].on); return `<div class="ind-top"><div><b>${on.length ? on.length + ' activo' + (on.length > 1 ? 's' : '') : 'Ninguno activo'}</b><small>${on.length ? on.map(k => IND_INFO[k][1]).join(' · ') : 'Toca un indicador para encenderlo'}</small></div>${on.length ? '<button class="btn ghost sm" type="button" data-alloff>Apagar todos</button>' : ''}</div>`; };
  sheet('Indicadores' + nth(), `<div id="ind-head">${head()}</div>
    ${Object.keys(IND_INFO).some(k => !canInd(k)) ? '<div class="demo-note">🔒 Los indicadores con candado los activa el administrador. Pídeselos por el chat.</div>' : ''}
    ${cats.map(c => `<h4 class="ind-cat">${c}</h4>${Object.keys(IND_INFO).filter(k => IND_INFO[k][3] === c).map(tile).join('')}`).join('')}`, el => {
    const refresh = k => { const t = el.querySelector(`[data-ik="${k}"]`), ind = chart.getInd(), on = !!(ind[k] && ind[k].on); t.classList.toggle('on', on); t.querySelector('.st').textContent = on ? 'ACTIVO' : 'APAGADO'; t.querySelector('.itb').setAttribute('aria-pressed', on); $('#ind-head').innerHTML = head(); };
    el.onclick = e => {
      if (e.target.closest('[data-alloff]')) { const off = {}; Object.keys(IND_INFO).forEach(k => off[k] = { on: false }); chart.setInd(off); save(); Object.keys(IND_INFO).forEach(refresh); return; }
      const tg = e.target.closest('[data-tg]');
      if (tg) { const k = tg.dataset.tg; if (!canInd(k)) return toast('Este indicador lo activa el administrador'); const on = !chart.getInd()[k].on; chart.setInd({ [k]: { on } }); save(); refresh(k); if (on && OPT[k]) { const d = el.querySelector(`[data-ik="${k}"] details`); if (d && k === 'ses') d.open = true; } return; }
      const ob = e.target.closest('[data-ot="b"]'); if (ob) { const on = ob.getAttribute('aria-checked') !== 'true'; ob.setAttribute('aria-checked', on); indSetField(chart, ob.dataset.ok, ob.dataset.of, on); save(); }
    };
    const set = (o, final) => { if (!o || o.dataset.ot === 'b') return; const v = optRead(o); if (v === undefined) return; if (final && o.tagName === 'INPUT' && o.dataset.ot !== 'c') o.value = v; indSetField(chart, o.dataset.ok, o.dataset.of, v); save(); };
    el.onchange = e => set(e.target.closest('[data-ok]'), true);
    el.oninput = e => { const o = e.target.closest('[data-ok]'); if (o && (o.dataset.ot === 'c' || o.dataset.ot === 's' || isFinite(num(o.value)))) set(o, false); };
  });
};

$('#c-full').onclick = () => {
  const on = !$('#app').classList.contains('full'); $('#app').classList.toggle('full', on); $('#c-full').setAttribute('aria-pressed', on);
  try { if (on && document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(() => {}); else if (!on && document.fullscreenElement) document.exitFullscreen().catch(() => {}); } catch (e) {}
  panes.forEach(p => p.chart.redraw());
};

// =============== FORTUNATY ===============
const FT = { msgs: [], busy: false, mode: null };
const CHIPS = ['Análisis técnico del XAUUSD', 'Noticias del oro hoy', 'Niveles clave para hoy', '¿Cómo afecta el DXY al oro ahora?', 'Explícame el RSI actual', 'Revisa mis líneas del gráfico'];
const SYS = `Eres Fortunaty, la inteligencia artificial de la app Fortuna Radiante, especializada en el oro (XAUUSD) y en los mercados relacionados (DXY, Bitcoin, petróleo WTI), y también analizas los pares de divisas e índices que aparezcan en «precios».
Respondes siempre en español, con tono cercano, claro y profesional, pensado para leerse en el móvil: frases cortas, títulos breves con ###, listas con guiones y cifras concretas tomadas de los DATOS que se te dan. Máximo unas 220 palabras salvo que pidan más.
En los DATOS, zonasCompra/zonasVenta vienen del indicador del usuario «Radiant Fortune Zones» como [desde, hasta, temporalidad, FVG o VI, fuerza]; úsalas como zonas de compra y venta, junto con liquidezArriba/liquidezAbajo, ultimaSenal y el rango premium/descuento. Recuerda que el oro suele moverse al revés que el DXY.
Para un análisis técnico usa esta estructura: ### Resumen · ### Tendencia (H1, H4, D1) · ### Niveles clave (soportes y resistencias con precio) · ### Escenarios (alcista y bajista, con qué confirmaría cada uno) · ### Riesgos.
Nunca garantices resultados ni des órdenes de compra/venta personalizadas; puedes describir escenarios y niveles. Termina los análisis con una línea breve: "Esto es información, no asesoramiento financiero."
Si los DATOS indican que los precios son simulados, dilo con naturalidad al principio ("Con los datos de demostración de la app…").`;
const SYS_NONEWS = `\nEn este modo NO tienes acceso a noticias ni a internet. Si te piden noticias, dilo claramente, no inventes titulares ni datos, y explica qué tipo de eventos suelen mover el oro (datos de empleo e inflación de EE. UU., decisiones de la Reserva Federal, el dólar, tensiones geopolíticas) para que el usuario los consulte.`;
function snapshot() {
  const o = { hora_madrid: new Date().toLocaleString('es-ES', { timeZone: 'Europe/Madrid' }), fuente_de_precios: isReal('XAUUSD') ? (FEED.fresh ? 'precios reales de Vantage (MetaTrader 5) en directo' : 'precios reales de Vantage, últimos disponibles (mercado cerrado o robot parado)') + (ORDER.some(s => !isReal(s)) ? '; simulados: ' + ORDER.filter(s => !isReal(s)).join(', ') : '') : LIVE && FEAT.candles ? 'precios reales del bróker' : 'DATOS SIMULADOS (modo demostración de la app)', precios: {}, xauusd_indicadores: {} };
  VIS().forEach(s => o.precios[s] = { precio: r2(px[s], SY[s].d), cambio_24h_pct: r2(chg(s)) });
  [['H1', 60], ['H4', 240], ['D1', 1440]].forEach(([l, m]) => { const a = FortunaChart.analyze(seriesSync('XAUUSD', m), m * 6e4); if (a) { const deep = v => typeof v === 'number' ? r2(v) : Array.isArray(v) ? v.map(deep) : v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).map(([kk, vv]) => [kk, deep(vv)])) : v; o.xauusd_indicadores[l] = deep(a); } });
  const lines = (LS.get('fr.draw.XAUUSD') || []).filter(d => d.type === 'hline').map(d => r2(d.p[0].price)); if (lines.length) o.lineas_horizontales_del_usuario_en_xauusd = lines;
  return o;
}
let samplerP = null;
function getSampler() {
  if (!samplerP) samplerP = (async () => {
    for (let k = 0; k < 30 && !(window.claude && window.claude.use); k++) await wait(100);
    if (!(window.claude && window.claude.use)) return null;
    try { return await window.claude.use('sample'); } catch (e) { return null; }
  })();
  return samplerP;
}
async function ftMode() {
  if (LIVE && FEAT.ai) return 'server';
  if (comm.mode === 'supabase') return 'edge';
  return (await getSampler()) ? 'sample' : 'offline';
}
function md(t) {
  const lines = esc(t).split('\n'); let h = '', inList = false;
  const inline = s => s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\[([^\]]+)\]\((https:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  for (const raw of lines) {
    const l = raw.trim();
    if (/^([-*•]|\d+\.)\s+/.test(l)) { if (!inList) { h += '<ul>'; inList = true; } h += '<li>' + inline(l.replace(/^([-*•]|\d+\.)\s+/, '')) + '</li>'; continue; }
    if (inList) { h += '</ul>'; inList = false; }
    if (/^#{1,4}\s/.test(l)) h += '<h4>' + inline(l.replace(/^#{1,4}\s/, '')) + '</h4>';
    else if (l) h += '<p>' + inline(l) + '</p>';
  }
  return h + (inList ? '</ul>' : '');
}
function renderFT() {
  const box = $('#ft-msgs'), badge = { server: 'IA con noticias en tiempo real', edge: 'IA con noticias en tiempo real', sample: 'IA · análisis con los datos de la app', offline: 'Modo básico · análisis automático' }[FT.mode] || 'Conectando…';
  const hello = `<div class="ft-hello"><div class="ft-av"><img src="icons/logo-192.png" alt=""></div><h2>Fortunaty</h2><p>Tu analista del oro. Pregúntame por el XAUUSD, el dólar, niveles, noticias o cómo leer un indicador.</p><span class="badge">${badge}</span></div>`;
  box.innerHTML = hello + FT.msgs.map(m => m.role === 'user' ? `<div class="bub user">${esc(m.content)}</div>` : `<div class="bub ai"><div class="who">Fortunaty</div>${m.content ? md(m.content) : '<div class="dots"><span></span><span></span><span></span></div>'}${m.sources && m.sources.length ? `<div class="src"><b>Fuentes</b>${m.sources.filter(s => /^https:\/\//.test(s.url)).map(s => `<a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.title || s.url)}</a>`).join('')}</div>` : ''}</div>`).join('') + (FT.msgs.length ? '<p class="disc">Fortunaty informa y analiza; no es asesoramiento financiero.</p>' : '');
  box.scrollTop = box.scrollHeight;
}
RENDER.fortunaty = async () => {
  $('#ft-chips').innerHTML = CHIPS.map(c => `<button data-chip="${esc(c)}">${esc(c)}</button>`).join('');
  renderFT(); if (!FT.mode) { FT.mode = await ftMode(); renderFT(); }
};
$('#ft-chips').onclick = e => { const b = e.target.closest('[data-chip]'); if (b) ask(b.dataset.chip); };
$('#ft-form').onsubmit = e => { e.preventDefault(); const t = $('#ft-in').value.trim(); if (t) { $('#ft-in').value = ''; ask(t); } };
function offlineAnswer(q) {
  const s = snapshot(), a = s.xauusd_indicadores, out = [`Ahora mismo no tengo conexión con la IA, así que te dejo la **lectura automática** de los indicadores${LIVE && FEAT.candles ? '' : ' (con los datos de demostración)'}:`];
  for (const [l, x] of Object.entries(a)) out.push(`- **${l}**: precio ${dec(x.close)} · ${x.close > x.ema200 ? 'por encima' : 'por debajo'} de la EMA 200 · RSI ${dec(x.rsi14, 1)} · MACD ${x.macd > x.macdSignal ? 'alcista' : 'bajista'}`);
  const h = a.H1; if (h) out.push(`### Niveles H1`, `- Resistencias: ${dec(h.pivots.R1)} y ${dec(h.swingHigh50)}`, `- Soportes: ${dec(h.pivots.S1)} y ${dec(h.swingLow50)}`);
  if (/notic/i.test(q)) out.push('Para noticias necesito la conexión con la IA del servidor.');
  out.push('Esto es información, no asesoramiento financiero.');
  return out.join('\n');
}
async function ask(q) {
  if (FT.busy) return toast('Fortunaty está terminando la respuesta anterior');
  FT.busy = true; if (!FT.mode) FT.mode = await ftMode();
  FT.msgs.push({ role: 'user', content: q }); const msg = { role: 'assistant', content: '' }; FT.msgs.push(msg); renderFT();
  try {
    const snap = snapshot(), hist = FT.msgs.slice(0, -1).filter(m => m.content).slice(-10).map(m => ({ role: m.role, content: m.content }));
    if (FT.mode === 'server') {
      const j = await api('/api/fortunaty', { method: 'POST', body: { messages: hist, snapshot: snap } });
      msg.content = j.text; msg.sources = j.sources;
    } else if (FT.mode === 'edge') {
      try { const j = await comm.fn('fortunaty', { messages: hist, snapshot: snap }); msg.content = j.text; msg.sources = j.sources; }
      catch (x) {
        if (x.code === 'no_key' || x.status === 404 || /Failed to send|not found|fetch/i.test(x.message)) msg.content = offlineAnswer(q) + (ADMIN ? '\n\n**Aviso para el admin:** falta activar Fortunaty en Supabase (función «fortunaty» y secreto ANTHROPIC_API_KEY). Mira el tutorial.' : '');
        else throw x;
      }
    } else if (FT.mode === 'sample') {
      const sample = await getSampler();
      const input = hist.map((m, i) => i === hist.length - 1 ? { role: 'user', content: `${SYS}${SYS_NONEWS}\n\nDATOS DE MERCADO ACTUALES (JSON):\n${JSON.stringify(snap)}\n\nPREGUNTA DEL USUARIO: ${m.content}` } : m);
      while (input.length && input[0].role !== 'user') input.shift();
      let last = 0;
      const res = await sample(input, { cache: false, onText: ({ text }) => { msg.content = text; if (Date.now() - last > 120) { last = Date.now(); renderFT(); } } });
      msg.content = res.text;
    } else { await wait(500); msg.content = offlineAnswer(q); }
  } catch (e) {
    const code = e && e.code;
    msg.content = code === 'not_granted' ? 'Necesito tu permiso para usar la IA en esta vista. Vuelve a preguntar y acepta el aviso.' : code === 'rate_limited' ? 'Has hecho muchas preguntas seguidas. Espera un momento y vuelve a intentarlo.' : (e && e.message ? 'No he podido responder: ' + e.message : 'No he podido responder ahora mismo.');
    if (code === 'not_granted') FT.mode = null;
  }
  FT.busy = false; renderFT();
}

// =============== COMUNIDAD: registro, miembros y chat tipo Telegram ===============
// Con Supabase configurado (config.js) la comunidad es real y compartida; si no, modo demo en este móvil.
let comTab = 'chat';
const CHANNELS = [['general', 'General'], ['xauusd', 'XAUUSD'], ['analisis', 'Análisis'], ['mentorias', 'Mentorías']];
let ch = 'general';
const SB_URL = String(window.FR_SUPABASE_URL || '').trim(), SB_KEY = String(window.FR_SUPABASE_KEY || '').trim();
const okUrl = u => typeof u === 'string' && /^(https:\/\/|data:image\/|blob:)/.test(u);
const AVC = ['#c8901a', '#b5652a', '#8a6a1c', '#a0522d', '#7c4dff', '#2e8b57', '#3b6fd8', '#b03a5b'];
const hashN = s => { let h = 0; for (const c of String(s || '')) h = (h * 31 + c.charCodeAt(0)) | 0; return Math.abs(h); };
function avHTML(p, size = 40, online = false) {
  const inner = p && okUrl(p.avatar_url) ? `<img src="${esc(p.avatar_url)}" alt="" loading="lazy">` : `<span style="background:${AVC[hashN(p && p.alias) % AVC.length]};font-size:${Math.round(size * .42)}px">${esc(((p && p.alias) || '?')[0].toUpperCase())}</span>`;
  return `<span class="ava${online ? ' on' : ''}" style="width:${size}px;height:${size}px">${inner}</span>`;
}
async function shrink(file, max, square) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((ok, ko) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => ko(new Error('No se pudo leer la imagen')); i.src = url; });
    let w = img.naturalWidth, h = img.naturalHeight, sx = 0, sy = 0, sw = w, sh = h;
    if (square) { const m = Math.min(w, h); sx = (w - m) / 2; sy = (h - m) / 2; sw = sh = m; w = h = Math.min(max, m); }
    else { const k = Math.min(1, max / Math.max(w, h)); w = Math.round(w * k); h = Math.round(h * k); }
    const c = document.createElement('canvas'); c.width = w; c.height = h; c.getContext('2d').drawImage(img, sx, sy, sw, sh, 0, 0, w, h);
    return await new Promise(ok => c.toBlob(ok, 'image/jpeg', .82));
  } finally { URL.revokeObjectURL(url); }
}
const blobToData = b => new Promise(ok => { const r = new FileReader(); r.onload = () => ok(r.result); r.readAsDataURL(b); });
function loadScript(src) { return new Promise((ok, ko) => { const s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = () => ko(new Error('Sin conexión con la comunidad')); document.head.append(s); }); }

// ---------- modo demo: todo en este dispositivo ----------
function LocalComm() {
  const now = Date.now();
  const people = [['Carmen_FX', 'Opero la apertura de Londres cada mañana.'], ['PipHunter', 'Scalping en M5 · paciencia y stop.'], ['GoldDigger', 'Solo oro, solo H1.'], ['NoaTrades', 'Gestión del riesgo ante todo.'], ['Martina.V', 'Swing trader, me gustan los rangos.'], ['SwingKing', 'Rupturas con volumen.'], ['ToroBravo', 'Agresivo pero siempre con stop.'], ['LoboDeWallSt', 'Price action puro.'], ['Laura Méndez', 'Mentora · price action en oro.', 'mentor']];
  const members = people.map(([alias, bio, role], i) => ({ id: 'u' + i, alias, bio, role: role || 'user', avatar_url: null, created_at: new Date(now - (i + 2) * 864e5 * 3).toISOString() }));
  let me = LS.get('fr.local.me'); const msgs = []; let mid = 1; const subs = [];
  const add = (c, uid, kind, body, ago, x = {}) => msgs.push({ id: mid++, channel: c, user_id: uid, kind, body, media_url: x.media_url || null, duration: x.duration || null, created_at: new Date(now - ago * 6e4).toISOString() });
  const chartPic = (() => { try { const c = document.createElement('canvas'); c.width = 520; c.height = 300; const g = c.getContext('2d'); g.fillStyle = '#110f0b'; g.fillRect(0, 0, 520, 300); let p = 160; for (let i = 0; i < 40; i++) { const o = p, cl = p + (Math.random() - .45) * 22; g.strokeStyle = g.fillStyle = cl < o ? '#3ddc97' : '#ff5f5f'; const x = 14 + i * 12.5; g.beginPath(); g.moveTo(x + 4, Math.min(o, cl) - 8); g.lineTo(x + 4, Math.max(o, cl) + 8); g.stroke(); g.fillRect(x, Math.min(o, cl), 8, Math.max(2, Math.abs(cl - o))); p = cl; } g.strokeStyle = '#f2c14e'; g.setLineDash([6, 5]); g.beginPath(); g.moveTo(0, 120); g.lineTo(520, 120); g.stroke(); g.fillStyle = '#f2c14e'; g.font = '600 18px sans-serif'; g.fillText('XAUUSD H1 · resistencia', 16, 108); return c.toDataURL('image/jpeg', .8); } catch (e) { return null; } })();
  add('general', 'u0', 'text', '¡Buenos días, familia radiante! ☀️ ¿Quién opera hoy Londres?', 95);
  add('general', 'u1', 'text', 'Yo, con media posición. Hay datos de EE. UU. por la tarde.', 90);
  add('general', 'u6', 'text', 'Subí 3 puestos en la liga esta semana 💪', 40);
  add('general', 'u3', 'text', '🔥🔥', 38);
  add('xauusd', 'u2', 'text', 'El oro respetando la EMA 50 en H1 otra vez. Os dejo mi gráfico:', 72);
  if (chartPic) add('xauusd', 'u2', 'image', null, 71, { media_url: chartPic });
  add('xauusd', 'u7', 'text', 'RSI de H4 alto, yo esperaría un retroceso para entrar.', 50);
  add('xauusd', 'u4', 'text', 'Atentos al pivote diario, ayer rebotó justo ahí 🎯', 20);
  add('analisis', 'u5', 'text', 'Mi idea: rango en D1, espero ruptura con fuerza antes de entrar.', 180);
  add('mentorias', 'u8', 'text', 'Esta semana revisamos operaciones de la liga. Traed capturas del gráfico 📊', 300);
  add('mentorias', 'u8', 'text', 'La grabación queda en Mentorías al día siguiente.', 110);
  const emit = m => subs.forEach(s => s.on(m)), save = () => LS.set('fr.local.me', me);
  const REPL = ['Buena observación 👌', 'Lo veo parecido, pero esperaría confirmación en H1.', 'Cuidado con el spread en noticias ⚠️', '¿Dónde pondrías el stop?', 'Gracias por compartir 🙌', 'Fortunaty me marcó el mismo nivel.', '😂😂', '¡Vamos! 🚀'];
  const self = {
    mode: 'demo', init: async () => {}, me: () => me, onAuth() {}, onPresence() {},
    profile: id => id === 'me' ? me : members.find(m => m.id === id),
    async signUp({ alias, email, avatar }) {
      if (members.some(m => m.alias.toLowerCase() === alias.toLowerCase())) throw new Error('Ese alias ya está en uso.');
      me = { id: 'me', alias, bio: '', role: 'user', email, avatar_url: avatar ? await blobToData(avatar) : null, created_at: new Date().toISOString() }; save(); return { needsConfirm: false };
    },
    async signIn({ email }) { const s = LS.get('fr.local.me'); if (!s) throw new Error('No hay ninguna cuenta en este dispositivo. Crea una.'); if (s.email && email && s.email.toLowerCase() !== email.toLowerCase()) throw new Error('Ese correo no coincide con la cuenta de este dispositivo.'); me = s; },
    async signOut() { me = null; },
    async resetPassword() { throw new Error('En modo demo no hay contraseñas que recuperar.'); },
    async setPassword() {},
    async deleteAccount() { LS.del('fr.local.me'); me = null; for (let i = msgs.length - 1; i >= 0; i--) if (msgs[i].user_id === 'me') msgs.splice(i, 1); },
    async updateProfile(p) { Object.assign(me, p); save(); },
    async uploadAvatar(blob) { me.avatar_url = await blobToData(blob); save(); },
    async members() { return me ? [me, ...members] : members.slice(); },
    online: () => new Set(['u0', 'u2', 'u4', 'u8', ...(me ? ['me'] : [])]),
    async messages(c) { return msgs.filter(m => m.channel === c); },
    async send(c, { kind, body, blob, duration }) {
      const m = { id: mid++, channel: c, user_id: 'me', kind, body: body || null, media_url: blob ? URL.createObjectURL(blob) : null, duration: duration || null, created_at: new Date().toISOString() };
      msgs.push(m); emit(m);
      if (Math.random() < .65) setTimeout(() => { const u = members[Math.floor(Math.random() * 8)], r = { id: mid++, channel: c, user_id: u.id, kind: 'text', body: REPL[Math.floor(Math.random() * REPL.length)], created_at: new Date().toISOString() }; msgs.push(r); emit(r); }, 1600 + Math.random() * 2600);
    },
    async remove(id) { const i = msgs.findIndex(m => m.id === id); if (i >= 0) msgs.splice(i, 1); subs.forEach(s => s.del && s.del(id)); },
    subscribe(on, del) { subs.push({ on, del }); },
    async alerts() { return LS.get('fr.alerts') || []; },
    async addAlert(x) { const al = { id: Date.now(), active: true, created_at: new Date().toISOString(), ...x }; const l = LS.get('fr.alerts') || []; l.unshift(al); LS.set('fr.alerts', l); return al; },
    async delAlert(id) { LS.set('fr.alerts', (LS.get('fr.alerts') || []).filter(a => a.id !== id)); },
    async config() { return LS.get('fr.cfg.local'); },
    async saveConfig(v) { LS.set('fr.cfg.local', v); },
    async isAdmin() { return !!me; },
    async bans() { return LS.get('fr.bans') || []; },
    async ban(id) { LS.set('fr.bans', [...new Set([...(LS.get('fr.bans') || []), id])]); },
    async unban(id) { LS.set('fr.bans', (LS.get('fr.bans') || []).filter(x => x !== id)); },
    // ---------- v3 en modo prueba (se guarda solo en este móvil) ----------
    async news() { let l = LS.get('fr.l.news'); if (!l) { const d = Date.now(); l = [{ id: 'demo/3', channel: 'canaldemo', posted_at: new Date(d - 12 * 6e4).toISOString(), title: 'El oro marca un nuevo máximo histórico por encima de 4.050 $', body: '🚨 ÚLTIMA HORA: el oro sube con fuerza y supera los 4.050 $ por onza.\n\nPowell (Fed): «los tipos seguirán altos durante más tiempo».', topic: 'oro', link: 'https://t.me/canaldemo/3' }, { id: 'demo/2', channel: 'canaldemo', posted_at: new Date(d - 95 * 6e4).toISOString(), title: 'IPC de EE. UU.: 3,1 % frente al 3,0 % esperado', body: 'La inflación de EE. UU. sale una décima por encima de lo previsto. El dólar reacciona al alza.', topic: 'dolar', link: 'https://t.me/canaldemo/2' }, { id: 'demo/1', channel: 'canaldemo', posted_at: new Date(d - 5 * 36e5).toISOString(), title: 'El petróleo cae un 2 % tras el aumento de inventarios', body: 'Los inventarios de crudo suben más de lo esperado y el WTI baja por debajo de 65 $.', topic: 'petroleo', link: 'https://t.me/canaldemo/1' }]; LS.set('fr.l.news', l); } return l; },
    async addNews(n) { LS.set('fr.l.news', [{ ...n, id: 'fortuna/' + Date.now(), channel: 'fortuna', posted_at: new Date().toISOString() }, ...(await self.news())]); },
    async deleteNews(id) { LS.set('fr.l.news', (await self.news()).filter(x => x.id !== id)); },
    async adminUsers() { const a = me ? LS.get('fr.acc.' + me.id) || {} : {}; return me ? [{ id: me.id, email: me.email || 'tu@correo.com', alias: me.alias, avatar_url: me.avatar_url, created_at: me.created_at, last_sign_in_at: new Date().toISOString(), status: a.status || null, sections: a.sections, indicators: a.indicators, roles: [], muted: false, is_admin: true }] : []; },
    async deleteUser() { throw new Error('En modo prueba no se pueden borrar usuarios'); },
    async roles() { return LS.get('fr.l.roles') || [{ id: 'fundador', name: 'Fundador', color: '#F2C14E', icon: '👑', sort: 0, can_signals: true, can_moderate: true }, { id: 'analista', name: 'Analista', color: '#3DDC97', icon: '📡', sort: 1, can_signals: true, can_moderate: false }, { id: 'vip', name: 'VIP', color: '#B388FF', icon: '💎', sort: 4, can_signals: false, can_moderate: false }, { id: 'novato', name: 'Novato', color: '#8BC34A', icon: '🌱', sort: 6, can_signals: false, can_moderate: false }]; },
    async userRoles() { return LS.get('fr.l.uroles') || (me ? [{ user_id: me.id, role_id: 'fundador' }] : []); },
    async saveRole(r) { const l = await self.roles(); const i = l.findIndex(x => x.id === r.id); if (i >= 0) l[i] = r; else l.push(r); LS.set('fr.l.roles', l); },
    async deleteRole(id) { LS.set('fr.l.roles', (await self.roles()).filter(x => x.id !== id)); },
    async setUserRoles(uid, ids) { LS.set('fr.l.uroles', [...(await self.userRoles()).filter(x => x.user_id !== uid), ...ids.map(role_id => ({ user_id: uid, role_id }))]); },
    async signals() { return LS.get('fr.l.sig') || []; },
    async saveSignal(s) { const l = LS.get('fr.l.sig') || []; if (s.id) { const i = l.findIndex(x => x.id === s.id); l[i] = { ...l[i], ...s, updated_at: new Date().toISOString(), closed_at: ['tp3', 'sl', 'be', 'cerrada', 'cancelada'].includes(s.status) ? new Date().toISOString() : l[i].closed_at }; } else l.unshift({ ...s, id: 's' + Date.now(), created_by: me && me.id, created_at: new Date().toISOString(), updated_at: new Date().toISOString() }); LS.set('fr.l.sig', l); },
    async deleteSignal(id) { LS.set('fr.l.sig', (LS.get('fr.l.sig') || []).filter(x => x.id !== id)); },
    async trades(from, to) { return (LS.get('fr.l.trades') || []).filter(x => x.close_time >= from && x.close_time < to); },
    async addTrade(t) { const l = LS.get('fr.l.trades') || []; const pip = pipsOf(t.symbol, t.open_price, t.close_price, t.side); l.push({ ...t, id: Date.now() + Math.random(), source: 'manual', pips: pip }); LS.set('fr.l.trades', l); },
    async updateTrade(id, p) { const l = LS.get('fr.l.trades') || []; const i = l.findIndex(x => x.id === id); if (i >= 0) { l[i] = { ...l[i], ...p }; if (p.pips === null) l[i].pips = pipsOf(l[i].symbol, l[i].open_price, l[i].close_price, l[i].side); } LS.set('fr.l.trades', l); },
    async deleteTrade(id) { LS.set('fr.l.trades', (LS.get('fr.l.trades') || []).filter(x => x.id !== id)); },
    async mtAccounts() { return []; },
    async journalKey() { return 'fr_modo_prueba_sin_servidor'; },
    async challenges() { let l = LS.get('fr.l.ch'); if (!l) { const d = Date.now(); l = [{ id: 'c1', title: 'Racha de fuego', icon: '🔥', kind: 'racha', target: 5, min_trades: 0, xp: 200, starts_at: new Date(d - 3 * 864e5).toISOString(), ends_at: new Date(d + 4 * 864e5).toISOString(), description: 'Encadena 5 operaciones ganadoras esta semana.' }, { id: 'c2', title: 'Francotirador', icon: '🎯', kind: 'winrate', target: 60, min_trades: 10, xp: 300, starts_at: new Date(d - 10 * 864e5).toISOString(), ends_at: new Date(d + 20 * 864e5).toISOString(), description: '' }, { id: 'c3', title: 'Siempre con stop', icon: '🛡️', kind: 'con_sl', target: 100, min_trades: 5, xp: 150, starts_at: new Date(d - 2 * 864e5).toISOString(), ends_at: new Date(d + 12 * 864e5).toISOString(), description: 'Todas tus operaciones con stop loss.' }]; LS.set('fr.l.ch', l); } return l; },
    async joins() { return LS.get('fr.l.jo') || []; },
    async join(cid) { LS.set('fr.l.jo', [...(LS.get('fr.l.jo') || []), { challenge_id: cid, user_id: me.id, manual_done: false }]); },
    async leave(cid) { LS.set('fr.l.jo', (LS.get('fr.l.jo') || []).filter(j => !(j.challenge_id === cid && j.user_id === me.id))); },
    async saveChallenge(c) { const l = await self.challenges(); if (c.id) { const i = l.findIndex(x => x.id === c.id); l[i] = { ...l[i], ...c }; } else l.push({ ...c, id: 'c' + Date.now() }); LS.set('fr.l.ch', l); },
    async deleteChallenge(id) { LS.set('fr.l.ch', (await self.challenges()).filter(x => x.id !== id)); },
    async challengeValue(cid, uid) {
      const c = (await self.challenges()).find(x => x.id === cid); if (!c) return 0;
      if (c.kind === 'manual') return (LS.get('fr.l.jo') || []).some(j => j.challenge_id === cid && j.user_id === uid && j.manual_done) ? 1 : 0;
      const T = (LS.get('fr.l.trades') || []).filter(x => x.close_time >= c.starts_at && x.close_time <= c.ends_at).sort((a, b) => a.close_time < b.close_time ? -1 : 1), n = T.length, w = T.filter(x => x.profit > 0).length;
      if (c.kind === 'operaciones') return n; if (n < c.min_trades) return 0;
      if (c.kind === 'winrate') return n ? Math.round(1000 * w / n) / 10 : 0; if (c.kind === 'con_sl') return n ? Math.round(1000 * T.filter(x => x.sl).length / n) / 10 : 0;
      if (c.kind === 'racha') { let b = 0, k = 0; T.forEach(x => { k = x.profit > 0 ? k + 1 : 0; b = Math.max(b, k); }); return b; }
      if (c.kind === 'dias_verdes') { const d = {}; T.forEach(x => { const k = x.close_time.slice(0, 10); d[k] = (d[k] || 0) + x.profit; }); return Object.values(d).filter(v => v > 0).length; }
      return 0;
    },
    async challengeBoard(cid) { const c = (await self.challenges()).find(x => x.id === cid), j = (LS.get('fr.l.jo') || []).filter(x => x.challenge_id === cid); return Promise.all(j.map(async x => { const v = await self.challengeValue(cid, x.user_id); return { user_id: x.user_id, alias: me.alias, avatar_url: me.avatar_url, value: v, done: v >= c.target }; })); },
    async ranking() { if (!me) return []; let xp = 0, r = 0; for (const c of await self.challenges()) { if ((LS.get('fr.l.jo') || []).some(j => j.challenge_id === c.id && j.user_id === me.id) && await self.challengeValue(c.id, me.id) >= c.target) { xp += c.xp; r++; } } xp += (LS.get('fr.l.xp') || []).reduce((a, x) => a + x.xp, 0); return [{ user_id: me.id, alias: me.alias, avatar_url: me.avatar_url, xp, retos: r }]; },
    async setManualDone(cid, uid, v) { LS.set('fr.l.jo', (LS.get('fr.l.jo') || []).map(j => j.challenge_id === cid && j.user_id === uid ? { ...j, manual_done: v } : j)); },
    async giveXp(uid, xp, reason) { LS.set('fr.l.xp', [...(LS.get('fr.l.xp') || []), { user_id: uid, xp, reason }]); },
    async myAccess() { return me ? LS.get('fr.acc.' + me.id) : null; },
    async submitAccess(d) { const a = { status: 'pendiente', broker: d.broker, mt5_server: d.server, mt5_login: d.login, balance: d.balance, submitted_at: new Date().toISOString() }; LS.set('fr.acc.' + me.id, a); },
    async accessList() { return me && LS.get('fr.acc.' + me.id) ? [{ user_id: me.id, alias: me.alias, ...LS.get('fr.acc.' + me.id) }] : []; },
    async setAccess(uid, patch) { LS.set('fr.acc.' + uid, { ...(LS.get('fr.acc.' + uid) || {}), ...patch }); },
    async proofUrl() { throw new Error('En modo prueba no se guardan capturas'); },
    async fn() { const e = new Error('Sin servidor'); e.status = 404; throw e; },
  };
  return self;
}

// ---------- modo real: Supabase (registro, perfiles, chat en tiempo real, fotos y audios) ----------
function SupaComm() {
  let sb, session = null, me = null, online = new Set(), presenceCb = () => {}, authCb = () => {}, presence = null, rt = null;
  const subs = [], prof = new Map();
  const trad = m => /Invalid login/i.test(m) ? 'Correo o contraseña incorrectos.' : /Email not confirmed/i.test(m) ? 'Confirma tu correo: te enviamos un enlace al registrarte.' : /already registered|already been registered/i.test(m) ? 'Ya hay una cuenta con ese correo. Entra o recupera la contraseña.' : /Password should be|weak/i.test(m) ? 'La contraseña es demasiado corta o sencilla.' : /duplicate key|profiles_alias/i.test(m) ? 'Ese alias ya está en uso.' : /rate limit|too many/i.test(m) ? 'Demasiados intentos. Espera unos minutos.' : /Failed to fetch|NetworkError/i.test(m) ? 'Sin conexión. Revisa internet.' : m;
  const fail = e => { if (e) throw new Error(trad(e.message || String(e))); };
  async function loadMe() {
    me = null; if (!session) return;
    const { data } = await sb.from('profiles').select('*').eq('id', session.user.id).maybeSingle();
    if (data) { me = { ...data, email: session.user.email }; prof.set(me.id, me); }
    const pend = LS.get('fr.pendingAvatar');
    if (me && pend) { try { await self.uploadAvatar(await (await fetch(pend)).blob()); } catch (e) {} LS.del('fr.pendingAvatar'); }
  }
  function wire() {
    if (presence) { sb.removeChannel(presence); presence = null; } if (rt) { sb.removeChannel(rt); rt = null; }
    online = new Set(); presenceCb();
    if (!me) return;
    presence = sb.channel('presencia', { config: { presence: { key: me.id } } });
    presence.on('presence', { event: 'sync' }, () => { online = new Set(Object.keys(presence.presenceState())); presenceCb(); })
      .subscribe(async st => { if (st === 'SUBSCRIBED') { try { await presence.track({ at: Date.now() }); } catch (e) {} } });
    rt = sb.channel('mensajes')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, async p => { if (!prof.has(p.new.user_id)) { try { await self.members(); } catch (e) {} } subs.forEach(s => s.on(p.new)); })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, p => subs.forEach(s => s.del && s.del(p.old.id)))
      .subscribe();
  }
  const here = () => location.href.split('#')[0];
  const self = {
    mode: 'online',
    async init() {
      await loadScript('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js');
      sb = window.supabase.createClient(SB_URL, SB_KEY);
      session = (await sb.auth.getSession()).data.session; await loadMe(); wire();
      sb.auth.onAuthStateChange((ev, s) => setTimeout(async () => {
        if (ev === 'PASSWORD_RECOVERY') { session = s; authCb('recovery'); return; }
        const was = session && session.user.id, now = s && s.user.id; session = s;
        if (was !== now || ev === 'USER_UPDATED') { await loadMe(); wire(); authCb(ev); }
      }, 0));
    },
    me: () => me, onAuth(cb) { authCb = cb; }, onPresence(cb) { presenceCb = cb; }, online: () => online,
    profile: id => prof.get(id),
    async signUp({ alias, email, password, avatar }) {
      const { data: ex } = await sb.from('profiles').select('id').ilike('alias', alias.replace(/[\\%_]/g, m => '\\' + m)).limit(1);
      if (ex && ex.length) throw new Error('Ese alias ya está en uso.');
      if (avatar) LS.set('fr.pendingAvatar', await blobToData(avatar));
      const { data, error } = await sb.auth.signUp({ email, password, options: { data: { alias }, emailRedirectTo: here() } }); fail(error);
      if (data.user && Array.isArray(data.user.identities) && !data.user.identities.length) throw new Error('Ya hay una cuenta con ese correo. Entra o recupera la contraseña.');
      if (data.session) { session = data.session; await loadMe(); wire(); return { needsConfirm: false }; }
      return { needsConfirm: true };
    },
    async signIn({ email, password }) {
      const { data, error } = await sb.auth.signInWithPassword({ email, password }); fail(error);
      session = data.session; await loadMe(); if (!me) throw new Error('Tu perfil no existe. Revisa la instalación de la base de datos.'); wire();
    },
    async signOut() { await sb.auth.signOut(); session = null; me = null; wire(); },
    async resetPassword(email) { const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: here() }); fail(error); },
    async setPassword(pw) { const { error } = await sb.auth.updateUser({ password: pw }); fail(error); },
    async deleteAccount() { const { error } = await sb.rpc('delete_my_account'); fail(error); try { await sb.auth.signOut(); } catch (e) {} session = null; me = null; wire(); },
    async updateProfile(p) { const { error } = await sb.from('profiles').update(p).eq('id', me.id); fail(error); Object.assign(me, p); prof.set(me.id, me); },
    async uploadAvatar(blob) {
      const path = `${session.user.id}/avatar-${Date.now()}.jpg`;
      const { error } = await sb.storage.from('avatars').upload(path, blob, { contentType: 'image/jpeg' }); fail(error);
      await self.updateProfile({ avatar_url: sb.storage.from('avatars').getPublicUrl(path).data.publicUrl });
    },
    async members() {
      const { data, error } = await sb.from('profiles').select('id,alias,avatar_url,bio,role,created_at').order('created_at', { ascending: false }).limit(1000); fail(error);
      data.forEach(p => prof.set(p.id, me && p.id === me.id ? { ...p, email: me.email } : p)); return data;
    },
    async messages(c) {
      if (!session) return [];
      const { data, error } = await sb.from('messages').select('*').eq('channel', c).order('id', { ascending: false }).limit(100); fail(error);
      const ids = [...new Set(data.map(m => m.user_id))].filter(id => !prof.has(id)); if (ids.length) await self.members();
      return data.reverse();
    },
    async send(c, { kind, body, blob, duration, ext, type }) {
      let media_url = null;
      if (blob) {
        const path = `${session.user.id}/${Date.now()}-${Math.random().toString(36).slice(2, 7)}.${ext}`;
        const { error } = await sb.storage.from('chat').upload(path, blob, { contentType: type }); fail(error);
        media_url = sb.storage.from('chat').getPublicUrl(path).data.publicUrl;
      }
      const { data, error } = await sb.from('messages').insert({ channel: c, user_id: me.id, kind, body: body || null, media_url, duration: duration || null }).select().single(); fail(error);
      subs.forEach(s => s.on(data));
    },
    async remove(id) { const { error } = await sb.from('messages').delete().eq('id', id); fail(error); subs.forEach(s => s.del && s.del(id)); },
    subscribe(on, del) { subs.push({ on, del }); },
    // precios y velas de Vantage
    async prices() { const { data, error } = await sb.from('prices').select('symbol,bid,ask,ts'); fail(error); return data; },
    async candles(s, m) { const { data, error } = await sb.from('candles').select('*').eq('symbol', s).eq('tf', m).order('t', { ascending: false }).limit(500); fail(error); return data.reverse(); },
    // alertas de precio
    async alerts() { if (!me) return []; const { data, error } = await sb.from('alerts').select('*').eq('user_id', me.id).order('id', { ascending: false }).limit(50); fail(error); return data; },
    async addAlert(x) { const { data, error } = await sb.from('alerts').insert({ ...x, user_id: me.id }).select().single(); fail(error); return data; },
    async delAlert(id) { const { error } = await sb.from('alerts').delete().eq('id', id); fail(error); },
    // notificaciones push
    async savePush(x) { const { error } = await sb.from('push_subscriptions').upsert({ ...x, user_id: me.id }, { onConflict: 'endpoint' }); fail(error); },
    async pushPref(endpoint) { const { data } = await sb.from('push_subscriptions').select('chat_pref').eq('endpoint', endpoint).maybeSingle(); return data && data.chat_pref; },
    async deletePush(endpoint) { const { error } = await sb.from('push_subscriptions').delete().eq('endpoint', endpoint); fail(error); },
    // ajustes de la app y administración
    async config() { const { data, error } = await sb.from('app_config').select('value').eq('key', 'app').maybeSingle(); if (error) return null; return data && data.value; },
    async saveConfig(v) { const { error } = await sb.from('app_config').upsert({ key: 'app', value: v, updated_at: new Date().toISOString() }); if (error && /permission|policy|row-level/i.test(error.message)) throw new Error('tu cuenta no es administradora'); fail(error); },
    async isAdmin() { if (!me) return false; const { data, error } = await sb.rpc('is_admin'); return !error && data === true; },
    async bans() { if (!me) return []; const { data, error } = await sb.from('bans').select('user_id'); return error ? [] : data.map(b => b.user_id); },
    async ban(id) { const { error } = await sb.from('bans').insert({ user_id: id }); fail(error); },
    async unban(id) { const { error } = await sb.from('bans').delete().eq('user_id', id); fail(error); },
    // ---------- v3: usuarios, roles, señales, diario y liga ----------
    async news() { const { data, error } = await sb.from('news').select('*').order('posted_at', { ascending: false }).limit(60); if (error) { if (/does not exist|schema cache/i.test(error.message)) return []; throw new Error(error.message); } return data; },
    async addNews(n) { const { error } = await sb.from('news').insert({ ...n, id: 'fortuna/' + Date.now(), channel: 'fortuna' }); if (error) throw new Error(error.message); },
    async deleteNews(id) { const { error } = await sb.from('news').delete().eq('id', id); if (error) throw new Error(error.message); },
    async adminUsers() { const { data, error } = await sb.rpc('admin_users'); if (error) throw new Error(error.message); return data; },
    async deleteUser(id) { const { error } = await sb.rpc('admin_delete_user', { p_user: id }); if (error) throw new Error(error.message); },
    async roles() { const { data, error } = await sb.from('roles').select('*').order('sort'); if (error) return []; return data; },
    async userRoles() { const { data, error } = await sb.from('user_roles').select('*'); if (error) return []; return data; },
    async saveRole(r) { const { error } = await sb.from('roles').upsert(r); if (error) throw new Error(error.message); },
    async deleteRole(id) { const { error } = await sb.from('roles').delete().eq('id', id); if (error) throw new Error(error.message); },
    async setUserRoles(uid, ids) {
      const { error: e1 } = await sb.from('user_roles').delete().eq('user_id', uid); if (e1) throw new Error(e1.message);
      if (ids.length) { const { error } = await sb.from('user_roles').insert(ids.map(role_id => ({ user_id: uid, role_id }))); if (error) throw new Error(error.message); }
    },
    async signals() { const { data, error } = await sb.from('signals').select('*').order('created_at', { ascending: false }).limit(150); if (error) throw new Error(error.message); return data; },
    async saveSignal(s) {
      if (s.id) { const { id, ...rest } = s; const { error } = await sb.from('signals').update(rest).eq('id', id); if (error) throw new Error(error.message); }
      else { const { error } = await sb.from('signals').insert({ ...s, created_by: me.id }); if (error) throw new Error(error.message); }
    },
    async deleteSignal(id) { const { error } = await sb.from('signals').delete().eq('id', id); if (error) throw new Error(error.message); },
    async trades(from, to) { const { data, error } = await sb.from('trades').select('*').eq('user_id', me.id).gte('close_time', from).lt('close_time', to).order('close_time').limit(2000); if (error) throw new Error(error.message); return data; },
    async addTrade(t) { const { error } = await sb.from('trades').insert({ ...t, user_id: me.id, source: 'manual' }); if (error) throw new Error(error.message); },
    async updateTrade(id, p) { const { error } = await sb.from('trades').update(p).eq('id', id); if (error) throw new Error(error.message); },
    async deleteTrade(id) { const { error } = await sb.from('trades').delete().eq('id', id); if (error) throw new Error(error.message); },
    async mtAccounts() { const { data, error } = await sb.from('mt_accounts').select('*').eq('user_id', me.id).order('updated_at', { ascending: false }); if (error) return []; return data; },
    async journalKey(renew) { const { data, error } = await sb.rpc('my_journal_key', { p_new: !!renew }); if (error) throw new Error(error.message); return data; },
    async challenges() { const { data, error } = await sb.from('challenges').select('*').order('ends_at'); if (error) throw new Error(error.message); return data; },
    async joins() { const { data, error } = await sb.from('challenge_joins').select('challenge_id, user_id, manual_done'); if (error) throw new Error(error.message); return data; },
    async join(cid) { const { error } = await sb.from('challenge_joins').insert({ challenge_id: cid, user_id: me.id }); if (error) throw new Error(error.message); },
    async leave(cid) { const { error } = await sb.from('challenge_joins').delete().eq('challenge_id', cid).eq('user_id', me.id); if (error) throw new Error(error.message); },
    async saveChallenge(c) { if (c.id) { const { id, ...rest } = c; const { error } = await sb.from('challenges').update(rest).eq('id', id); if (error) throw new Error(error.message); } else { const { error } = await sb.from('challenges').insert(c); if (error) throw new Error(error.message); } },
    async deleteChallenge(id) { const { error } = await sb.from('challenges').delete().eq('id', id); if (error) throw new Error(error.message); },
    async challengeBoard(cid) { const { data, error } = await sb.rpc('league_challenge', { p_ch: cid }); if (error) throw new Error(error.message); return data; },
    async challengeValue(cid, uid) { const { data, error } = await sb.rpc('challenge_value', { p_ch: cid, p_user: uid }); if (error) throw new Error(error.message); return data; },
    async ranking() { const { data, error } = await sb.rpc('league_ranking'); if (error) throw new Error(error.message); return data; },
    async setManualDone(cid, uid, v) { const { error } = await sb.from('challenge_joins').update({ manual_done: v }).eq('challenge_id', cid).eq('user_id', uid); if (error) throw new Error(error.message); },
    async giveXp(uid, xp, reason) { const { error } = await sb.from('xp_awards').insert({ user_id: uid, xp, reason }); if (error) throw new Error(error.message); },
    async myAccess() {
      if (!me) return null;
      const { data, error } = await sb.from('access').select('status, note, broker, mt5_server, mt5_login, balance, sections, indicators, submitted_at').eq('user_id', me.id).maybeSingle();
      if (error) { if (/does not exist|schema cache|relation/i.test(error.message)) return { status: 'aprobado', sections: ALLSEC, indicators: ALLIND, legacy: true }; throw new Error(error.message); }
      return data;
    },
    async submitAccess(d) {
      let proof = null;
      if (d.file) { const b = await shrink(d.file, 1600); proof = `${me.id}/${Date.now()}.jpg`; const { error } = await sb.storage.from('proofs').upload(proof, b, { contentType: 'image/jpeg' }); if (error) throw new Error('No se pudo subir la captura: ' + error.message); }
      const { error } = await sb.rpc('submit_access', { p_broker: d.broker, p_server: d.server, p_login: d.login, p_investor: d.investor || null, p_balance: d.balance, p_proof: proof });
      if (error) throw new Error(error.message);
    },
    async accessList() { const { data, error } = await sb.from('access').select('*').order('submitted_at', { ascending: false, nullsFirst: false }); if (error) throw new Error(error.message); return data; },
    async setAccess(uid, patch) { const { alias, ...rest } = patch; const { error } = await sb.from('access').upsert({ user_id: uid, ...(alias ? { alias } : {}), ...rest }); if (error) throw new Error(error.message); },
    async proofUrl(path) { const { data, error } = await sb.storage.from('proofs').createSignedUrl(path, 600); if (error) throw new Error(error.message); return data.signedUrl; },
    async fn(name, body) {
      const { data, error } = await sb.functions.invoke(name, { body });
      if (error) { let msg = error.message, code, status = error.context && error.context.status; try { const j = await error.context.json(); msg = j.error || msg; code = j.code; } catch (x) {} const e = new Error(msg); e.code = code; e.status = status; throw e; }
      return data;
    },
    // Respaldo por si el tiempo real no llega: pide los mensajes nuevos
    async poll(c, afterId) {
      if (!session) return;
      const { data, error } = await sb.from('messages').select('*').eq('channel', c).gt('id', afterId || 0).order('id', { ascending: true }).limit(50);
      if (error || !data.length) return;
      if (data.some(m => !prof.has(m.user_id))) { try { await self.members(); } catch (e) {} }
      data.forEach(m => subs.forEach(s => s.on(m)));
    },
  };
  return self;
}
const comm = SB_URL && SB_KEY ? SupaComm() : LocalComm();
function syncUser() { const m = comm.me(); setUser(m ? { id: m.id, alias: m.alias, avatar_url: m.avatar_url } : null); }

// ---------- pestañas de comunidad ----------
RENDER.comunidad = () => {
  $$('#com-seg button').forEach(b => b.setAttribute('aria-pressed', b.dataset.c === comTab));
  $('#com-chat').hidden = comTab !== 'chat'; $('#com-miembros').hidden = comTab !== 'miembros'; $('#com-liga').hidden = comTab !== 'liga';
  if (comTab === 'chat') openChannel(ch); else if (comTab === 'miembros') renderMembers(); else renderLiga();
};
document.addEventListener('click', e => { if (e.target.closest('[data-liga]')) comTab = 'liga'; }, true);
$('#com-seg').onclick = e => { const b = e.target.closest('[data-c]'); if (b) { comTab = b.dataset.c; RENDER.comunidad(); } };

// ---------- chat ----------
let cmsgs = [], loadingCh = null; const unread = {};
const DAYF = new Intl.DateTimeFormat('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
function dayLabel(d) { const t = new Date(); t.setHours(0, 0, 0, 0); const x = new Date(d); x.setHours(0, 0, 0, 0); const diff = (t - x) / 864e5; return diff === 0 ? 'Hoy' : diff === 1 ? 'Ayer' : DAYF.format(x); }
const fmtDur = s => { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const EMO_ONLY = /^(?:\p{Extended_Pictographic}|\p{Emoji_Component}|‍|️|\s)+$/u;
function richText(t) {
  return esc(t).replace(/https:\/\/[^\s<]+/g, u => `<a href="${u}" target="_blank" rel="noopener">${u}</a>`).replace(/(^|\s)@([\p{L}\p{N}_.\-]{3,20})/gu, '$1<b class="mn">@$2</b>');
}
function waveBars(seedStr) { let h = hashN(seedStr); return Array.from({ length: 28 }, () => { h = (h * 1103515245 + 12345) & 0x7fffffff; return `<i style="height:${25 + (h % 75)}%"></i>`; }).join(''); }
function msgHTML(m, prev, next) {
  if (m.kind === 'sys') return `<div class="sysm">${esc(m.body)}</div>`;
  const meId = comm.me() && comm.me().id, out = m.user_id === meId, p = comm.profile(m.user_id) || { alias: 'Miembro', id: m.user_id };
  const same = x => x && x.kind !== 'sys' && x.user_id === m.user_id && Math.abs(new Date(x.created_at) - new Date(m.created_at)) < 5 * 6e4 && dayLabel(x.created_at) === dayLabel(m.created_at);
  const first = !same(prev), last = !same(next);
  const time = `<span class="meta">${hm(m.created_at)}${out ? ' ✓✓' : ''}</span>`;
  const name = !out && first ? `<div class="nm" data-prof="${esc(m.user_id)}" style="color:${AVC[hashN(p.alias) % AVC.length] === '#7c4dff' ? '#b39dff' : '#f2c14e'}">${esc(p.alias)}${roleBadge(m.user_id) || (p.role === 'mentor' ? '<small>mentor</small>' : '')}</div>` : '';
  let body = '', cls = '';
  if (m.kind === 'image' && okUrl(m.media_url)) { cls = 'pic'; body = `${name}<img class="ph" src="${esc(m.media_url)}" alt="Foto" loading="lazy" data-full="${esc(m.media_url)}">${m.body ? `<div class="tx" style="padding:4px 7px 0">${richText(m.body)}</div>` : ''}${time}`; }
  else if (m.kind === 'audio' && okUrl(m.media_url)) body = `${name}<div class="au" data-src="${esc(m.media_url)}" data-dur="${Number(m.duration) || 0}"><button class="play" aria-label="Reproducir audio"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></button><div style="flex:1"><div class="wave">${waveBars(m.id)}</div><span class="dur">${fmtDur(m.duration)}</span></div></div>${time}`;
  else { const t = String(m.body || ''); if (t.length <= 12 && EMO_ONLY.test(t) && /\p{Extended_Pictographic}/u.test(t)) cls = 'big'; body = `${name}<div class="tx">${richText(t)}</div>${time}`; }
  const slot = out ? '' : `<span class="slot" data-prof="${esc(m.user_id)}">${last ? avHTML(p, 34) : ''}</span>`;
  return `<div class="bm ${out ? 'out' : 'in'}${first ? ' first' : ''}${last ? ' last' : ''}" data-id="${esc(m.id)}">${slot}<div class="bb ${cls}">${body}</div></div>`;
}
function renderChatList(stick) {
  const box = $('#msgs'), near = box.scrollHeight - box.scrollTop - box.clientHeight < 120;
  let h = '', lastDay = '';
  if (!cmsgs.length) h = `<div class="sysm">Todavía no hay mensajes en #${esc(CHANNELS.find(c => c[0] === ch)[1])}. ¡Rompe el hielo! 👋</div>`;
  cmsgs.forEach((m, i) => { const d = dayLabel(m.created_at); if (d !== lastDay) { h += `<div class="day">${esc(d)}</div>`; lastDay = d; } h += msgHTML(m, cmsgs[i - 1], cmsgs[i + 1]); });
  box.innerHTML = h;
  if (stick || near) box.scrollTop = box.scrollHeight;
}
const chans = () => CHANNELS.filter(c => c[0] !== 'mentorias' || !mentLocked());
function renderChans() { if (!chans().some(c => c[0] === ch)) ch = 'general'; $('#chans').innerHTML = chans().map(([k, n]) => `<button data-ch="${k}" aria-selected="${k === ch}"># ${n}${unread[k] ? `<span class="ub">${unread[k]}</span>` : ''}</button>`).join(''); }
function renderOnline() { const n = comm.online().size; const t = n ? `● ${n} en línea` : ''; $('#online').textContent = t; $('#m-online').textContent = t; }
function renderGate() {
  const me = comm.me();
  $('#send').hidden = !me; $('#gate').hidden = !!me; if (me) return;
  $('#emojis').hidden = true;
  $('#gate').innerHTML = `<p>${comm.mode === 'online' ? 'Únete para leer y escribir en la comunidad.' : 'Crea tu perfil para escribir en el chat.'}</p><button class="btn gold full" data-go="cuenta">Crear cuenta o entrar</button>`;
}
async function openChannel(c) {
  ch = c; unread[c] = 0; renderChans(); renderGate(); renderOnline();
  if (comm.mode === 'online' && !comm.me()) { cmsgs = []; $('#msgs').innerHTML = '<div class="sysm">🔒 El chat es solo para miembros registrados.</div>'; return; }
  loadingCh = c; $('#msgs').innerHTML = '<div class="sysm">Cargando mensajes…</div>';
  try { const list = await comm.messages(c); if (loadingCh !== c) return; cmsgs = list; } catch (e) { cmsgs = []; toast(e.message); }
  renderChatList(true);
}
$('#chans').onclick = e => { const b = e.target.closest('[data-ch]'); if (b) openChannel(b.dataset.ch); };
comm.subscribe(m => {
  const yo = comm.me();
  if (yo && m.user_id !== yo.id && m.body && m.body.toLowerCase().includes('@' + yo.alias.toLowerCase()) && !(view === 'comunidad' && comTab === 'chat' && ch === m.channel)) {
    const p = comm.profile(m.user_id); toast(`💬 ${p ? p.alias : 'Alguien'} te ha mencionado en #${(CHANNELS.find(c => c[0] === m.channel) || [, m.channel])[1]}`);
    if (navigator.vibrate) try { navigator.vibrate(40); } catch (e) {}
  }
  if (m.channel !== ch || !(view === 'comunidad' && comTab === 'chat')) { if (!comm.me() || m.user_id !== comm.me().id) { unread[m.channel] = (unread[m.channel] || 0) + 1; if (view === 'comunidad') renderChans(); } if (m.channel !== ch) return; }
  if (cmsgs.some(x => String(x.id) === String(m.id))) return;
  cmsgs.push(m); if (view === 'comunidad' && comTab === 'chat') renderChatList(comm.me() && m.user_id === comm.me().id);
}, id => { const i = cmsgs.findIndex(x => String(x.id) === String(id)); if (i >= 0) { cmsgs.splice(i, 1); if (view === 'comunidad' && comTab === 'chat') renderChatList(); } });
comm.onPresence(() => { renderOnline(); if (view === 'comunidad' && comTab === 'miembros') renderMembers(true); });
$('#msgs').addEventListener('scroll', () => { const b = $('#msgs'); $('#tobottom').hidden = b.scrollHeight - b.scrollTop - b.clientHeight < 300; }, { passive: true });
setInterval(() => {
  if (comm.mode !== 'online' || !comm.poll || !comm.me() || document.hidden || !(view === 'comunidad' && comTab === 'chat')) return;
  const last = cmsgs.filter(m => typeof m.id === 'number').reduce((x, m) => Math.max(x, m.id), 0);
  comm.poll(ch, last).catch(() => {});
}, 4000);
$('#tobottom').onclick = () => { const b = $('#msgs'); b.scrollTo({ top: b.scrollHeight, behavior: 'smooth' }); };

// componer: texto, emojis, fotos y audios
const ICON_MIC = '<path d="M12 15a3.5 3.5 0 0 0 3.5-3.5v-6a3.5 3.5 0 0 0-7 0v6A3.5 3.5 0 0 0 12 15zm6-3.5h-1.8a4.2 4.2 0 0 1-8.4 0H6a6 6 0 0 0 5 5.9V21h2v-3.6a6 6 0 0 0 5-5.9z"/>';
const ICON_SEND = '<path d="M3 20l18-8L3 4v6l12 2-12 2z"/>';
const ta = $('#msg');
function mainBtn() { const has = ta.value.trim().length > 0; $('#b-main-ic').innerHTML = has ? ICON_SEND : ICON_MIC; $('#b-main').setAttribute('aria-label', has ? 'Enviar' : 'Grabar audio'); }
function grow() { ta.style.height = 'auto'; ta.style.height = Math.min(130, ta.scrollHeight) + 'px'; }
ta.addEventListener('input', () => { grow(); mainBtn(); });
ta.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && matchMedia('(pointer:fine)').matches) { e.preventDefault(); sendText(); } });
$('#send').onsubmit = e => { e.preventDefault(); sendText(); };
$('#b-main').onclick = () => ta.value.trim() ? sendText() : startRec();
mainBtn();
async function sendMsg(o) {
  if (!comm.me()) { toast('Crea tu cuenta para escribir'); show('cuenta'); return false; }
  try { await comm.send(ch, o); return true; } catch (e) { toast(e.message); return false; }
}
async function sendText() {
  const t = ta.value.trim(); if (!t) return;
  if (t === '/precio') { ta.value = ''; grow(); mainBtn(); cmsgs.push({ id: 's' + Date.now(), kind: 'sys', body: `XAUUSD cotiza a ${dec(px.XAUUSD)} (${sg(chg('XAUUSD'))} % en 24 h)`, created_at: new Date().toISOString() }); renderChatList(true); return; }
  ta.value = ''; grow(); mainBtn();
  if (!(await sendMsg({ kind: 'text', body: t }))) { ta.value = t; grow(); mainBtn(); }
}
// emojis
const EMO = {
  'Caras': '😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😎 🤩 🥳 🤔 🤨 😐 🙄 😏 😴 😮 😲 😳 🥺 😢 😭 😤 😠 😡 🤯 😱 🤗 🤭 🤫 🤑 🤠 😬 🫠 🥲',
  'Gestos': '👍 👎 👏 🙌 🙏 💪 🤝 ✌️ 🤞 👌 🤙 👊 ✊ 👋 🫡 👀 🧠 ❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💯 🔥 ✨ ⭐ 🌟 ⚡ 💥 🎉 🎊',
  'Trading': '📈 📉 📊 💹 💰 💵 💶 💸 🪙 🥇 🏆 🎯 🚀 🌕 🐂 🐻 ⏰ 🔔 📣 ⚠️ ✅ ❌ 🛑 🟢 🔴 🟡 💎 🏦 🧾 🕯️ 🧮 🔍',
  'Objetos': '☕ 🍕 🍺 🥂 🎧 📱 💻 ⌚ 📅 📌 🔒 🔑 🎁 🏖️ ✈️ 🌍 🌙 ☀️ 🌧️ ⛈️ 🎮 ⚽ 🏀 🎵',
};
let emoCat = 'Caras';
function renderEmo() { $('#etabs').innerHTML = Object.keys(EMO).map(k => `<button type="button" data-ec="${k}" aria-pressed="${k === emoCat}">${k}</button>`).join(''); $('#egrid').innerHTML = EMO[emoCat].split(' ').map(e => `<button type="button" data-e="${e}">${e}</button>`).join(''); }
$('#b-emoji').onclick = () => { const p = $('#emojis'); p.hidden = !p.hidden; $('#b-emoji').setAttribute('aria-pressed', !p.hidden); if (!p.hidden) renderEmo(); const b = $('#msgs'); b.scrollTop = b.scrollHeight; };
$('#etabs').onclick = e => { const b = e.target.closest('[data-ec]'); if (b) { emoCat = b.dataset.ec; renderEmo(); } };
$('#egrid').onclick = e => { const b = e.target.closest('[data-e]'); if (!b) return; const s = ta.selectionStart ?? ta.value.length, en = ta.selectionEnd ?? ta.value.length; ta.value = ta.value.slice(0, s) + b.dataset.e + ta.value.slice(en); const p = s + b.dataset.e.length; try { ta.setSelectionRange(p, p); } catch (x) {} grow(); mainBtn(); };
// fotos
$('#b-attach').onclick = () => { if (!comm.me()) { toast('Crea tu cuenta para enviar fotos'); show('cuenta'); return; } $('#f-photo').click(); };
$('#f-photo').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  if (!/^image\//.test(f.type)) return toast('Elige una imagen');
  toast('Enviando foto…');
  try { const blob = await shrink(f, 1280, false); await sendMsg({ kind: 'image', blob, ext: 'jpg', type: 'image/jpeg', body: ta.value.trim() || null }); ta.value = ''; grow(); mainBtn(); } catch (x) { toast(x.message); }
};
// audios
let rec = null;
async function startRec() {
  if (!comm.me()) { toast('Crea tu cuenta para enviar audios'); show('cuenta'); return; }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) return toast('Aquí no se puede grabar audio. Usa la app instalada o Safari/Chrome.');
  let stream; try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); } catch (e) { return toast('Sin permiso de micrófono. Actívalo en los ajustes del móvil.'); }
  const type = ['audio/mp4', 'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus'].find(t => MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t)) || '';
  let mr; try { mr = new MediaRecorder(stream, type ? { mimeType: type } : {}); } catch (e) { stream.getTracks().forEach(t => t.stop()); return toast('No se pudo empezar a grabar.'); }
  const chunks = []; mr.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
  rec = { mr, stream, chunks, t0: Date.now(), type: mr.mimeType || type || 'audio/webm' };
  rec.timer = setInterval(() => { const s = (Date.now() - rec.t0) / 1000; $('#rec-t').textContent = fmtDur(s); if (s >= 120) stopRec(true); }, 250);
  mr.start(250); $('#rec').hidden = false; $('#send').hidden = true; $('#emojis').hidden = true; $('#rec-t').textContent = '0:00';
  if (navigator.vibrate) try { navigator.vibrate(15); } catch (e) {}
}
function stopRec(send) {
  const r = rec; if (!r) return; rec = null; clearInterval(r.timer);
  r.mr.onstop = async () => {
    r.stream.getTracks().forEach(t => t.stop()); $('#rec').hidden = true; $('#send').hidden = false;
    if (!send) return;
    const dur = (Date.now() - r.t0) / 1000; if (dur < 1) return toast('Audio demasiado corto');
    const mime = r.type.split(';')[0], blob = new Blob(r.chunks, { type: mime }), ext = /mp4|aac|m4a/.test(mime) ? 'm4a' : /ogg/.test(mime) ? 'ogg' : 'webm';
    await sendMsg({ kind: 'audio', blob, duration: dur, ext, type: mime });
  };
  try { r.mr.stop(); } catch (e) { r.mr.onstop(); }
}
$('#rec-x').onclick = () => stopRec(false); $('#rec-ok').onclick = () => stopRec(true);
// reproducción de audios, fotos y perfiles
const player = new Audio(); let playing = null;
function setPlayIcon(au, on) { au.querySelector('.play').innerHTML = `<svg viewBox="0 0 24 24">${on ? '<path d="M6 5h4v14H6zm8 0h4v14h-4z"/>' : '<path d="M8 5v14l11-7z"/>'}</svg>`; }
player.addEventListener('timeupdate', () => { if (!playing) return; const d = player.duration && isFinite(player.duration) ? player.duration : Number(playing.dataset.dur) || 1, k = player.currentTime / d, bars = playing.querySelectorAll('.wave i'); bars.forEach((b, i) => b.classList.toggle('on', i / bars.length < k)); playing.querySelector('.dur').textContent = fmtDur(player.currentTime) + ' / ' + fmtDur(d); });
player.addEventListener('ended', () => { if (playing) { setPlayIcon(playing, false); playing.querySelectorAll('.wave i').forEach(b => b.classList.remove('on')); playing.querySelector('.dur').textContent = fmtDur(playing.dataset.dur); } playing = null; });
$('#msgs').addEventListener('click', e => {
  const pl = e.target.closest('.au .play');
  if (pl) { const au = pl.closest('.au'); if (playing === au && !player.paused) { player.pause(); setPlayIcon(au, false); return; } if (playing && playing !== au) setPlayIcon(playing, false); if (playing !== au) { player.src = au.dataset.src; playing = au; } player.play().then(() => setPlayIcon(au, true)).catch(() => toast('No se pudo reproducir este audio en este móvil')); return; }
  const ph = e.target.closest('.ph'); if (ph) { $('#lb-img').src = ph.dataset.full; $('#lb').hidden = false; return; }
  const pr = e.target.closest('[data-prof]'); if (pr) { profileSheet(pr.dataset.prof); return; }
});
$('#lb').onclick = () => { $('#lb').hidden = true; $('#lb-img').removeAttribute('src'); };
// mantener pulsado un mensaje propio: copiar o eliminar
let lpT = 0;
$('#msgs').addEventListener('pointerdown', e => { const bm = e.target.closest('.bm'); if (!bm || e.target.closest('.play,.ph')) return; lpT = setTimeout(() => msgMenu(bm.dataset.id), 520); });
['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => $('#msgs').addEventListener(ev, () => clearTimeout(lpT)));
$('#msgs').addEventListener('scroll', () => clearTimeout(lpT), { passive: true });
function msgMenu(id) {
  const m = cmsgs.find(x => String(x.id) === String(id)); if (!m || m.kind === 'sys') return;
  const mine = comm.me() && m.user_id === comm.me().id;
  sheet('Mensaje', `${m.body ? '<button class="opt" data-act="copy"><b>Copiar texto</b></button>' : ''}${!mine ? '<button class="opt" data-act="reply"><b>Mencionar al autor</b></button>' : ''}${mine || ADMIN || roleOf(meIdX()).some(r => r.can_moderate) ? `<button class="opt" data-act="del"><b style="color:var(--dn)">Eliminar mensaje${mine ? '' : ' (admin)'}</b></button>` : ''}${ADMIN && !mine ? `<button class="opt" data-act="ban"><b style="color:var(--dn)">${BANS.has(m.user_id) ? 'Desbloquear usuario' : 'Bloquear usuario (no podrá escribir)'}</b></button>` : ''}<button class="opt" data-act="x"><b>Cancelar</b></button>`, el => el.onclick = async e => {
    const a = e.target.closest('[data-act]'); if (!a) return; closeSheet();
    if (a.dataset.act === 'copy') { try { await navigator.clipboard.writeText(m.body); toast('Copiado'); } catch (x) { toast('No se pudo copiar'); } }
    if (a.dataset.act === 'reply') { const p = comm.profile(m.user_id); if (p) { ta.value = `@${p.alias} ` + ta.value; grow(); mainBtn(); ta.focus(); } }
    if (a.dataset.act === 'del') { try { await comm.remove(m.id); toast('Mensaje eliminado'); } catch (x) { toast(x.message); } }
    if (a.dataset.act === 'ban') { const u = m.user_id, p = comm.profile(u); try { if (BANS.has(u)) { await comm.unban(u); BANS.delete(u); toast('Usuario desbloqueado'); } else { await comm.ban(u); BANS.add(u); toast((p ? p.alias : 'Usuario') + ' bloqueado: ya no puede escribir'); } } catch (x) { toast(x.message); } }
  });
}
function profileSheet(id) {
  const p = comm.profile(id); if (!p) return; const isMe = comm.me() && comm.me().id === id;
  sheet(p.alias, `<div class="psheet">${avHTML(p, 110, comm.online().has(id))}<p>${p.role === 'mentor' ? '<span class="role">Mentor</span> ' : ''}Miembro desde ${new Date(p.created_at || Date.now()).toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}</p>${p.bio ? `<p style="color:var(--ink)">${esc(p.bio)}</p>` : ''}${isMe ? '<button class="btn gold full" data-go="cuenta">Editar mi perfil</button>' : `<button class="btn gold full" data-mention="${esc(p.alias)}">Mencionar en el chat</button>`}</div>`, el => el.onclick = e => {
    const b = e.target.closest('[data-mention]'); if (b) { closeSheet(); comTab = 'chat'; show('comunidad'); ta.value = `@${b.dataset.mention} ` + ta.value; grow(); mainBtn(); }
    if (e.target.closest('[data-go]')) closeSheet();
  });
}
// ---------- miembros ----------
let memberList = [];
async function renderMembers(quiet) {
  if (!quiet) { try { memberList = await comm.members(); } catch (e) { toast(e.message); } }
  const q = $('#m-q').value.trim().toLowerCase(), on = comm.online(), meId = comm.me() && comm.me().id;
  const list = memberList.filter(p => !q || p.alias.toLowerCase().includes(q)).sort((a, b) => (b.id === meId) - (a.id === meId) || on.has(b.id) - on.has(a.id) || (b.role === 'mentor') - (a.role === 'mentor'));
  $('#m-count').textContent = `${memberList.length} miembro${memberList.length === 1 ? '' : 's'}`; renderOnline();
  $('#mgrid').innerHTML = list.map(p => `<div class="mcard" data-prof="${esc(p.id)}" role="button" tabindex="0">${avHTML(p, 64, on.has(p.id))}<b>${esc(p.alias)}</b>${roleBadge(p.id)}${p.id === meId ? '<span class="youb">Tú</span>' : ''}<p>${esc(p.bio || 'Trader de la comunidad')}</p></div>`).join('') || '<p class="sub">Nadie coincide con la búsqueda.</p>';
}
$('#m-q').oninput = () => renderMembers(true);
$('#mgrid').onclick = e => { const c = e.target.closest('[data-prof]'); if (c) profileSheet(c.dataset.prof); };

const SEASON_END = new Date('2026-12-31T23:59:59+01:00');
const RC = ['#f2c14e', '#4fc3f7', '#3ddc97', '#b388ff', '#ff8a65'];
let traders = [], prevPos = {};
function curve(dr, vo, n = 30) { let v = 1e4; const a = [v]; for (let i = 1; i < n; i++) { v *= 1 + dr + (rnd() - .5) * vo; a.push(v); } return a; }
function stats(t) { if (t.curve && t.curve.length > 1 && !t.fixed) { const c = t.curve; t.gain = (c[c.length - 1] / c[0] - 1) * 100; let pk = c[0], dd = 0; for (const v of c) { pk = Math.max(pk, v); dd = Math.max(dd, (pk - v) / pk * 100); } t.dd = dd; } t.gain = t.gain || 0; t.dd = t.dd || 0; t.score = Math.round(10 * (t.gain - .5 * t.dd)); t.ok = t.trades >= 10; return t; }
function badges(t) { const b = []; if (t.pos <= 3 && t.ok) b.push('Podio'); if (t.win >= 65) b.push('Francotirador'); if (t.dd < 5 && t.ok) b.push('Nervios de acero'); if (t.trades >= 150) b.push('Hiperactivo'); return b; }
const SEED = [['LoboDeWallSt', 'MT5', .006, .03], ['PipHunter', 'MT4', .004, .018], ['Carmen_FX', 'MT5', .005, .012], ['ScalperZen', 'MT5', .003, .04], ['ToroBravo', 'MT4', .007, .055], ['NoaTrades', 'MT5', .002, .01], ['Draco88', 'MT4', -.001, .03], ['GoldDigger', 'MT5', .005, .035], ['Martina.V', 'MT5', .0025, .015], ['SwingKing', 'MT4', .001, .02], ['Iker_Pips', 'MT5', .0035, .025], ['LunaCapital', 'MT5', .004, .02], ['Novato21', 'MT5', .001, .05]];
function demoLeague() { traders = SEED.map(([alias, platform, dr, vo], i) => stats({ id: 'd' + i, alias, platform, curve: curve(dr, vo), trades: i === 12 ? 6 : Math.round(20 + rnd() * 200), win: Math.round(42 + rnd() * 30) })); const m = LS.get('fr.mt'); if (m && user) traders.push(stats({ ...m, me: true, alias: user.alias })); }
function ranked() { const a = [...traders].sort((x, y) => (y.ok - x.ok) || (y.score - x.score)); a.forEach((t, i) => t.pos = i + 1); return a; }
function renderLigaOld() {
  const s = Math.max(0, SEASON_END - Date.now()) / 1000; $('#clock').textContent = `${Math.floor(s / 86400)} d ${Math.floor(s % 86400 / 3600)} h`;
  const all = ranked(), q = $('#q').value.trim().toLowerCase(), pf = $('#pf').value;
  $('#cta-link').hidden = all.some(t => t.me);
  const top = all.filter(t => t.ok).slice(0, 3), ord = [top[1], top[0], top[2]];
  $('#podium').innerHTML = ord.map((t, i) => t ? `<div class="step p${[2, 1, 3][i]}"><div class="who">${esc(t.alias)}</div><div class="g">${sg(t.gain, 1)} % · ${t.score}</div><div class="blk">${['II', 'I', 'III'][i]}</div></div>` : '<div></div>').join('');
  $('#rows').innerHTML = all.filter(t => (!pf || t.platform === pf) && (!q || t.alias.toLowerCase().includes(q))).map(t => {
    const p = prevPos[t.id], mv = p && p !== t.pos ? `<span class="mv ${p > t.pos ? 'u' : 'd'}">${p > t.pos ? '▲' : '▼'}${Math.abs(p - t.pos)}</span>` : '';
    return `<div class="rk ${t.me ? 'me' : ''} ${t.ok ? '' : 'out'}"><div class="pos">${t.ok ? t.pos : '–'}${mv}</div><div><b>${esc(t.alias)}</b>${t.me ? ' (tú)' : ''}<span class="tag ${t.platform === 'MT5' ? 'mt5' : ''}">${esc(t.platform)}</span><div class="badges">${t.ok ? badges(t).map(x => `<span>${esc(x)}</span>`).join('') : '<span>Sin clasificar</span>'}</div><small>DD ${dec(t.dd, 1)} % · ${Number(t.trades)} ops · ${Number(t.win)} % acierto</small></div><div class="r"><b class="${t.gain >= 0 ? 'u' : 'd'}">${sg(t.gain, 1)} %</b><small>${t.score} pts</small></div></div>`;
  }).join('') || '<p class="sub">Ningún trader coincide.</p>';
  all.forEach(t => prevPos[t.id] = t.pos);
  raceSet = all.filter(t => t.ok).slice(0, 5); drawRace();
}
const race = $('#race'); let raceSet = [];
function drawRace() {
  const W = race.clientWidth, H = race.clientHeight; if (!W) return;
  const se = raceSet.filter(t => t.curve && t.curve.length > 1).map(t => t.curve.map(v => (v / t.curve[0] - 1) * 100));
  if (!se.length) { race.innerHTML = ''; $('#legend').innerHTML = '<span>Aún no hay datos suficientes</span>'; return; }
  const n = Math.max(...se.map(s => s.length)); let lo = Math.min(0, ...se.flat()), hi = Math.max(1, ...se.flat()); const pd = (hi - lo) * .08; lo -= pd; hi += pd;
  const L = 32, R = 8, T = 8, B = 20, x = i => L + i / Math.max(1, n - 1) * (W - L - R), y = v => T + (hi - v) / (hi - lo) * (H - T - B);
  const st = Math.max(1, Math.ceil((hi - lo) / 4 / 5) * 5), ticks = []; for (let v = Math.ceil(lo / st) * st; v <= hi; v += st) ticks.push(v);
  race.innerHTML = ticks.map(v => `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)"/><text x="${L - 5}" y="${y(v) + 4}" font-size="11" text-anchor="end" fill="var(--mute)">${v}%</text>`).join('') + se.map((s, k) => `<polyline fill="none" stroke="${RC[k]}" stroke-width="${k ? 2 : 3}" stroke-linejoin="round" points="${s.map((v, i) => x(i + n - s.length).toFixed(1) + ',' + y(v).toFixed(1)).join(' ')}"/>`).join('');
  $('#legend').innerHTML = raceSet.map((t, k) => `<span><i style="background:${RC[k]}"></i>${t.pos}. ${esc(t.alias)}</span>`).join('');
}
const raceRO = new ResizeObserver(drawRace); raceRO.observe(race);
$('#q').oninput = renderLigaOld; $('#pf').onchange = renderLigaOld;
async function loadLeague() { const j = await api('/api/leaderboard'); traders = j.traders.map(t => stats({ ...t, fixed: true })); if (view === 'comunidad' && comTab === 'liga') renderLigaOld(); }
function leagueTick() { if (LIVE) return; for (const t of traders) if (rnd() < .5) { const c = t.curve; c[c.length - 1] *= 1 + (rnd() - .47) * .006; if (rnd() < .15) t.trades++; stats(t); } const me = traders.find(t => t.me); if (me) LS.set('fr.mt', me); if (view === 'comunidad' && comTab === 'liga') renderLigaOld(); }

// =============== MENTORÍAS ===============
let MENT = null, booked = new Set(LS.get('fr.book') || []), done = new Set(LS.get('fr.course') || []);
function demoMent() {
  const at = (d, h) => { const x = new Date(); x.setDate(x.getDate() + d); x.setHours(h, 0, 0, 0); return x.toISOString(); };
  MENT = { mentors: [
    { id: 'laura', name: 'Laura Méndez', role: 'Price action en oro', bio: 'Soportes, resistencias y lectura de velas en XAUUSD.', color: '#d9961b' },
    { id: 'diego', name: 'Diego Arce', role: 'Indicadores y sistemas', bio: 'Medias, RSI y MACD aplicados con reglas claras.', color: '#8a6a1c' },
    { id: 'sara', name: 'Sara Vidal', role: 'Riesgo y psicología', bio: 'Gestión del capital, diario y control emocional.', color: '#7c4dff' }],
    sessions: [
    { id: 's1', title: 'Análisis semanal de XAUUSD', mentorId: 'laura', start: at(1, 19), durationMin: 60, capacity: 50, booked: 31 },
    { id: 's2', title: 'Cómo usar el RSI sin engañarte', mentorId: 'diego', start: at(2, 19), durationMin: 45, capacity: 40, booked: 18 },
    { id: 's3', title: 'Revisión de operaciones de la liga', mentorId: 'laura', start: at(4, 20), durationMin: 75, capacity: 30, booked: 27 },
    { id: 's4', title: 'Gestión del riesgo: la regla del 1 %', mentorId: 'sara', start: at(6, 19), durationMin: 60, capacity: 60, booked: 12 }] };
  MENT.sessions.forEach(s => { s.mine = booked.has(s.id); if (s.mine) s.booked++; });
}
const COURSE = [
  { t: 'Fundamentos del oro', l: [
    ['Qué mueve al XAUUSD', 'El oro cotiza en dólares, así que un dólar fuerte suele presionarlo a la baja. También le afectan los tipos de interés reales (cuando suben, el oro, que no paga intereses, pierde atractivo) y su papel de refugio en momentos de miedo.'],
    ['Sesiones y volatilidad', 'El mayor movimiento suele darse en Londres y en el solape con Nueva York; Asia acostumbra a ser más tranquila. Los datos de EE. UU. (empleo, inflación, Reserva Federal) provocan picos de volatilidad.'],
    ['Spread, swap y contrato', 'En la mayoría de brókers 1 lote = 100 onzas: 1 $ de movimiento vale 100 $ por lote. El spread se ensancha con noticias y en el cambio de día; el swap se cobra o paga por mantener posiciones de un día a otro.']] },
  { t: 'Análisis técnico', l: [
    ['Soportes y resistencias', 'Zonas donde el precio reaccionó antes. Piensa en zonas, no en líneas exactas: cuantos más toques y más alta la temporalidad, más relevantes. Dibújalas con la herramienta Horizontal o Rectángulo del gráfico.'],
    ['Medias EMA 20, 50 y 200', 'Precio y EMA 50 por encima de la EMA 200 describen un contexto alcista (y al revés). La EMA 20 sirve de referencia para retrocesos en tendencias fuertes.'],
    ['RSI y MACD', 'RSI por encima de 70 indica sobrecompra y por debajo de 30 sobreventa, pero en tendencias fuertes puede quedarse ahí mucho tiempo. El cruce del MACD con su señal confirma cambios de impulso: úsalos para confirmar, no como única razón para entrar.'],
    ['Fibonacci', 'Traza el Fibonacci desde el inicio hasta el final de un impulso. Los retrocesos del 38,2 %, 50 % y 61,8 % son zonas que muchos traders vigilan para reincorporarse a la tendencia.']] },
  { t: 'Riesgo y psicología', l: [
    ['La regla del 1 %', 'Arriesga como máximo un porcentaje pequeño del capital en cada operación. Con un 1 % hacen falta muchas pérdidas seguidas para dañar seriamente la cuenta.'],
    ['Calcular el lotaje', 'Lotes = (capital × riesgo %) ÷ (distancia al stop en $ × 100). Ejemplo: 10.000 $, 1 % y stop a 5 $ → 100 ÷ 500 = 0,20 lotes. Tienes la calculadora en Más.'],
    ['Drawdown y diario', 'Una caída del 20 % necesita un +25 % para recuperarse; una del 50 %, un +100 %. Apunta cada operación en el diario para detectar los errores que repites.']] },
];
const upcoming = () => [...MENT.sessions].filter(s => new Date(s.start).getTime() + s.durationMin * 6e4 > Date.now()).sort((a, b) => new Date(a.start) - new Date(b.start));
const when = iso => new Date(iso).toLocaleString('es-ES', { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
const safeColor = c => /^#[0-9a-f]{3,6}$/i.test(c || '') ? c : '#0d5c45';
RENDER.mentorias = () => {
  const lk = mentLocked(); $('#ment-lock').hidden = !lk; $('#ment-body').hidden = lk;
  $('#ment-lock').innerHTML = lk ? `<div class="lockbox"><div class="lk">🔒</div><h2>Mentorías · muy pronto</h2><p>${esc(CFG.ment.msg)}</p></div>` : '';
  $('#ment-admin').hidden = !(ADMIN && CFG.ment.locked);
  if (lk || !MENT) return; const mentor = id => MENT.mentors.find(m => m.id === id) || { name: '' };
  const ss = upcoming(), nx = ss[0];
  $('#next').innerHTML = nx ? `<div class="date"><b>${new Date(nx.start).getDate()}</b>${new Date(nx.start).toLocaleDateString('es-ES', { month: 'short' })}</div><div><p>Próxima sesión · ${hm(nx.start)} · ${nx.durationMin} min</p><h3>${esc(nx.title)}</h3><p>con ${esc(mentor(nx.mentorId).name)}${nx.mine && nx.link && /^https:\/\//.test(nx.link) ? ` · <a href="${esc(nx.link)}" target="_blank" rel="noopener">Entrar a la sala</a>` : ''}</p></div><button class="btn gold" data-book="${esc(nx.id)}">${nx.mine ? 'Plaza reservada ✓' : 'Reservar plaza'}</button>` : '<div><h3>No hay sesiones programadas</h3></div>';
  $('#sessions').innerHTML = ss.slice(1).map(s => `<div class="mses"><span class="when">${esc(when(s.start))}</span><h3>${esc(s.title)}</h3><span class="sub">${esc(mentor(s.mentorId).name)} · ${s.durationMin} min · ${s.booked}/${s.capacity} plazas</span><div class="meter"><i style="width:${Math.min(100, s.booked / s.capacity * 100)}%"></i></div><button class="btn ${s.mine ? 'ghost' : 'gold'} sm" data-book="${esc(s.id)}" ${!s.mine && s.booked >= s.capacity ? 'disabled' : ''}>${s.mine ? 'Reservada · cancelar' : s.booked >= s.capacity ? 'Completa' : 'Reservar plaza'}</button></div>`).join('');
  const total = COURSE.reduce((a, m) => a + m.l.length, 0); $('#prog').textContent = `${done.size}/${total} lecciones`;
  $('#course').innerHTML = COURSE.map((m, i) => { const d = m.l.filter((_, j) => done.has(i + '.' + j)).length; return `<div class="mod"><h3><span>${i + 1}. ${esc(m.t)}</span><span class="sub">${d}/${m.l.length}</span></h3><div class="meter" style="margin:10px 0"><i style="width:${d / m.l.length * 100}%"></i></div>${m.l.map(([t, x], j) => { const k = i + '.' + j, ok = done.has(k); return `<details><summary><span class="${ok ? 'ok' : ''}">${ok ? '✓' : '○'}</span>${esc(t)}</summary><p>${esc(x)}</p><button class="btn ${ok ? 'ghost' : 'gold'} sm" data-lesson="${k}">${ok ? 'Marcar como pendiente' : 'Marcar como vista'}</button></details>`; }).join('')}</div>`; }).join('');
  $('#mentors').innerHTML = MENT.mentors.map(m => `<div class="mentor"><div class="av" style="background:${safeColor(m.color)}">${esc(m.name[0])}</div><div><b>${esc(m.name)}</b><p>${esc(m.role)}</p><p>${esc(m.bio)}</p></div></div>`).join('');
};
$('#v-mentorias').addEventListener('click', async e => {
  if (mentLocked()) return;
  const l = e.target.closest('[data-lesson]');
  if (l) { const k = l.dataset.lesson; done.has(k) ? done.delete(k) : done.add(k); LS.set('fr.course', [...done]); RENDER.mentorias(); const again = $(`[data-lesson="${k}"]`); if (again) again.closest('details').open = true; return; }
  const b = e.target.closest('[data-book]'); if (!b) return;
  if (!user) { toast('Entra con tu alias para reservar'); show('cuenta'); return; }
  const s = MENT.sessions.find(x => x.id === b.dataset.book);
  if (LIVE) { try { Object.assign(s, await api(`/api/mentorias/${encodeURIComponent(s.id)}/reserva`, { method: 'POST' })); } catch (x) { return toast(x.message); } }
  else { s.mine = !s.mine; s.booked += s.mine ? 1 : -1; s.mine ? booked.add(s.id) : booked.delete(s.id); LS.set('fr.book', [...booked]); }
  toast(s.mine ? 'Plaza reservada: ' + s.title : 'Reserva cancelada'); RENDER.mentorias();
});
async function loadMent() { try { MENT = await api('/api/mentorias'); } catch (e) {} }

// =============== AJUSTES DE LA APP Y ADMINISTRADOR ===============
const CFG_DEF = {
  badge: 'Beta',
  banner: { on: false, text: '', link: '' },
  ment: { locked: true, msg: 'Muy pronto abriremos las mentorías en directo con el equipo de Fortuna Radiante. ¡Te avisaremos aquí!' },
  install: { apk: 'https://github.com/jose14881488lunacoco-lab/fortuna-radiante/releases/latest/download/FortunaRadiante.apk', web: 'https://jose14881488lunacoco-lab.github.io/fortuna-radiante/' },
};
const mergeCfg = v => ({ ...CFG_DEF, ...v, banner: { ...CFG_DEF.banner, ...(v && v.banner) }, ment: { ...CFG_DEF.ment, ...(v && v.ment) }, install: { ...CFG_DEF.install, ...(v && v.install) }, market: { ...((v && v.market) || {}) }, news: { ...((v && v.news) || {}) } });
let CFG = mergeCfg(LS.get('fr.cfg') || {}), ADMIN = false, BANS = new Set();
const safeUrl = u => /^https:\/\/[^\s"'<>]+$/i.test(u || '') ? u : '';
async function loadCfg() {
  try { const v = await comm.config(); if (v) { CFG = mergeCfg(v); LS.set('fr.cfg', v); } } catch (e) {}
  try { ADMIN = await comm.isAdmin(); } catch (e) { ADMIN = false; }
  try { BANS = new Set(await comm.bans()); } catch (e) {}
  applyCfg();
}
function applyCfg() {
  modeBadge();
  const mt = CFG.ment;
  if (mt.sessions && mt.sessions.length) { MENT = { mentors: mt.mentors || [], sessions: mt.sessions.map(s => ({ ...s, booked: (s.booked || 0) + (booked.has(s.id) ? 1 : 0), mine: booked.has(s.id) })) }; }
  $('#adm-link').hidden = !ADMIN;
  const bn = $('#banner'); if (bn) { const b = CFG.banner, url = safeUrl(b.link); bn.hidden = !(b.on && b.text); bn.innerHTML = b.on && b.text ? `<span>📣</span><p>${esc(b.text)}</p>${url ? `<a href="${esc(url)}" target="_blank" rel="noopener">Ver</a>` : ''}` : ''; }
  if (RENDER[view] && ['inicio', 'mentorias', 'instalar', 'admin', 'mas'].includes(view)) RENDER[view]();
}
const mentLocked = () => CFG.ment.locked && !ADMIN;
RENDER.mas = () => { $('#adm-link').hidden = !ADMIN; const m = $('#ment-link small'); if (m) m.textContent = CFG.ment.locked ? '🔒 Muy pronto' : 'Sesiones en directo y ruta del trader'; };
RENDER.instalar = () => {
  const ins = CFG.install, apk = safeUrl(ins.apk), web = safeUrl(ins.web);
  $('#inst-links').innerHTML = `
    ${apk ? `<a class="btn gold full" href="${esc(apk)}" target="_blank" rel="noopener">🤖 Descargar para Android (APK)</a>` : ''}
    ${web ? `<a class="btn ghost full" href="${esc(web)}" target="_blank" rel="noopener">🍏 App web (iPhone y ordenador)</a>` : ''}
    ${web ? `<div class="linkbox"><span>${esc(web)}</span><button class="btn ghost sm" id="inst-copy">Copiar</button></div><button class="btn ghost full" id="inst-share">Compartir enlace con un amigo</button>` : ''}`;
  const c = $('#inst-copy'); if (c) c.onclick = async () => { try { await navigator.clipboard.writeText(web); toast('Enlace copiado'); } catch (e) { toast('Mantén pulsado el enlace para copiarlo'); } };
  const s = $('#inst-share'); if (s) s.onclick = async () => { const txt = `Fortuna Radiante · la app de trading del oro\n\nAndroid: ${apk}\niPhone: abre ${web} en Safari → Compartir → Añadir a pantalla de inicio`; try { if (navigator.share) await navigator.share({ title: 'Fortuna Radiante', text: txt }); else { await navigator.clipboard.writeText(txt); toast('Enlaces copiados: pégalos en WhatsApp'); } } catch (e) {} };
};
// ---------- panel de administrador ----------
RENDER.admin = async () => {
  const box = $('#adm');
  if (!ADMIN) { box.innerHTML = '<div class="card"><p class="sub" style="margin:0">🔒 Solo el administrador puede ver esta sección.</p></div>'; return; }
  const c = CFG, mt = c.ment, ses = mt.sessions || [], mens = mt.mentors || [];
  let members = []; try { members = await comm.members(); } catch (e) {}
  const banned = members.filter(p => BANS.has(p.id));
  const sw = (id, on) => `<button class="sw-t" role="switch" aria-checked="${!!on}" id="${id}" type="button"></button>`;
  box.innerHTML = `
  <div class="admgrid"><a class="card adm alink" href="#accesos"><h3>👥 Usuarios</h3><span class="badge2">${ACC_PEND || ''}</span><p class="sub">Correos, cuentas MT5, aprobar, permisos, silenciar, expulsar y eliminar.</p></a>
  <a class="card adm alink" href="#roles"><h3>🏷️ Roles</h3><p class="sub">Crea roles (Analista, VIP…) y quién publica señales o modera.</p></a>
  <a class="card adm alink" href="#senales"><h3>📡 Señales</h3><p class="sub">Publica señales con entrada, SL y TP. Avisa a todos.</p></a>
  <a class="card adm alink" href="#comunidad" data-liga><h3>🏆 Retos</h3><p class="sub">Crea retos de la liga y da XP.</p></a>
  <a class="card adm alink" href="#noticias"><h3>📰 Noticias</h3><p class="sub">Canal de Telegram traducido y noticias propias.</p></a></div>
  ${comm.mode === 'demo' ? '<div class="demo-note">Modo prueba: estos cambios solo se guardan en este móvil. Con la comunidad conectada se aplican a todos.</div>' : ''}
  <div class="card adm"><h3>General</h3>
    <label>Etiqueta de la cabecera<input id="a-badge" maxlength="12" value="${esc(c.badge)}"></label>
  </div>
  <div class="card adm"><div class="hd"><h3>Anuncio en Inicio</h3>${sw('a-bn-on', c.banner.on)}</div>
    <label>Texto del anuncio<textarea id="a-bn-text" maxlength="200" rows="3">${esc(c.banner.text)}</textarea></label>
    <label>Enlace (opcional, empieza por https://)<input id="a-bn-link" value="${esc(c.banner.link)}" placeholder="https://…"></label>
  </div>
  <div class="card adm"><div class="hd"><h3>Mentorías bloqueadas</h3>${sw('a-m-lock', mt.locked)}</div>
    <p class="sub">Si está activado, los miembros ven un candado y el mensaje de abajo. Tú siempre las ves.</p>
    <label>Mensaje para los miembros<textarea id="a-m-msg" maxlength="240" rows="3">${esc(mt.msg)}</textarea></label>
    <h4>Mentores</h4><div id="a-mens">${mens.map((m, i) => `<div class="arow"><input data-mn="${i}" data-f="name" value="${esc(m.name)}" placeholder="Nombre"><input data-mn="${i}" data-f="role" value="${esc(m.role || '')}" placeholder="Especialidad"><button class="x" data-delmn="${i}" type="button" aria-label="Quitar">×</button></div>`).join('')}</div>
    <button class="btn ghost sm" id="a-addmn" type="button">+ Añadir mentor</button>
    <h4>Sesiones</h4><div id="a-ses">${ses.map((s, i) => `<div class="aset"><input data-sn="${i}" data-f="title" value="${esc(s.title)}" placeholder="Título"><label class="al">Fecha y hora<input type="datetime-local" data-sn="${i}" data-f="start" value="${esc(toLocalInput(s.start))}"></label><div class="arow"><label class="al">Minutos<input data-sn="${i}" data-f="durationMin" inputmode="numeric" value="${s.durationMin}"></label><label class="al">Plazas<input data-sn="${i}" data-f="capacity" inputmode="numeric" value="${s.capacity}"></label></div><label class="al">Mentor<select data-sn="${i}" data-f="mentorId">${mens.map(m => `<option value="${esc(m.id)}"${m.id === s.mentorId ? ' selected' : ''}>${esc(m.name)}</option>`).join('')}</select></label><div class="arow"><input data-sn="${i}" data-f="link" value="${esc(s.link || '')}" placeholder="Enlace Zoom / Meet (https://…)"><button class="x" data-delsn="${i}" type="button" aria-label="Quitar">×</button></div></div>`).join('') || '<p class="sub">Sin sesiones propias: se muestran las de ejemplo.</p>'}</div>
    <button class="btn ghost sm" id="a-addsn" type="button">+ Añadir sesión</button>
  </div>
  <div class="card adm"><h3>Enlaces para instalar</h3>
    <label>Descarga Android (APK)<input id="a-apk" value="${esc(c.install.apk)}"></label>
    <label>App web (iPhone y ordenador)<input id="a-web" value="${esc(c.install.web)}"></label>
  </div>
  <div class="card adm"><h3>Usuarios bloqueados</h3>
    <p class="sub">Un usuario bloqueado no puede escribir en el chat. Para bloquear a alguien: mantén pulsado uno de sus mensajes → «Bloquear usuario».</p>
    ${banned.length ? banned.map(p => `<div class="arow"><b style="flex:1">${esc(p.alias)}</b><button class="btn ghost sm" data-unban="${esc(p.id)}" type="button">Desbloquear</button></div>`).join('') : '<p class="sub">Nadie bloqueado.</p>'}
  </div>
  <button class="btn gold full" id="a-save" type="button">Guardar cambios</button>
  <p class="fine">Los cambios se ven al momento en la app de todos (web, Android e iPhone).</p>`;
  const st = { mentors: JSON.parse(JSON.stringify(mens)), sessions: JSON.parse(JSON.stringify(ses)) };
  if (!st.mentors.length && MENT) st.mentors = JSON.parse(JSON.stringify(MENT.mentors)).map(m => ({ id: m.id, name: m.name, role: m.role, bio: m.bio || '', color: m.color }));
  box.onclick = async e => {
    const t = e.target;
    if (t.classList.contains('sw-t')) { t.setAttribute('aria-checked', t.getAttribute('aria-checked') !== 'true'); return; }
    if (t.id === 'a-addmn') { collect(); st.mentors.push({ id: 'm' + Date.now().toString(36), name: '', role: '', bio: '', color: '#d9961b' }); redraw(); return; }
    if (t.id === 'a-addsn') { collect(); const d = new Date(); d.setDate(d.getDate() + 1); d.setHours(19, 0, 0, 0); st.sessions.push({ id: 's' + Date.now().toString(36), title: '', mentorId: (st.mentors[0] || {}).id || '', start: d.toISOString(), durationMin: 60, capacity: 50, booked: 0, link: '' }); redraw(); return; }
    if (t.dataset.delmn != null) { collect(); st.mentors.splice(+t.dataset.delmn, 1); redraw(); return; }
    if (t.dataset.delsn != null) { collect(); st.sessions.splice(+t.dataset.delsn, 1); redraw(); return; }
    if (t.dataset.unban) { try { await comm.unban(t.dataset.unban); BANS.delete(t.dataset.unban); toast('Usuario desbloqueado'); RENDER.admin(); } catch (x) { toast(x.message); } return; }
    if (t.id === 'a-save') {
      collect();
      const v = { badge: $('#a-badge').value.trim().slice(0, 12) || 'Beta',
        banner: { on: $('#a-bn-on').getAttribute('aria-checked') === 'true', text: $('#a-bn-text').value.trim(), link: $('#a-bn-link').value.trim() },
        ment: { locked: $('#a-m-lock').getAttribute('aria-checked') === 'true', msg: $('#a-m-msg').value.trim() || CFG_DEF.ment.msg, mentors: st.mentors.filter(m => m.name.trim()), sessions: st.sessions.filter(s => s.title.trim()) },
        install: { apk: $('#a-apk').value.trim(), web: $('#a-web').value.trim() } };
      if (v.banner.link && !safeUrl(v.banner.link)) return toast('El enlace del anuncio debe empezar por https://');
      if ((v.install.apk && !safeUrl(v.install.apk)) || (v.install.web && !safeUrl(v.install.web))) return toast('Los enlaces deben empezar por https://');
      if (v.ment.sessions.some(s => s.link && !safeUrl(s.link))) return toast('Los enlaces de las sesiones deben empezar por https://');
      t.disabled = true;
      try { await comm.saveConfig(v); CFG = mergeCfg(v); LS.set('fr.cfg', v); if (!v.ment.sessions.length) demoMent(); applyCfg(); toast('✅ Cambios guardados para todos'); }
      catch (x) { toast('No se pudo guardar: ' + x.message); } finally { t.disabled = false; }
    }
  };
  function collect() {
    $$('#a-mens [data-mn]').forEach(i => { const m = st.mentors[+i.dataset.mn]; if (m) m[i.dataset.f] = i.value; });
    $$('#a-ses [data-sn]').forEach(i => { const s = st.sessions[+i.dataset.sn]; if (!s) return; const f = i.dataset.f; s[f] = f === 'start' ? (i.value ? new Date(i.value).toISOString() : s.start) : f === 'durationMin' || f === 'capacity' ? Math.max(1, parseInt(i.value) || 1) : i.value; });
  }
  function redraw() {
    const keep = { badge: $('#a-badge').value, bnOn: $('#a-bn-on').getAttribute('aria-checked') === 'true', bnText: $('#a-bn-text').value, bnLink: $('#a-bn-link').value, lock: $('#a-m-lock').getAttribute('aria-checked') === 'true', msg: $('#a-m-msg').value, apk: $('#a-apk').value, web: $('#a-web').value };
    const prev = CFG; CFG = mergeCfg({ badge: keep.badge, banner: { on: keep.bnOn, text: keep.bnText, link: keep.bnLink }, ment: { locked: keep.lock, msg: keep.msg, mentors: st.mentors, sessions: st.sessions }, install: { apk: keep.apk, web: keep.web } });
    const sc = $('#main').scrollTop; RENDER.admin().then(() => { CFG = prev; $('#main').scrollTop = sc; });
  }
};
// =============== ACCESO: registro → MT5 → verificación del admin ===============
const SECTIONS = [['grafico', 'Gráfico'], ['mercado', 'Centro de mercado'], ['senales', 'Señales Fortuna'], ['fortunaty', 'Fortunaty (IA)'], ['comunidad', 'Chat y miembros'], ['liga', 'Liga y retos'], ['diario', 'Diario de operaciones'], ['noticias', 'Noticias Fortuna'], ['mentorias', 'Mentorías'], ['herramientas', 'Calculadoras']];
const INDS = [['zones', 'ProZones (zonas de compra y venta)'], ['dxy', 'Panel DXY (zonas)'], ['ses', 'Sesiones de mercado'], ['ema', 'Medias móviles EMA'], ['bb', 'Bandas de Bollinger'], ['piv', 'Pivotes diarios'], ['rsi', 'RSI'], ['macd', 'MACD'], ['vp', 'Volume Profile'], ['div', 'Divergencias RSI']];
const VIEW_SEC = { grafico: 'grafico', mercado: 'mercado', senales: 'senales', fortunaty: 'fortunaty', comunidad: 'comunidad', mentorias: 'mentorias', utiles: 'herramientas', diario: 'diario', noticias: 'noticias' };
const ALLSEC = Object.fromEntries(SECTIONS.map(([k]) => [k, true])), ALLIND = Object.fromEntries(INDS.map(([k]) => [k, true]));
let ACC = null, ACC_OK = false, CFG_OK = false, accEdit = false, blockedSec = null;
const gate = () => !comm.me() ? 'login' : !(ACC_OK && CFG_OK) ? 'wait' : ADMIN || (ACC && ACC.status === 'aprobado') ? 'ok' : 'acceso';
const canSec = k => ADMIN || !!(ACC && ACC.status === 'aprobado' && (ACC.sections || {})[k]);
const canInd = k => ADMIN || !!(ACC && ACC.status === 'aprobado' && (ACC.indicators || {})[k]);
async function loadAccess() {
  if (!comm.me()) { ACC = null; ACC_OK = true; return; }
  try { ACC = await comm.myAccess(); } catch (e) { ACC = ACC || null; }
  ACC_OK = true;
}
async function boot() {
  CFG_OK = ACC_OK = false; applyGate();
  await Promise.all([loadCfg().finally(() => { CFG_OK = true; }), loadAccess()]);
  loadRoles().then(() => { if (view === 'comunidad') RENDER.comunidad(); });
  applyGate();
  if (ADMIN) { try { const n = (await comm.accessList()).filter(a => a.status === 'pendiente').length; ACC_PEND = n; updPend(); if (n) toast(`Tienes ${n} solicitud${n > 1 ? 'es' : ''} de acceso pendiente${n > 1 ? 's' : ''}`); } catch (e) {} }
}
let ACC_PEND = 0;
function updPend() { const b = $('#acc-pend'); if (b) { b.textContent = ACC_PEND; b.hidden = !ACC_PEND; } }
function applyGate() {
  const g = gate();
  $('#app').classList.toggle('locked-app', g !== 'ok');
  $$('.tabbar a').forEach(a => { const s = VIEW_SEC[a.dataset.t]; a.classList.toggle('locked', g === 'ok' && !!s && !canSec(s)); });
  if (typeof panes !== 'undefined') applyIndGate();
  show(WANT || (view && !['acceso', 'cuenta', 'bloqueado'].includes(view) ? view : (location.hash.slice(1) || 'inicio')));
}
// re-comprobar el acceso (aprobación, expulsión, permisos nuevos)
setInterval(async () => {
  if (!comm.me() || ADMIN || document.hidden) return;
  const before = JSON.stringify(ACC); await loadAccess();
  if (JSON.stringify(ACC) !== before) { applyGate(); if (ACC && ACC.status === 'aprobado') toast('✅ Tu acceso se ha actualizado'); }
}, 30000);
function applyIndGate() {
  (panes || []).forEach(p => { if (!p || !p.chart) return; const ind = p.chart.getInd(), off = {}; INDS.forEach(([k]) => { if (!canInd(k) && ind[k] && ind[k].on) off[k] = { on: false }; }); if (Object.keys(off).length) p.chart.setInd(off); });
}
// pantalla para quien aún no tiene acceso
RENDER.acceso = () => {
  const el = $('#acc'), me = comm.me(), a = ACC, logout = '<button class="btn ghost full" id="acc-out" type="button" style="margin-top:12px">Cerrar sesión</button>';
  const hero = (t, s) => `<div class="auth-hero"><img src="icons/logo-192.png" alt=""><h1>${t}</h1><p class="sub" style="margin:0">${s}</p></div>`;
  if (gate() === 'wait') el.innerHTML = '<div class="acc-wait"><div class="spin"></div><p class="sub">Comprobando tu acceso…</p></div>';
  else if (a && a.status === 'expulsado') el.innerHTML = hero('Acceso retirado', 'El administrador ha retirado tu acceso a Fortuna Radiante.') + (a.note ? `<div class="card"><b>Motivo</b><p class="sub" style="margin:6px 0 0">${esc(a.note)}</p></div>` : '') + logout;
  else if (a && a.status === 'pendiente' && !accEdit) el.innerHTML = hero('Estamos verificando tu cuenta', 'El equipo está comprobando tu cuenta de MT5. En cuanto se apruebe entrarás automáticamente.') + `
    <div class="card accsum"><div><span>Bróker</span><b>${esc(a.broker || '—')}</b></div><div><span>Servidor</span><b>${esc(a.mt5_server || '—')}</b></div><div><span>Cuenta</span><b>${esc(a.mt5_login || '—')}</b></div><div><span>Saldo indicado</span><b>${a.balance != null ? esc(dec(+a.balance)) + ' $' : '—'}</b></div></div>
    <div class="steps3"><span class="ok">1 · Cuenta creada</span><span class="ok">2 · MT5 enviado</span><span class="cur">3 · Verificación</span></div>
    <button class="btn gold full" id="acc-chk" type="button">Comprobar ahora</button><button class="btn ghost full" id="acc-ed" type="button" style="margin-top:10px">Corregir mis datos</button>${logout}`;
  else el.innerHTML = hero('Vincula tu cuenta MT5', 'Paso 2 de 2 · Para entrar necesitamos comprobar que tienes una cuenta real con saldo en el bróker.') + (a && a.status === 'rechazado' ? `<div class="card rej"><b>Solicitud rechazada</b><p class="sub" style="margin:6px 0 0">${esc(a.note || 'Revisa tus datos y vuelve a enviarlos.')}</p></div>` : '') + `
    <form class="card authbox" id="mt5f" novalidate>
      <label>Bróker<input id="m-broker" maxlength="60" value="${esc((a && a.broker) || 'Vantage Markets')}"></label>
      <label>Servidor de MT5<input id="m-server" maxlength="80" placeholder="Ej.: VantageInternational-Live 3" value="${esc((a && a.mt5_server) || '')}"><small class="sub">En MT5: menú ☰ → Gestionar cuentas, aparece debajo de tu número de cuenta.</small></label>
      <label>Número de cuenta (login)<input id="m-login" inputmode="numeric" maxlength="12" value="${esc((a && a.mt5_login) || '')}"></label>
      <label>Contraseña de inversor (opcional)<input id="m-inv" type="password" maxlength="64" autocomplete="off"><small class="sub">Es la de <b>solo lectura</b>: permite ver la cuenta pero no operar. <b>Nunca</b> pongas tu contraseña principal. Se borra en cuanto el equipo revisa tu solicitud.</small></label>
      <label>Saldo aproximado (USD)<input id="m-bal" inputmode="decimal" value="${a && a.balance != null ? esc(a.balance) : ''}"></label>
      <label>Captura del saldo en MT5 (recomendado)<input type="file" id="m-proof" accept="image/*"><small class="sub">Haz una captura de la pestaña «Operaciones» donde se ve el balance.</small></label>
      <p class="err" id="m-err" role="alert"></p>
      <button class="btn gold full" id="m-go">Enviar para verificar</button>
    </form>${accEdit ? '<button class="btn ghost full" id="acc-cancel" type="button">Cancelar</button>' : ''}${logout}`;
  el.onclick = async e => {
    const t = e.target;
    if (t.id === 'acc-out') { await comm.signOut(); ACC = null; accEdit = false; syncUser(); applyGate(); }
    if (t.id === 'acc-chk') { t.disabled = true; await loadAccess(); applyGate(); if (ACC && ACC.status === 'pendiente') toast('Todavía en revisión. Te avisaremos.'); }
    if (t.id === 'acc-ed') { accEdit = true; RENDER.acceso(); }
    if (t.id === 'acc-cancel') { accEdit = false; RENDER.acceso(); }
  };
  const f = $('#mt5f'); if (f) f.onsubmit = async e => {
    e.preventDefault(); const err = $('#m-err'), go = $('#m-go');
    const d = { broker: $('#m-broker').value.trim(), server: $('#m-server').value.trim(), login: $('#m-login').value.replace(/\s/g, ''), investor: $('#m-inv').value, balance: $('#m-bal').value.trim() ? num($('#m-bal').value) : null, file: $('#m-proof').files[0] || null };
    if (!/^\d{4,12}$/.test(d.login)) return err.textContent = 'Escribe tu número de cuenta MT5 (solo números).';
    if (!d.server) return err.textContent = 'Escribe el servidor de MT5.';
    if (d.balance != null && !isFinite(d.balance)) return err.textContent = 'El saldo debe ser un número.';
    err.textContent = ''; go.disabled = true; go.textContent = 'Enviando…';
    try { await comm.submitAccess(d); accEdit = false; await loadAccess(); applyGate(); toast('Enviado. El equipo revisará tu cuenta.'); }
    catch (x) { err.textContent = x.message; go.disabled = false; go.textContent = 'Enviar para verificar'; }
  };
};
RENDER.bloqueado = () => {
  const name = (SECTIONS.find(s => s[0] === blockedSec) || [, 'esta sección'])[1];
  $('#blk').innerHTML = `<div class="lockbox" style="margin-top:20px"><div class="lk">🔒</div><h2>${esc(name)}</h2><p>El administrador todavía no te ha dado acceso a esta sección. Si crees que es un error, escríbele por el chat.</p></div>`;
};
// ---------- panel de accesos (admin) ----------
let accTab = 'pendiente';
RENDER.accesos = async () => {
  const box = $('#accs'); if (!ADMIN) { box.innerHTML = '<p class="sub">Solo para el administrador.</p>'; return; }
  box.innerHTML = '<div class="acc-wait"><div class="spin"></div></div>';
  let list = [], members = [];
  try { [list, members] = await Promise.all([comm.accessList(), comm.members()]); } catch (e) { box.innerHTML = `<div class="card rej">No se pudo cargar: ${esc(e.message)}. ¿Has ejecutado <b>admin-supabase.sql</b>?</div>`; return; }
  const byId = Object.fromEntries(list.map(a => [a.user_id, a])), me = comm.me();
  const sinv = members.filter(m => !byId[m.id] && (!me || m.id !== me.id)).map(m => ({ user_id: m.id, alias: m.alias, status: 'sin', avatar_url: m.avatar_url }));
  const groups = { pendiente: list.filter(a => a.status === 'pendiente'), aprobado: list.filter(a => a.status === 'aprobado'), sin: sinv, rechazado: list.filter(a => a.status === 'rechazado'), expulsado: list.filter(a => a.status === 'expulsado') };
  ACC_PEND = groups.pendiente.length; updPend();
  const names = { pendiente: 'Pendientes', aprobado: 'Aprobados', sin: 'Sin vincular', rechazado: 'Rechazados', expulsado: 'Expulsados' };
  const card = a => { const m = members.find(x => x.id === a.user_id) || a, d = a.submitted_at ? new Date(a.submitted_at).toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' }) : '';
    const secs = a.status === 'aprobado' ? SECTIONS.filter(([k]) => (a.sections || {})[k]).length : 0, inds = a.status === 'aprobado' ? INDS.filter(([k]) => (a.indicators || {})[k]).length : 0;
    return `<div class="card acard" data-u="${esc(a.user_id)}"><div class="ahd">${avHTML({ alias: m.alias || a.alias || '?', avatar_url: m.avatar_url }, 40)}<div style="min-width:0;flex:1"><b>${esc(m.alias || a.alias || 'Sin alias')}</b><div class="sub">${esc(a.email || '')}${d ? ' · ' + d : ''}</div></div></div>
      ${a.mt5_login ? `<div class="accsum"><div><span>Bróker</span><b>${esc(a.broker || '—')}</b></div><div><span>Servidor</span><b>${esc(a.mt5_server || '—')}</b></div><div><span>Cuenta</span><b>${esc(a.mt5_login)}</b></div><div><span>Saldo indicado</span><b>${a.balance != null ? esc(dec(+a.balance)) + ' $' : '—'}</b></div>${a.investor_pw ? `<div style="grid-column:1/-1"><span>Contraseña de inversor</span><b class="pw" data-pw="${esc(a.investor_pw)}">•••••••• <button class="linkb" data-act="pw" type="button">Mostrar</button></b></div>` : ''}</div>` : a.status !== 'sin' ? '' : '<p class="sub" style="margin:0">Se registró pero todavía no ha enviado su cuenta MT5.</p>'}
      ${a.status === 'aprobado' ? `<p class="sub" style="margin:0">Secciones: ${secs}/${SECTIONS.length} · Indicadores: ${inds}/${INDS.length}</p>` : ''}
      ${a.note ? `<p class="sub" style="margin:0">Motivo: ${esc(a.note)}</p>` : ''}
      <div class="row2">${a.proof_path ? '<button class="btn ghost sm" data-act="proof" type="button">Ver captura</button>' : ''}
      ${a.status === 'pendiente' || a.status === 'rechazado' || a.status === 'sin' ? '<button class="btn gold sm" data-act="ok" type="button">Aprobar</button>' : ''}
      ${a.status === 'pendiente' ? '<button class="btn ghost sm" data-act="no" type="button">Rechazar</button>' : ''}
      ${a.status === 'aprobado' ? '<button class="btn gold sm" data-act="ok" type="button">Permisos</button>' : ''}
      ${a.status === 'expulsado' ? '<button class="btn gold sm" data-act="ok" type="button">Readmitir</button>' : '<button class="btn sm danger" data-act="out" type="button">Expulsar</button>'}</div></div>`; };
  box.innerHTML = `<div class="segm wrap">${Object.keys(groups).map(k => `<button type="button" data-at="${k}" aria-pressed="${k === accTab}">${names[k]} <span class="cnt">${groups[k].length}</span></button>`).join('')}</div>
    ${groups[accTab].map(card).join('') || `<p class="sub" style="text-align:center;margin:30px 0">No hay nadie en «${names[accTab]}».</p>`}`;
  box.onclick = async e => {
    const tb = e.target.closest('[data-at]'); if (tb) { accTab = tb.dataset.at; RENDER.accesos(); return; }
    const b = e.target.closest('[data-act]'); if (!b) return; const cardEl = b.closest('[data-u]'), uid = cardEl.dataset.u, a = byId[uid] || groups.sin.find(x => x.user_id === uid), alias = (members.find(x => x.id === uid) || a).alias;
    const act = b.dataset.act;
    if (act === 'pw') { const w = b.closest('.pw'); w.textContent = w.dataset.pw; return; }
    if (act === 'proof') { try { $('#lb-img').src = await comm.proofUrl(a.proof_path); $('#lb').hidden = false; } catch (x) { toast(x.message); } return; }
    if (act === 'ok') return permSheet(uid, alias, a);
    if (act === 'no' || act === 'out') {
      const out = act === 'out';
      sheet(out ? 'Expulsar a ' + alias : 'Rechazar a ' + alias, `<p class="sub">${out ? 'No podrá entrar en la app ni leer ni escribir en el chat. Puedes readmitirle más tarde.' : 'Verá el motivo y podrá corregir sus datos y volver a enviarlos.'}</p><label class="fl">Motivo (lo verá el usuario)<textarea id="ac-note" rows="3" maxlength="240">${out ? '' : 'No hemos podido comprobar el saldo de la cuenta.'}</textarea></label><button class="btn ${out ? 'danger' : 'gold'} full" id="ac-go" type="button">${out ? 'Expulsar de la app' : 'Rechazar solicitud'}</button>`, el => {
        $('#ac-go').onclick = async () => { try { await comm.setAccess(uid, { status: out ? 'expulsado' : 'rechazado', note: $('#ac-note').value.trim() || null, alias }); closeSheet(); toast(out ? alias + ' ha sido expulsado' : 'Solicitud rechazada'); RENDER.accesos(); } catch (x) { toast(x.message); } };
      });
    }
  };
};
function permSheet(uid, alias, a) {
  const fresh = !a || a.status !== 'aprobado', sec = fresh ? { ...ALLSEC } : { ...(a.sections || {}) }, ind = fresh ? {} : { ...(a.indicators || {}) };
  const row = (g, k, l, on) => `<label class="chk"><input type="checkbox" data-g="${g}" data-k="${k}"${on ? ' checked' : ''}><span>${esc(l)}</span></label>`;
  sheet((fresh ? 'Dar acceso a ' : 'Permisos de ') + alias, `
    <h4 class="og2">Zonas de la app <button class="linkb" data-all="s" type="button">Todas</button> · <button class="linkb" data-none="s" type="button">Ninguna</button></h4>${SECTIONS.map(([k, l]) => row('s', k, l, sec[k])).join('')}
    <h4 class="og2">Indicadores <button class="linkb" data-all="i" type="button">Todos</button> · <button class="linkb" data-none="i" type="button">Ninguno</button></h4>${INDS.map(([k, l]) => row('i', k, l, ind[k])).join('')}
    <button class="btn gold full" id="pm-go" type="button" style="margin-top:14px">${fresh ? 'Aprobar y dar acceso' : 'Guardar permisos'}</button>`, el => {
    el.onclick = async e => {
      const al = e.target.closest('[data-all],[data-none]'); if (al) { const g = al.dataset.all || al.dataset.none; $$(`#sheet-c input[data-g="${g}"]`).forEach(i => i.checked = !!al.dataset.all); return; }
      if (e.target.id !== 'pm-go') return;
      const s = {}, i2 = {}; $$('#sheet-c input[data-g="s"]').forEach(i => s[i.dataset.k] = i.checked); $$('#sheet-c input[data-g="i"]').forEach(i => i2[i.dataset.k] = i.checked);
      try { await comm.setAccess(uid, { status: 'aprobado', sections: s, indicators: i2, note: null, alias }); closeSheet(); toast('✅ ' + alias + (fresh ? ' ya tiene acceso' : ': permisos guardados')); RENDER.accesos(); } catch (x) { toast(x.message); }
    };
  });
}

// =============== TRADINGVIEW (precios y gráficos en tiempo real) ===============
const TVS = { XAUUSD: 'OANDA:XAUUSD', DXY: 'TVC:DXY', BTCUSD: 'BITSTAMP:BTCUSD', USOIL: 'TVC:USOIL' };
function tvEmbed(el, type, cfg, h) {
  if (!el) return;
  el.innerHTML = `<div class="tradingview-widget-container" style="height:${h || '100%'}"><div class="tradingview-widget-container__widget" style="height:${h ? 'calc(100% - 20px)' : '100%'}"></div><div class="tv-cr"><a href="https://es.tradingview.com/" rel="noopener nofollow" target="_blank">Datos de TradingView</a></div></div>`;
  const s = document.createElement('script'); s.src = `https://s3.tradingview.com/external-embedding/embed-widget-${type}.js`; s.async = true;
  s.textContent = JSON.stringify({ locale: 'es', colorTheme: 'dark', isTransparent: true, ...cfg });
  s.onerror = () => { el.innerHTML = '<p class="sub tv-off">No se pudo cargar TradingView (sin conexión o bloqueado en esta vista).</p>'; };
  el.firstChild.appendChild(s);
}
function tvTicker() {
  const host = $('#tk-tv'); if (!host) return;
  tvEmbed(host, 'ticker-tape', { symbols: [{ proName: 'OANDA:XAUUSD', title: 'Oro' }, { proName: 'TVC:DXY', title: 'DXY' }, { proName: 'BITSTAMP:BTCUSD', title: 'Bitcoin' }, { proName: 'TVC:USOIL', title: 'Petróleo' }, { proName: 'FX:EURUSD', title: 'EURUSD' }, { proName: 'TVC:US10Y', title: 'Bono EE. UU. 10A' }, { proName: 'OANDA:XAGUSD', title: 'Plata' }], showSymbolLogo: true, displayMode: 'adaptive' });
  // si TradingView carga, sustituye a la cinta propia
  let k = 0; const chk = setInterval(() => { k++; if (host.querySelector('iframe')) { $('#ticker').classList.add('tv'); clearInterval(chk); } else if (k > 20) clearInterval(chk); }, 500);
}
const TVI = { 1: '1', 5: '5', 15: '15', 60: '60', 240: '240', 1440: 'D' };
let tvMode = false;
function tvChart() {
  const box = $('#c-tvbox'); $('#v-grafico').classList.toggle('tvon', tvMode); $('#c-tv').setAttribute('aria-pressed', tvMode);
  if (!tvMode) { box.innerHTML = ''; box.dataset.k = ''; return; }
  const c = LAY.panes[Math.min(active, LAY.n - 1)], key = c.sym + '|' + c.tf; if (box.dataset.k === key) return; box.dataset.k = key;
  tvEmbed(box, 'advanced-chart', { symbol: TVS[c.sym] || 'OANDA:XAUUSD', interval: TVI[c.tf] || '60', timezone: 'Europe/Madrid', theme: 'dark', style: '1', autosize: true, allow_symbol_change: true, withdateranges: true, hide_side_toolbar: false, backgroundColor: 'rgba(11,9,6,1)', gridColor: 'rgba(242,193,78,0.06)', isTransparent: false, support_host: 'https://www.tradingview.com' });
}

// =============== CENTRO DE MERCADO ===============
const MK_ASSETS = [['XAUUSD', 'Oro'], ['DXY', 'Dólar (DXY)'], ['BTCUSD', 'Bitcoin'], ['USOIL', 'Petróleo WTI']];
const DIRS = { alcista: ['ALCISTA', '▲', 'u'], bajista: ['BAJISTA', '▼', 'd'], neutral: ['NEUTRAL', '•', 'n'] };
// Sesgo calculado con los indicadores de la app (EMA, RSI, MACD, ProZones, divergencias y DXY para el oro)
const BIAS_CACHE = {};
function techBias(sym, tf) {
  const d = seriesSync(sym, tf); if (!d || d.length < 210) return null;
  const key = sym + '|' + tf + '|' + d.length + '|' + d[d.length - 1].close; if (BIAS_CACHE[key]) return BIAS_CACHE[key];
  const F = FortunaChart, c = d.map(x => x.close), n = c.length - 1, last = c[n];
  const e50 = F.ema(c, 50), e200 = F.ema(c, 200), r = F.rsi(c, 14), m = F.macd(c, 12, 26, 9), parts = [];
  const add = (name, v, txt) => parts.push({ name, v, txt });
  add('EMA 50/200', (last > e50[n] ? 1 : -1) + (e50[n] > e200[n] ? 1 : -1) > 0 ? 1 : (last > e50[n] ? 1 : -1) + (e50[n] > e200[n] ? 1 : -1) < 0 ? -1 : 0, last > e50[n] && e50[n] > e200[n] ? 'Precio sobre la EMA 50 y tendencia alcista' : last < e50[n] && e50[n] < e200[n] ? 'Precio bajo la EMA 50 y tendencia bajista' : 'Medias mezcladas');
  const rv = r[n]; add('RSI 14', rv > 55 ? 1 : rv < 45 ? -1 : 0, rv == null ? '—' : 'RSI ' + rv.toFixed(1) + (rv >= 70 ? ' · sobrecompra' : rv <= 30 ? ' · sobreventa' : ''));
  const hn = m.h[n], hp = m.h[n - 1]; add('MACD', hn > 0 ? 1 : -1, hn > 0 ? (hn > hp ? 'Histograma positivo y creciendo' : 'Histograma positivo') : (hn < hp ? 'Histograma negativo y bajando' : 'Histograma negativo'));
  let zv = 0, ztxt = 'Precio entre zonas';
  try {
    const R = F.rfzCalc(d, { htf: false }, tf * 6e4);
    if (R) { const inB = R.zs.find(z => z.typ > 0 && last >= z.bot && last <= z.top), inS = R.zs.find(z => z.typ < 0 && last >= z.bot && last <= z.top);
      const below = R.zs.filter(z => z.typ > 0 && z.top < last).sort((a, b) => b.top - a.top)[0], above = R.zs.filter(z => z.typ < 0 && z.bot > last).sort((a, b) => a.bot - b.bot)[0];
      if (inB) { zv = 1; ztxt = 'Dentro de una zona de compra'; } else if (inS) { zv = -1; ztxt = 'Dentro de una zona de venta'; }
      else if (below && above) { const db = last - below.top, da = above.bot - last; zv = db < da * .5 ? 1 : da < db * .5 ? -1 : 0; ztxt = zv > 0 ? 'Cerca de una zona de compra' : zv < 0 ? 'Cerca de una zona de venta' : 'Precio entre zonas'; }
      else if (below && !above) ztxt = 'Sin zonas de venta por encima'; else if (above && !below) ztxt = 'Sin zonas de compra por debajo'; }
  } catch (x) {}
  add('ProZones', zv, ztxt);
  let dv = 0, dtxt = 'Sin divergencias recientes';
  try { const dl = F.divergences(d, r).filter(x => x.b >= n - 12).pop(); if (dl) { dv = dl.type === 'bull' ? 1 : -1; dtxt = dl.type === 'bull' ? 'Divergencia alcista reciente' : 'Divergencia bajista reciente'; } } catch (x) {}
  add('Divergencias RSI', dv, dtxt);
  if (sym === 'XAUUSD') { const dx = techBias('DXY', tf); if (dx) add('DXY (inverso)', dx.dir === 'alcista' ? -1 : dx.dir === 'bajista' ? 1 : 0, 'El dólar está ' + dx.dir); }
  const sc = parts.reduce((a, p) => a + p.v, 0), out = { dir: sc >= 2 ? 'alcista' : sc <= -2 ? 'bajista' : 'neutral', sc, parts, rsi: rv };
  return BIAS_CACHE[key] = out;
}
function mkSessions() {
  const now = new Date(), wd = now.getUTCDay(), list = [['Sídney', 'Australia/Sydney', 7, 16], ['Tokio', 'Asia/Tokyo', 9, 18], ['Londres', 'Europe/London', 8, 17], ['Nueva York', 'America/New_York', 8, 17]];
  return list.map(([n, tz, o, c]) => {
    const h = +new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: 'numeric', hourCycle: 'h23' }).format(now), dow = new Intl.DateTimeFormat('en-GB', { timeZone: tz, weekday: 'short' }).format(now);
    const open = !['Sat', 'Sun'].includes(dow) && h >= o && h < c;
    const loc = new Date(now); const off = (t) => { const p = new Intl.DateTimeFormat('en-GB', { timeZone: t, hour: 'numeric', minute: 'numeric', hourCycle: 'h23' }).formatToParts(now); return +p.find(x => x.type === 'hour').value; };
    const diff = off('Europe/Madrid') - h, f = x => String(((x + diff) % 24 + 24) % 24).padStart(2, '0') + ':00';
    return { n, open, hours: f(o) + '–' + f(c) };
  });
}
let mkWidgets = false;
RENDER.mercado = () => {
  const el = $('#mk'), m = CFG.market || {}, b = m.bias || {};
  const real = s => isReal(s) ? '' : ' <small class="sim">sim</small>';
  const tfs = [['H1', 60], ['H4', 240], ['D1', 1440]];
  const tech = MK_ASSETS.map(([s, l]) => { const r = tfs.map(([, tf]) => techBias(s, tf)); const tot = r.reduce((a, x) => a + (x ? x.sc : 0), 0); return { s, l, r, all: tot >= 4 ? 'alcista' : tot <= -4 ? 'bajista' : 'neutral' }; });
  const pill = d => { const x = DIRS[d] || DIRS.neutral; return `<span class="bpill ${x[2]}">${x[1]} ${x[0]}</span>`; };
  // oro y dólar
  const g = seriesSync('XAUUSD', 60), dx = seriesSync('DXY', 60); let corr = null;
  if (g && dx && g.length > 60 && dx.length > 60) { const A = g.slice(-50).map(x => x.close), B = dx.slice(-50).map(x => x.close), ma = A.reduce((a, b) => a + b) / 50, mb = B.reduce((a, b) => a + b) / 50; let sab = 0, saa = 0, sbb = 0; for (let i = 0; i < 50; i++) { sab += (A[i] - ma) * (B[i] - mb); saa += (A[i] - ma) ** 2; sbb += (B[i] - mb) ** 2; } corr = saa && sbb ? sab / Math.sqrt(saa * sbb) : null; }
  const dxb = tech[1].all, goldFromDxy = corr != null && corr < -0.3 ? (dxb === 'alcista' ? 'bajista' : dxb === 'bajista' ? 'alcista' : 'neutral') : 'neutral';
  // niveles del oro
  let lv = null; const h1 = seriesSync('XAUUSD', 60), d1 = seriesSync('XAUUSD', 1440);
  if (h1 && h1.length > 50) { const R = FortunaChart.rfzCalc(h1, { htf: false }, 36e5, null, d1); if (R) { const L = R.pdh.length - 1, cl = h1[h1.length - 1].close; lv = { pdh: R.pdh[L], pdl: R.pdl[L], pwh: R.pwh[L], pwl: R.pwl[L], buy: R.zs.filter(z => z.typ > 0).sort((a, b) => b.top - a.top)[0], sell: R.zs.filter(z => z.typ < 0).sort((a, b) => a.bot - b.bot)[0], cl }; } }
  let atr = null; if (d1 && d1.length > 15) { let s = 0; for (let i = d1.length - 14; i < d1.length; i++) s += Math.max(d1[i].high - d1[i].low, Math.abs(d1[i].high - d1[i - 1].close), Math.abs(d1[i].low - d1[i - 1].close)); atr = s / 14; }
  const today = d1 && d1.length ? d1[d1.length - 1] : null;
  const ses = mkSessions(), upd = m.updated ? new Date(m.updated).toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' }) : null;
  const top = `
    <h1 class="title" style="margin-bottom:6px">Centro de mercado</h1>
    <div class="card mcard"><h3>Sesiones de mercado</h3>${sessionsHTML()}</div>
    <div class="card mcard"><div class="hd"><h3>Sesgo del equipo</h3>${ADMIN ? '<button class="btn ghost sm" id="mk-edit" type="button">Editar</button>' : ''}</div>
      ${m.comment ? `<p class="mkc">${esc(m.comment)}</p>` : '<p class="sub" style="margin:0">El equipo todavía no ha publicado el sesgo de hoy.</p>'}
      ${MK_ASSETS.map(([s, l]) => b[s] && b[s].dir ? `<div class="mkr"><div><b>${l}</b>${b[s].note ? `<small>${esc(b[s].note)}</small>` : ''}</div>${pill(b[s].dir)}</div>` : '').join('')}
      ${upd ? `<p class="fine" style="margin:4px 0 0">Actualizado: ${upd}</p>` : ''}</div>
    <div class="card mcard"><h3>Sesgo de los indicadores</h3><p class="sub" style="margin:0">EMA 50/200, RSI, MACD, ProZones y divergencias en cada temporalidad (en el oro también cuenta el DXY).</p>
      <div class="btab"><div class="bh"><span></span>${tfs.map(([l]) => `<span>${l}</span>`).join('')}<span>Global</span></div>
      ${tech.map(t => `<div class="br"><b>${t.l}${real(t.s)}</b>${t.r.map(x => x ? `<span class="${DIRS[x.dir][2]}">${DIRS[x.dir][1]}</span>` : '<span>–</span>').join('')}<span>${pill(t.all)}</span></div>`).join('')}</div></div>
    ${(() => { const rows = [['H1', 60], ['H4', 240]].map(([l, tf]) => [l, techBias('XAUUSD', tf)]).filter(x => x[1]); if (!rows.length) return ''; return `<div class="card mcard"><h3>Qué dice cada indicador · Oro</h3><div class="seg2">${rows.map(([l], i) => `<button type="button" data-bk="${i}" aria-pressed="${i === 0}">${l}</button>`).join('')}</div>${rows.map(([l, b], i) => `<div class="bk" data-bkp="${i}"${i ? ' hidden' : ''}>${b.parts.map(p => `<div class="bkr"><span class="${p.v > 0 ? 'u' : p.v < 0 ? 'd' : 'n'}">${p.v > 0 ? '▲' : p.v < 0 ? '▼' : '•'}</span><div><b>${esc(p.name)}</b><small>${esc(p.txt)}</small></div></div>`).join('')}<div class="bkr tot"><span></span><div><b>Resultado ${l}</b></div>${pill(b.dir)}</div></div>`).join('')}</div>`; })()}
    <div class="card mcard"><h3>Oro frente al dólar</h3>
      <div class="kp2"><div><span>Correlación oro/DXY (H1, 50 velas)</span><b class="${corr != null && corr < 0 ? 'u' : ''}">${corr == null ? '—' : corr.toFixed(2)}</b></div><div><span>Sesgo del DXY</span>${pill(dxb)}</div><div><span>Lectura para el oro</span>${pill(goldFromDxy)}</div></div>
      <p class="sub" style="margin:0">${corr != null && corr < -0.3 ? 'Correlación inversa: si el dólar sube, el oro tiende a bajar, y al revés.' : 'Ahora mismo el oro y el dólar no se mueven claramente al revés: el DXY pesa menos.'}</p></div>
    <div class="card mcard"><h3>Niveles clave del oro</h3>
      ${lv ? `<div class="kp2"><div><span>Máx. día anterior (PDH)</span><b>${lv.pdh != null ? dec(lv.pdh) : '—'}</b></div><div><span>Mín. día anterior (PDL)</span><b>${lv.pdl != null ? dec(lv.pdl) : '—'}</b></div><div><span>Máx. semana anterior</span><b>${lv.pwh != null ? dec(lv.pwh) : '—'}</b></div><div><span>Mín. semana anterior</span><b>${lv.pwl != null ? dec(lv.pwl) : '—'}</b></div>
      <div><span>Zona de venta más cercana (H1)</span><b class="d">${lv.sell ? dec(lv.sell.bot) + ' – ' + dec(lv.sell.top) : '—'}</b></div><div><span>Zona de compra más cercana (H1)</span><b class="u">${lv.buy ? dec(lv.buy.bot) + ' – ' + dec(lv.buy.top) : '—'}</b></div>
      <div><span>Rango de hoy</span><b>${today ? dec(today.high - today.low) : '—'}</b></div><div><span>Volatilidad media diaria (ATR 14)</span><b>${atr ? dec(atr) : '—'}</b></div></div>` : '<p class="sub">Cargando datos…</p>'}
      <p class="fine" style="margin:6px 0 0">Calculado con los precios de ${isReal('XAUUSD') ? 'Vantage en directo' : 'simulación (conecta el robot de MT5)'}.</p></div>
    ${canSec('fortunaty') ? '<button class="btn gold full" data-ask="Hazme un resumen del mercado de hoy para el oro: noticias importantes, calendario económico, sesgo y niveles clave." type="button">✨ Resumen del día con Fortunaty</button>' : ''}`;
  if (!mkWidgets) {
    el.innerHTML = '<div id="mk-top"></div>' + `
      <div class="card mcard"><h3>Calendario económico</h3><div id="tv-cal" class="tvw" style="height:560px"></div></div>
      <div class="card mcard"><h3>Noticias del oro</h3><div id="tv-news" class="tvw" style="height:560px"></div></div>`;
    mkWidgets = true;
    tvEmbed($('#tv-cal'), 'events', { width: '100%', height: '100%', importanceFilter: '0,1', countryFilter: 'us,eu,gb,jp,cn,ch' });
    tvEmbed($('#tv-news'), 'timeline', { feedMode: 'symbol', symbol: 'OANDA:XAUUSD', displayMode: 'regular', width: '100%', height: '100%' });
  }
  $('#mk-top').innerHTML = top;
  const ed = $('#mk-edit'); if (ed) ed.onclick = () => biasSheet();
  $('#mk-top').onclick = e => { const b = e.target.closest('[data-bk]'); if (!b) return; $$('#mk-top [data-bk]').forEach(x => x.setAttribute('aria-pressed', x === b)); $$('#mk-top [data-bkp]').forEach(x => x.hidden = x.dataset.bkp !== b.dataset.bk); };
  ['XAUUSD', 'DXY', 'BTCUSD', 'USOIL'].forEach(s => [60, 240, 1440].forEach(tf => { if (!seriesSync(s, tf)) getSeries(s, tf).then(() => { if (view === 'mercado') RENDER.mercado(); }).catch(() => {}); }));
};
function biasSheet() {
  const m = CFG.market || {}, b = m.bias || {};
  sheet('Sesgo del equipo', `<label class="fl">Comentario general del día<textarea id="bs-c" rows="3" maxlength="400" placeholder="Ej.: Semana con datos de empleo en EE. UU.; buscamos compras en zonas H4.">${esc(m.comment || '')}</textarea></label>
    ${MK_ASSETS.map(([s, l]) => `<div class="bsr"><b>${l}</b><select data-bs="${s}">${['', 'alcista', 'bajista', 'neutral'].map(d => `<option value="${d}"${(b[s] && b[s].dir || '') === d ? ' selected' : ''}>${d ? DIRS[d][0] : '— sin sesgo —'}</option>`).join('')}</select><input data-bn="${s}" maxlength="120" placeholder="Nota (opcional)" value="${esc(b[s] && b[s].note || '')}"></div>`).join('')}
    <button class="btn gold full" id="bs-go" type="button" style="margin-top:12px">Publicar sesgo para todos</button>`, el => {
    $('#bs-go').onclick = async () => {
      const bias = {}; MK_ASSETS.forEach(([s]) => { const d = $(`#sheet-c [data-bs="${s}"]`).value, n = $(`#sheet-c [data-bn="${s}"]`).value.trim(); if (d) bias[s] = { dir: d, note: n }; });
      const v = { ...CFG, market: { comment: $('#bs-c').value.trim(), bias, updated: new Date().toISOString() } };
      try { await comm.saveConfig(v); CFG = mergeCfg(v); LS.set('fr.cfg', v); closeSheet(); toast('✅ Sesgo publicado'); RENDER.mercado(); } catch (x) { toast('No se pudo guardar: ' + x.message); }
    };
  });
}

const toLocalInput = iso => { const d = new Date(iso); if (isNaN(d)) return ''; const p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`; };


// =============== ÚTILES ===============
function calc() {
  const bal = num($('#c-bal').value), risk = num($('#c-risk').value), en = num($('#c-in').value), sl = num($('#c-sl').value), rr = num($('#c-rr').value) || 0, out = $('#c-out');
  if (!(bal > 0 && risk > 0 && en > 0 && sl > 0) || en === sl) { out.innerHTML = '<div><span>Rellena capital, riesgo, entrada y stop</span><b>–</b></div>'; return; }
  const dist = Math.abs(en - sl), dir = sl < en ? 1 : -1, lots = Math.floor(bal * risk / 100 / (dist * 100) * 100) / 100, real = lots * dist * 100, tp = en + dir * dist * rr;
  out.innerHTML = `<div><span>${dir > 0 ? 'Compra' : 'Venta'} · tamaño de posición</span><b>${dec(lots)} lotes</b></div><div><span>Riesgo real</span><b class="d">${usd(real)}</b></div><div><span>Take profit ${dec(rr, 1)}R</span><b>${rr > 0 ? dec(tp) : '–'}</b><span>${rr > 0 ? '+' + usd(real * rr) : ''}</span></div>`;
}
['#c-bal', '#c-risk', '#c-in', '#c-sl', '#c-rr'].forEach(s => $(s).addEventListener('input', () => { calc(); LS.set('fr.calc', { bal: $('#c-bal').value, risk: $('#c-risk').value, rr: $('#c-rr').value }); }));
$('#c-now').onclick = () => { $('#c-in').value = px.XAUUSD.toFixed(2); $('#c-sl').value = (px.XAUUSD - 5).toFixed(2); calc(); };
const MK = [['Sídney', 'Australia/Sydney', 7, 16], ['Tokio', 'Asia/Tokyo', 9, 18], ['Londres', 'Europe/London', 8, 17], ['Nueva York', 'America/New_York', 8, 17]];
const FM = {};
function zt(tz, d) { const f = FM[tz] || (FM[tz] = new Intl.DateTimeFormat('en-GB', { timeZone: tz, weekday: 'short', hour: '2-digit', hourCycle: 'h23' })); const p = {}; f.formatToParts(d).forEach(x => p[x.type] = x.value); return { wd: p.weekday, h: +p.hour }; }
function fxOpen(d) { const n = zt('America/New_York', d); return !(n.wd === 'Sat' || (n.wd === 'Fri' && n.h >= 17) || (n.wd === 'Sun' && n.h < 17)); }
function mkOpen(m, d) { if (!fxOpen(d)) return false; const t = zt(m[1], d); return t.wd !== 'Sat' && t.wd !== 'Sun' && t.h >= m[2] && t.h < m[3]; }
function sessMini() { const now = new Date(); $('#sess-mini').innerHTML = MK.map(m => { const on = mkOpen(m, now); return `<div><b>${m[0]}</b><span class="${on ? 'on' : 'off'}">${on ? '● Abierta' : 'Cerrada'}</span></div>`; }).join(''); }
function sessions() { $('#sess').innerHTML = sessionsHTML(); }
RENDER.utiles = () => { const c = LS.get('fr.calc'); if (c) { $('#c-bal').value = c.bal; $('#c-risk').value = c.risk; $('#c-rr').value = c.rr; } if (!$('#c-in').value) $('#c-now').click(); calc(); sessions(); };

// =============== NOTICIAS FORTUNA ===============
const NTOP = { oro: ['🪙', 'Oro'], dolar: ['💵', 'Dólar'], bolsa: ['📈', 'Bolsa'], cripto: ['₿', 'Cripto'], petroleo: ['🛢️', 'Petróleo'], bancos: ['🏦', 'Bancos centrales'], economia: ['📊', 'Economía'], geopolitica: ['🌍', 'Geopolítica'], mercados: ['📰', 'Mercados'] };
let NEWS = [], newsOpen = new Set();
const newsImg = (n, small) => { const [ic, lb] = NTOP[n.topic] || NTOP.mercados; return `<div class="nimg t-${esc(n.topic || 'mercados')}${small ? ' sm' : ''}"><span class="nic">${ic}</span><div class="nbr"><img src="icons/logo-96.png" alt=""><div><b>NOTICIAS FORTUNA</b><small>${lb} · ${agoTxt(n.posted_at)}</small></div></div></div>`; };
async function loadNews() { try { NEWS = await comm.news(); } catch (e) { NEWS = NEWS || []; } }
RENDER.noticias = async () => {
  const box = $('#nws'); if (!box.dataset.ready) box.innerHTML = '<div class="acc-wait"><div class="spin"></div></div>';
  await loadNews(); box.dataset.ready = 1;
  const c = CFG.news || {}, credit = c.credit !== false;
  const adm = ADMIN ? `<details class="card nadm"${c.channel ? '' : ' open'}><summary><b>⚙ Ajustes de noticias (solo tú)</b></summary>
      <label class="fl">Canal de Telegram (público)<input id="nw-ch" placeholder="Ej.: nombredelcanal o https://t.me/nombredelcanal" value="${esc(c.channel || '')}"></label>
      <div class="orow2"><span><b>Traer noticias automáticamente</b><small class="sub">Cada 10 minutos, traducidas al español</small></span><button class="sw-t" role="switch" aria-checked="${c.on !== false}" id="nw-on" type="button"></button></div>
      <div class="orow2"><span><b>Mencionar el canal original</b><small class="sub">Recomendado: es lo normal cuando te dan permiso</small></span><button class="sw-t" role="switch" aria-checked="${credit}" id="nw-cr" type="button"></button></div>
      <div class="row2" style="margin-top:10px"><button class="btn gold sm" id="nw-save" type="button">Guardar</button><button class="btn ghost sm" id="nw-now" type="button">🔄 Actualizar ahora</button><button class="btn ghost sm" id="nw-add" type="button">+ Publicar noticia propia</button></div></details>` : '';
  box.innerHTML = adm + (NEWS.map(n => { const op = newsOpen.has(n.id), long = (n.body || '').length > 260;
    return `<article class="card ncard" data-n="${esc(n.id)}">${newsImg(n)}<h3>${esc(n.title || (n.body || '').split('\n')[0].slice(0, 90))}</h3><p class="nbody${op || !long ? '' : ' clamp'}">${esc(n.body || '')}</p>
      ${long ? `<button class="linkb" data-nm type="button">${op ? 'Leer menos' : 'Leer más'}</button>` : ''}
      <div class="nft">${n.channel !== 'fortuna' && credit && okUrl(n.link) ? `<small class="sub">Vía <a href="${esc(n.link)}" target="_blank" rel="noopener">@${esc(n.channel)}</a></small>` : '<small class="sub">Equipo Fortuna Radiante</small>'}${canSec('fortunaty') ? `<button class="linkb" data-nask type="button">✨ Qué significa para el oro</button>` : ''}${ADMIN ? '<button class="linkb d" data-ndel type="button">Borrar</button>' : ''}</div></article>`; }).join('') || `<div class="lockbox" style="margin-top:10px"><div class="lk">📰</div><h2>Todavía no hay noticias</h2><p>${ADMIN ? 'Escribe el nombre del canal arriba, guarda y pulsa «Actualizar ahora».' : 'En cuanto el equipo publique, aparecerán aquí traducidas al español.'}</p></div>`);
  box.onclick = async e => {
    const t = e.target;
    if (t.classList.contains('sw-t')) { t.setAttribute('aria-checked', t.getAttribute('aria-checked') !== 'true'); return; }
    if (t.id === 'nw-save' || t.id === 'nw-now') {
      const ch = $('#nw-ch').value.trim().replace(/^@|^https?:\/\/t\.me\/(s\/)?/i, '').replace(/\/.*$/, '');
      if (ch && !/^[A-Za-z0-9_]{4,64}$/.test(ch)) return toast('El nombre del canal no es válido');
      const v = { ...CFG, news: { channel: ch, on: $('#nw-on').getAttribute('aria-checked') === 'true', credit: $('#nw-cr').getAttribute('aria-checked') === 'true' } };
      try { await comm.saveConfig(v); CFG = mergeCfg(v); LS.set('fr.cfg', v); } catch (x) { return toast('No se pudo guardar: ' + x.message); }
      if (t.id === 'nw-save') { toast('✅ Ajustes guardados'); return RENDER.noticias(); }
      t.disabled = true; t.textContent = 'Traduciendo…';
      try { const r = await comm.fn('noticias', {}); toast(r.aviso || (r.nuevas ? `✅ ${r.nuevas} noticia${r.nuevas > 1 ? 's' : ''} nueva${r.nuevas > 1 ? 's' : ''}` : 'No hay noticias nuevas')); } catch (x) { toast(x.code === 'no_key' ? 'Primero activa Fortunaty (falta ANTHROPIC_API_KEY)' : x.status === 404 ? 'Falta crear la función «noticias» en Supabase' : x.message); }
      return RENDER.noticias();
    }
    if (t.id === 'nw-add') return sheet('Publicar noticia', `<label class="fl">Titular<input id="na-t" maxlength="140"></label><label class="fl">Texto<textarea id="na-b" rows="6" maxlength="3000"></textarea></label><label class="fl">Tema<select id="na-tp">${Object.entries(NTOP).map(([k, [ic, l]]) => `<option value="${k}">${ic} ${l}</option>`).join('')}</select></label><button class="btn gold full" id="na-go" type="button">Publicar</button>`, () => {
      $('#na-go').onclick = async () => { const ti = $('#na-t').value.trim(), b = $('#na-b').value.trim(); if (!ti || !b) return toast('Pon titular y texto'); try { await comm.addNews({ title: ti, body: b, topic: $('#na-tp').value }); closeSheet(); toast('📰 Noticia publicada'); RENDER.noticias(); } catch (x) { toast(x.message); } };
    });
    const card = t.closest('[data-n]'); if (!card) return; const n = NEWS.find(x => x.id === card.dataset.n);
    if (t.closest('[data-nm]')) { newsOpen.has(n.id) ? newsOpen.delete(n.id) : newsOpen.add(n.id); RENDER.noticias(); return; }
    if (t.closest('[data-nask]')) { show('fortunaty'); ask(`Explícame en 3 puntos qué puede significar esta noticia para el oro (XAUUSD) y el dólar: «${n.title}. ${(n.body || '').slice(0, 600)}»`); return; }
    if (t.closest('[data-ndel]')) { if (!confirm('¿Borrar esta noticia?')) return; try { await comm.deleteNews(n.id); RENDER.noticias(); } catch (x) { toast(x.message); } }
  };
};
async function homeNews() {
  const el = $('#home-news'); if (!el) return;
  if (!canSec('noticias')) { el.innerHTML = ''; return; }
  if (!NEWS.length) await loadNews();
  el.innerHTML = NEWS.length ? `<div class="hn-h"><h3>📰 Noticias Fortuna</h3><a href="#noticias" class="linkb">Ver todas ›</a></div>${NEWS.slice(0, 3).map(n => `<a class="hn" href="#noticias">${newsImg(n, true)}<b>${esc(n.title || (n.body || '').slice(0, 90))}</b></a>`).join('')}` : '';
}

// =============== ROLES DE LA COMUNIDAD ===============
let ROLES = [], UROLE = new Map();
async function loadRoles() { try { const [r, u] = await Promise.all([comm.roles(), comm.userRoles()]); ROLES = r || []; UROLE = new Map(); (u || []).forEach(x => { if (!UROLE.has(x.user_id)) UROLE.set(x.user_id, []); UROLE.get(x.user_id).push(x.role_id); }); } catch (e) {} }
const meIdX = () => comm.me() && comm.me().id;
const roleOf = uid => { const ids = UROLE.get(uid) || []; return ROLES.filter(r => ids.includes(r.id)).sort((a, b) => a.sort - b.sort); };
const roleBadge = (uid, all) => roleOf(uid).slice(0, all ? 9 : 1).map(r => `<span class="rbadge" style="--rc:${esc(r.color)}">${esc(r.icon)} ${esc(r.name)}</span>`).join('');
const canSignals = () => ADMIN || roleOf(comm.me() && comm.me().id).some(r => r.can_signals);
RENDER.roles = async () => {
  const box = $('#rls'); if (!ADMIN) { box.innerHTML = '<p class="sub">Solo para el administrador.</p>'; return; }
  await loadRoles();
  const count = id => [...UROLE.values()].filter(a => a.includes(id)).length;
  box.innerHTML = `<p class="sub">Los roles salen junto al nombre en el chat y en Miembros. Los repartes desde <b>Usuarios</b> → «Roles».</p>
    ${ROLES.map(r => `<div class="card rrow" data-r="${esc(r.id)}"><span class="rbadge big" style="--rc:${esc(r.color)}">${esc(r.icon)} ${esc(r.name)}</span><div style="flex:1;min-width:0"><small class="sub">${count(r.id)} persona${count(r.id) === 1 ? '' : 's'}${r.can_signals ? ' · publica señales' : ''}${r.can_moderate ? ' · modera el chat' : ''}</small></div><button class="btn ghost sm" data-edit="${esc(r.id)}" type="button">Editar</button></div>`).join('')}
    <button class="btn gold full" id="r-new" type="button">+ Crear rol</button>`;
  box.onclick = e => { const ed = e.target.closest('[data-edit]'); if (ed) roleSheet(ROLES.find(r => r.id === ed.dataset.edit)); if (e.target.id === 'r-new') roleSheet(null); };
};
function roleSheet(r) {
  const nw = !r; r = r || { id: '', name: '', color: '#D9A21B', icon: '⭐', sort: ROLES.length, can_signals: false, can_moderate: false };
  const sw = (id, on) => `<button class="sw-t" role="switch" aria-checked="${!!on}" id="${id}" type="button"></button>`;
  sheet(nw ? 'Nuevo rol' : 'Editar rol', `<div class="fgrid"><label class="fl">Icono<input id="ro-icon" maxlength="4" value="${esc(r.icon)}"></label><label class="fl">Nombre<input id="ro-name" maxlength="24" value="${esc(r.name)}" placeholder="Ej.: Analista"></label></div>
    <label class="fl">Color<input type="color" id="ro-color" value="${esc(r.color)}"></label>
    <div class="orow2"><span><b>Puede publicar señales</b><small class="sub">En la zona Señales Fortuna</small></span>${sw('ro-sig', r.can_signals)}</div>
    <div class="orow2"><span><b>Puede moderar el chat</b><small class="sub">Borrar mensajes de otros</small></span>${sw('ro-mod', r.can_moderate)}</div>
    <button class="btn gold full" id="ro-go" type="button" style="margin-top:12px">Guardar rol</button>${nw ? '' : '<button class="btn danger full" id="ro-del" type="button" style="margin-top:10px">Eliminar rol</button>'}`, el => {
    el.onclick = async e => {
      if (e.target.classList.contains('sw-t')) { e.target.setAttribute('aria-checked', e.target.getAttribute('aria-checked') !== 'true'); return; }
      if (e.target.id === 'ro-del') { if (!confirm(`¿Eliminar el rol «${r.name}»? Se quitará a todos los que lo tengan.`)) return; try { await comm.deleteRole(r.id); closeSheet(); toast('Rol eliminado'); RENDER.roles(); } catch (x) { toast(x.message); } return; }
      if (e.target.id !== 'ro-go') return;
      const name = $('#ro-name').value.trim(); if (name.length < 2) return toast('Pon un nombre al rol');
      const id = nw ? (name.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24) || 'rol' + Date.now() % 1e4) : r.id;
      try { await comm.saveRole({ id, name, icon: $('#ro-icon').value.trim() || '⭐', color: $('#ro-color').value, sort: r.sort, can_signals: $('#ro-sig').getAttribute('aria-checked') === 'true', can_moderate: $('#ro-mod').getAttribute('aria-checked') === 'true' }); closeSheet(); toast('✅ Rol guardado'); RENDER.roles(); } catch (x) { toast(x.message); }
    };
  });
}

// =============== USUARIOS (panel de administrador) ===============
let usrFilter = 'todos', usrQ = '';
RENDER.accesos = async () => {
  const box = $('#accs'); if (!ADMIN) { box.innerHTML = '<p class="sub">Solo para el administrador.</p>'; return; }
  if (!box.dataset.ready) box.innerHTML = '<div class="acc-wait"><div class="spin"></div></div>';
  let list = [];
  try { [list] = await Promise.all([comm.adminUsers(), loadRoles()]); } catch (e) { box.innerHTML = `<div class="card rej">No se pudo cargar: ${esc(e.message)}. ¿Has ejecutado <b>fortuna-v3-supabase.sql</b>?</div>`; return; }
  box.dataset.ready = 1;
  const st = u => u.is_admin ? 'admin' : u.status || 'sin';
  const F = { todos: ['Todos', () => true], pendiente: ['Pendientes', u => st(u) === 'pendiente'], aprobado: ['Aprobados', u => st(u) === 'aprobado'], sin: ['Sin MT5', u => st(u) === 'sin'], silenciado: ['Silenciados', u => u.muted], rechazado: ['Rechazados', u => st(u) === 'rechazado'], expulsado: ['Expulsados', u => st(u) === 'expulsado'] };
  const week = list.filter(u => u.last_sign_in_at && Date.now() - new Date(u.last_sign_in_at) < 7 * 864e5).length;
  ACC_PEND = list.filter(u => st(u) === 'pendiente').length; updPend();
  const STN = { admin: ['ADMIN', 'g'], aprobado: ['APROBADO', 'u'], pendiente: ['PENDIENTE', 'p'], rechazado: ['RECHAZADO', 'd'], expulsado: ['EXPULSADO', 'd'], sin: ['SIN MT5', 'n'] };
  const q = usrQ.toLowerCase(), shown = list.filter(F[usrFilter][1]).filter(u => !q || (u.alias || '').toLowerCase().includes(q) || (u.email || '').toLowerCase().includes(q) || (u.mt5_login || '').includes(q));
  const card = u => { const s = st(u), secs = u.sections || {}, inds = u.indicators || {}, ok = s === 'aprobado';
    return `<div class="card ucard" data-u="${esc(u.id)}">
      <div class="ahd">${avHTML({ alias: u.alias || '?', avatar_url: u.avatar_url }, 44)}<div style="min-width:0;flex:1"><b>${esc(u.alias || 'Sin perfil')}</b> ${roleBadge(u.id, true)}<button class="mail" data-act="mail" type="button">✉ ${esc(u.email || '—')}</button><small class="sub">Alta ${agoTxt(u.created_at)} · último acceso ${agoTxt(u.last_sign_in_at)}</small></div><span class="stp ${STN[s][1]}">${STN[s][0]}</span></div>
      ${u.mt5_login ? `<div class="accsum"><div><span>Bróker</span><b>${esc(u.broker || '—')}</b></div><div><span>Servidor</span><b>${esc(u.mt5_server || '—')}</b></div><div><span>Cuenta MT5</span><b>${esc(u.mt5_login)}</b></div><div><span>Saldo indicado</span><b>${u.balance != null ? nf(+u.balance) + ' $' : '—'}</b></div>${u.investor_pw ? `<div style="grid-column:1/-1"><span>Contraseña de inversor</span><b class="pw" data-pw="${esc(u.investor_pw)}">•••••••• <button class="linkb" data-act="pw" type="button">Mostrar</button></b></div>` : ''}</div>` : ''}
      ${u.note ? `<p class="sub" style="margin:0">Motivo: ${esc(u.note)}</p>` : ''}
      ${ok ? `<div class="qperm"><span class="sub">Toca para quitar o dar acceso:</span><div class="chips">${SECTIONS.map(([k, l]) => `<button type="button" class="chip${secs[k] ? ' on' : ''}" data-sec="${k}">${secs[k] ? '✓' : '✕'} ${esc(SEC_SHORT[k] || l)}</button>`).join('')}</div><button class="linkb" data-act="perm" type="button">Indicadores: ${INDS.filter(([k]) => inds[k]).length}/${INDS.length} · cambiar ›</button></div>` : ''}
      ${u.is_admin ? '' : `<div class="row2">
        ${u.proof_path ? '<button class="btn ghost sm" data-act="proof" type="button">📷 Captura</button>' : ''}
        ${s === 'pendiente' || s === 'rechazado' || s === 'sin' ? '<button class="btn gold sm" data-act="ok" type="button">Aprobar</button>' : ''}
        ${s === 'pendiente' ? '<button class="btn ghost sm" data-act="no" type="button">Rechazar</button>' : ''}
        ${s === 'expulsado' ? '<button class="btn gold sm" data-act="ok" type="button">Readmitir</button>' : ''}
        <button class="btn ghost sm" data-act="roles" type="button">🏷️ Roles</button>
        <button class="btn ghost sm" data-act="mute" type="button">${u.muted ? '🔊 Quitar silencio' : '🔇 Silenciar chat'}</button>
        ${s !== 'expulsado' ? '<button class="btn sm danger" data-act="out" type="button">Expulsar</button>' : ''}
        <button class="btn sm danger" data-act="del" type="button">🗑 Eliminar</button></div>`}</div>`; };
  box.innerHTML = `<div class="ustats"><div><b>${list.length}</b><span>usuarios</span></div><div><b>${list.filter(u => st(u) === 'aprobado').length}</b><span>aprobados</span></div><div><b class="${ACC_PEND ? 'p' : ''}">${ACC_PEND}</b><span>pendientes</span></div><div><b>${week}</b><span>activos 7 días</span></div></div>
    <input type="search" id="u-q" placeholder="Buscar por nombre, correo o cuenta MT5" value="${esc(usrQ)}" aria-label="Buscar usuario">
    <div class="segm wrap">${Object.entries(F).map(([k, [l, f]]) => `<button type="button" data-uf="${k}" aria-pressed="${k === usrFilter}">${l} <span class="cnt">${list.filter(f).length}</span></button>`).join('')}</div>
    <div id="u-list">${shown.map(card).join('') || '<p class="sub" style="text-align:center;margin:30px 0">Nadie con este filtro.</p>'}</div>`;
  const qi = $('#u-q'); qi.oninput = () => { usrQ = qi.value; clearTimeout(qi._t); qi._t = setTimeout(() => { RENDER.accesos().then(() => { const n = $('#u-q'); n.focus(); n.setSelectionRange(n.value.length, n.value.length); }); }, 250); };
  box.onclick = async e => {
    const f = e.target.closest('[data-uf]'); if (f) { usrFilter = f.dataset.uf; RENDER.accesos(); return; }
    const c = e.target.closest('[data-u]'); if (!c) return; const u = list.find(x => x.id === c.dataset.u), alias = u.alias || u.email;
    const sec = e.target.closest('[data-sec]');
    if (sec) { const k = sec.dataset.sec, v = !(u.sections || {})[k]; try { await comm.setAccess(u.id, { sections: { ...(u.sections || {}), [k]: v } }); u.sections = { ...(u.sections || {}), [k]: v }; sec.classList.toggle('on', v); sec.textContent = (v ? '✓ ' : '✕ ') + (SEC_SHORT[k] || k); toast(`${alias}: ${SEC_SHORT[k] || k} ${v ? 'activado' : 'bloqueado'}`); } catch (x) { toast(x.message); } return; }
    const b = e.target.closest('[data-act]'); if (!b) return; const act = b.dataset.act;
    if (act === 'mail') { try { await navigator.clipboard.writeText(u.email); toast('Correo copiado'); } catch (x) { toast(u.email); } return; }
    if (act === 'pw') { const w = b.closest('.pw'); w.textContent = w.dataset.pw; return; }
    if (act === 'proof') { try { $('#lb-img').src = await comm.proofUrl(u.proof_path); $('#lb').hidden = false; } catch (x) { toast(x.message); } return; }
    if (act === 'ok' || act === 'perm') return permSheet(u.id, alias, u.status ? { status: u.status, sections: u.sections, indicators: u.indicators } : null);
    if (act === 'roles') return userRolesSheet(u);
    if (act === 'mute') { try { if (u.muted) await comm.unban(u.id); else await comm.ban(u.id); toast(u.muted ? alias + ' puede volver a escribir' : alias + ' silenciado en el chat'); RENDER.accesos(); } catch (x) { toast(x.message); } return; }
    if (act === 'del') return sheet('Eliminar a ' + alias, `<p>Se borrará <b>su cuenta entera</b>: perfil, mensajes del chat, diario, retos y accesos. <b>No se puede deshacer.</b></p><label class="fl">Para confirmar, escribe <b>ELIMINAR</b><input id="del-ok" autocomplete="off"></label><button class="btn danger full" id="del-go" type="button">Eliminar definitivamente</button>`, () => {
      $('#del-go').onclick = async () => { if ($('#del-ok').value.trim().toUpperCase() !== 'ELIMINAR') return toast('Escribe ELIMINAR para confirmar'); try { await comm.deleteUser(u.id); closeSheet(); toast(alias + ' eliminado'); RENDER.accesos(); } catch (x) { toast(x.message); } };
    });
    if (act === 'no' || act === 'out') {
      const out = act === 'out';
      sheet(out ? 'Expulsar a ' + alias : 'Rechazar a ' + alias, `<p class="sub">${out ? 'No podrá entrar en la app ni leer ni escribir en el chat. Puedes readmitirle más tarde.' : 'Verá el motivo y podrá corregir sus datos y volver a enviarlos.'}</p><label class="fl">Motivo (lo verá el usuario)<textarea id="ac-note" rows="3" maxlength="240">${out ? '' : 'No hemos podido comprobar el saldo de la cuenta.'}</textarea></label><button class="btn ${out ? 'danger' : 'gold'} full" id="ac-go" type="button">${out ? 'Expulsar de la app' : 'Rechazar solicitud'}</button>`, () => {
        $('#ac-go').onclick = async () => { try { await comm.setAccess(u.id, { status: out ? 'expulsado' : 'rechazado', note: $('#ac-note').value.trim() || null, alias: u.alias }); closeSheet(); toast(out ? alias + ' ha sido expulsado' : 'Solicitud rechazada'); RENDER.accesos(); } catch (x) { toast(x.message); } };
      });
    }
  };
};
const SEC_SHORT = { grafico: 'Gráfico', mercado: 'Mercado', fortunaty: 'Fortunaty', comunidad: 'Chat', liga: 'Liga', senales: 'Señales', diario: 'Diario', noticias: 'Noticias', mentorias: 'Mentorías', herramientas: 'Calculadoras' };
function userRolesSheet(u) {
  const mine = UROLE.get(u.id) || [];
  sheet('Roles de ' + (u.alias || u.email), `${ROLES.map(r => `<label class="chk"><input type="checkbox" data-rl="${esc(r.id)}"${mine.includes(r.id) ? ' checked' : ''}><span class="rbadge" style="--rc:${esc(r.color)}">${esc(r.icon)} ${esc(r.name)}</span>${r.can_signals ? '<small class="sub">publica señales</small>' : ''}${r.can_moderate ? '<small class="sub">modera</small>' : ''}</label>`).join('') || '<p class="sub">No hay roles. Créalos en Panel de administrador → Roles.</p>'}
    <button class="btn gold full" id="ur-go" type="button" style="margin-top:12px">Guardar roles</button>`, () => {
    $('#ur-go').onclick = async () => { const ids = $$('#sheet-c [data-rl]').filter(i => i.checked).map(i => i.dataset.rl); try { await comm.setUserRoles(u.id, ids); closeSheet(); toast('✅ Roles guardados'); RENDER.accesos(); } catch (x) { toast(x.message); } };
  });
}

// =============== SEÑALES FORTUNA ===============
let SIGS = [], sigFilter = 'activas', sigTimer = null;
const SIG_OPEN = ['pendiente', 'activa', 'tp1', 'tp2'];
const SIG_ST = { pendiente: ['PENDIENTE', 'p'], activa: ['ACTIVA', 'g'], tp1: ['TP1 ✓', 'u'], tp2: ['TP2 ✓', 'u'], tp3: ['TP3 ✓', 'u'], sl: ['STOP LOSS', 'd'], be: ['BREAK EVEN', 'n'], cerrada: ['CERRADA', 'n'], cancelada: ['CANCELADA', 'n'] };
async function loadSignals() { try { SIGS = await comm.signals(); } catch (e) { SIGS = SIGS || []; } }
RENDER.senales = async () => {
  const box = $('#sig'); if (!box.dataset.ready) box.innerHTML = '<div class="acc-wait"><div class="spin"></div></div>';
  await loadSignals(); box.dataset.ready = 1; drawSignals();
  clearInterval(sigTimer); sigTimer = setInterval(() => { if (view === 'senales' && !document.hidden) loadSignals().then(drawSignals); else clearInterval(sigTimer); }, 20000);
};
function drawSignals() {
  const box = $('#sig'), now = new Date(), m0 = new Date(now.getFullYear(), now.getMonth(), 1);
  const closed = SIGS.filter(s => !SIG_OPEN.includes(s.status) && s.status !== 'cancelada' && s.result_pips != null && new Date(s.closed_at || s.updated_at) >= m0);
  const wins = closed.filter(s => s.result_pips > 0).length, tot = closed.reduce((a, s) => a + Number(s.result_pips), 0);
  const list = SIGS.filter(s => sigFilter === 'todas' || (sigFilter === 'activas' ? SIG_OPEN.includes(s.status) : !SIG_OPEN.includes(s.status)));
  const live = s => { const p = px[s.symbol]; if (!(p > 0) || !SIG_OPEN.includes(s.status) || s.status === 'pendiente') return null; return pipsOf(s.symbol, Number(s.entry), p, s.side); };
  const lvl = (s, l, v) => v == null ? '' : `<div class="lv"><span>${l}</span><b>${nf(+v, SY[s.symbol] ? SY[s.symbol].d : 2)}</b><small class="${l === 'SL' ? 'd' : 'u'}">${(() => { const p = pipsOf(s.symbol, +s.entry, +v, s.side); return p == null ? '' : (p > 0 ? '+' : '') + nf(p, 1) + ' pips'; })()}</small></div>`;
  const rr = s => { const r = s.sl ? Math.abs(s.entry - s.sl) : 0, w = s.tp1 ? Math.abs(s.tp1 - s.entry) : 0; return r && w ? '1:' + nf(w / r, 1) : null; };
  const card = s => { const [stt, cls] = SIG_ST[s.status] || [s.status, 'n'], lp = live(s), au = comm.profile(s.created_by);
    return `<div class="card scard ${s.side}" data-s="${esc(s.id)}"><div class="shd"><span class="side ${s.side}">${s.side === 'compra' ? '▲ COMPRA' : '▼ VENTA'}</span><b class="sym">${esc(s.symbol)}</b>${s.timeframe ? `<span class="tfp">${esc(s.timeframe)}</span>` : ''}<span class="stp ${cls}">${stt}</span></div>
      <div class="lvls"><div class="lv en"><span>${s.kind === 'mercado' ? 'Entrada' : s.kind === 'limite' ? 'Entrada límite' : 'Entrada stop'}</span><b>${nf(+s.entry, SY[s.symbol] ? SY[s.symbol].d : 2)}${s.entry_to ? ' – ' + nf(+s.entry_to, SY[s.symbol] ? SY[s.symbol].d : 2) : ''}</b>${rr(s) ? `<small>R:R ${rr(s)}</small>` : ''}</div>${lvl(s, 'SL', s.sl)}${lvl(s, 'TP1', s.tp1)}${lvl(s, 'TP2', s.tp2)}${lvl(s, 'TP3', s.tp3)}</div>
      ${lp != null ? `<div class="slive ${lp >= 0 ? 'u' : 'd'}">Ahora: ${lp > 0 ? '+' : ''}${nf(lp, 1)} pips <small>(precio ${nf(px[s.symbol], SY[s.symbol].d)})</small></div>` : ''}
      ${s.result_pips != null && !SIG_OPEN.includes(s.status) ? `<div class="slive ${s.result_pips >= 0 ? 'u' : 'd'}">Resultado: ${s.result_pips > 0 ? '+' : ''}${nf(+s.result_pips, 1)} pips</div>` : ''}
      ${s.note ? `<p class="snote">${esc(s.note)}</p>` : ''}
      <div class="sft"><small class="sub">${au ? esc(au.alias) + ' ' : ''}${roleBadge(s.created_by)} · ${agoTxt(s.created_at)}</small>${canSignals() ? '<button class="btn ghost sm" data-sa="gest" type="button">Gestionar</button>' : ''}</div></div>`; };
  box.innerHTML = `<div class="ustats"><div><b>${closed.length}</b><span>cerradas este mes</span></div><div><b>${closed.length ? Math.round(wins / closed.length * 100) + '%' : '—'}</b><span>acierto</span></div><div><b class="${tot >= 0 ? 'u' : 'd'}">${closed.length ? (tot > 0 ? '+' : '') + nf(tot, 1) : '—'}</b><span>pips del mes</span></div></div>
    ${canSignals() ? '<button class="btn gold full" id="sg-new" type="button">+ Nueva señal</button>' : ''}
    <div class="segm" style="margin:12px 0">${[['activas', 'Activas'], ['cerradas', 'Cerradas'], ['todas', 'Todas']].map(([k, l]) => `<button type="button" data-sf="${k}" aria-pressed="${k === sigFilter}">${l}</button>`).join('')}</div>
    ${list.map(card).join('') || `<p class="sub" style="text-align:center;margin:30px 0">${sigFilter === 'activas' ? 'No hay señales activas ahora mismo. Activa las notificaciones para enterarte al momento.' : 'Todavía no hay señales aquí.'}</p>`}
    <p class="fine">Las señales son ideas de trading del equipo, no asesoramiento financiero. Opera siempre con stop loss y un riesgo que puedas asumir.</p>`;
  box.onclick = e => {
    const f = e.target.closest('[data-sf]'); if (f) { sigFilter = f.dataset.sf; drawSignals(); return; }
    if (e.target.id === 'sg-new') return signalSheet(null);
    const g = e.target.closest('[data-sa="gest"]'); if (g) signalManage(SIGS.find(s => s.id === g.closest('[data-s]').dataset.s));
  };
}
function signalSheet(s) {
  const nw = !s; s = s || { symbol: 'XAUUSD', side: 'compra', kind: 'mercado', entry: px.XAUUSD ? +px.XAUUSD.toFixed(2) : '', timeframe: 'H1' };
  const fld = (id, l, v) => `<label class="fl">${l}<input id="${id}" inputmode="decimal" value="${v == null ? '' : esc(v)}"></label>`;
  sheet(nw ? 'Nueva señal' : 'Editar señal', `<div class="segm" id="sg-side"><button type="button" data-v="compra" aria-pressed="${s.side === 'compra'}">▲ Compra</button><button type="button" data-v="venta" aria-pressed="${s.side === 'venta'}">▼ Venta</button></div>
    <div class="fgrid"><label class="fl">Mercado<input id="sg-sym" list="sg-syms" value="${esc(s.symbol)}"><datalist id="sg-syms">${[...ORDER, 'EURUSD', 'GBPUSD', 'USDJPY', 'XAGUSD', 'US30', 'NAS100'].map(x => `<option value="${x}">`).join('')}</datalist></label>
    <label class="fl">Tipo<select id="sg-kind">${[['mercado', 'A mercado'], ['limite', 'Límite'], ['stop', 'Stop']].map(([k, l]) => `<option value="${k}"${s.kind === k ? ' selected' : ''}>${l}</option>`).join('')}</select></label></div>
    <div class="fgrid">${fld('sg-en', 'Entrada', s.entry)}${fld('sg-en2', 'Hasta (zona, opcional)', s.entry_to)}</div>
    <div class="fgrid">${fld('sg-sl', 'Stop loss', s.sl)}<label class="fl">Temporalidad<select id="sg-tf">${['M5', 'M15', 'M30', 'H1', 'H4', 'D1'].map(x => `<option${s.timeframe === x ? ' selected' : ''}>${x}</option>`).join('')}</select></label></div>
    <div class="fgrid3">${fld('sg-tp1', 'TP1', s.tp1)}${fld('sg-tp2', 'TP2', s.tp2)}${fld('sg-tp3', 'TP3', s.tp3)}</div>
    <div class="pipbox" id="sg-pips"></div>
    <label class="fl">Comentario (opcional)<textarea id="sg-note" rows="3" maxlength="600" placeholder="Motivo de la entrada, gestión, etc.">${esc(s.note || '')}</textarea></label>
    <button class="btn gold full" id="sg-go" type="button">${nw ? 'Publicar señal (avisa a todos)' : 'Guardar cambios'}</button>`, el => {
    let side = s.side;
    const val = id => { const v = $(id).value.trim(); return v === '' ? null : num(v); };
    const calc = () => { const sym = $('#sg-sym').value.trim().toUpperCase(), en = val('#sg-en'), pp = (v, l) => v == null || en == null ? '' : `<span>${l}: <b class="${l === 'SL' ? 'd' : 'u'}">${nf(pipsOf(sym, en, v, side), 1)} pips</b></span>`; const sl = val('#sg-sl'), t1 = val('#sg-tp1'); $('#sg-pips').innerHTML = pp(sl, 'SL') + pp(t1, 'TP1') + pp(val('#sg-tp2'), 'TP2') + pp(val('#sg-tp3'), 'TP3') + (sl != null && t1 != null && en != null && Math.abs(en - sl) > 0 ? `<span>R:R <b>1:${nf(Math.abs(t1 - en) / Math.abs(en - sl), 1)}</b></span>` : ''); };
    el.oninput = calc; calc();
    el.onclick = async e => {
      const sd = e.target.closest('#sg-side [data-v]'); if (sd) { side = sd.dataset.v; $$('#sg-side button').forEach(b => b.setAttribute('aria-pressed', b === sd)); calc(); return; }
      if (e.target.id !== 'sg-go') return;
      const o = { symbol: $('#sg-sym').value.trim().toUpperCase(), side, kind: $('#sg-kind').value, entry: val('#sg-en'), entry_to: val('#sg-en2'), sl: val('#sg-sl'), tp1: val('#sg-tp1'), tp2: val('#sg-tp2'), tp3: val('#sg-tp3'), timeframe: $('#sg-tf').value, note: $('#sg-note').value.trim() || null };
      if (!o.symbol || !(o.entry > 0)) return toast('Pon el mercado y el precio de entrada');
      if (o.sl != null && (side === 'compra' ? o.sl >= o.entry : o.sl <= o.entry)) return toast(side === 'compra' ? 'En una compra el stop va por debajo de la entrada' : 'En una venta el stop va por encima de la entrada');
      if (nw) o.status = o.kind === 'mercado' ? 'activa' : 'pendiente';
      e.target.disabled = true;
      try { await comm.saveSignal(nw ? o : { ...o, id: s.id }); closeSheet(); toast(nw ? '📡 Señal publicada' : 'Señal actualizada'); RENDER.senales(); } catch (x) { toast(x.message); e.target.disabled = false; }
    };
  });
}
function signalManage(s) {
  const res = st => { const lvl = { tp1: s.tp1, tp2: s.tp2, tp3: s.tp3, sl: s.sl, be: s.entry }[st]; return lvl == null ? null : pipsOf(s.symbol, +s.entry, +lvl, s.side); };
  sheet(`${s.side === 'compra' ? 'Compra' : 'Venta'} ${s.symbol}`, `<p class="sub">Marca cómo va la señal. Se avisa a todos y se calculan los pips.</p>
    <div class="stgrid">${[['activa', '▶ Activada'], ['tp1', '✅ TP1'], ['tp2', '✅ TP2'], ['tp3', '🏆 TP3'], ['be', '⚖️ Break even'], ['sl', '❌ Stop loss'], ['cerrada', '⏹ Cerrar a mano'], ['cancelada', '🚫 Cancelar']].map(([k, l]) => `<button class="btn ${s.status === k ? 'gold' : 'ghost'} sm" data-st="${k}" type="button">${l}${res(k) != null ? `<small>${res(k) > 0 ? '+' : ''}${nf(res(k), 1)} pips</small>` : ''}</button>`).join('')}</div>
    <label class="fl" id="cl-box" hidden>Precio de cierre<input id="cl-px" inputmode="decimal" value="${px[s.symbol] ? +px[s.symbol].toFixed(2) : ''}"></label>
    <button class="btn ghost full" id="sg-ed" type="button">✏️ Editar niveles</button><button class="btn danger full" id="sg-del" type="button" style="margin-top:10px">🗑 Borrar señal</button>`, el => {
    el.onclick = async e => {
      if (e.target.id === 'sg-ed') { closeSheet(); return signalSheet(s); }
      if (e.target.id === 'sg-del') { if (!confirm('¿Borrar esta señal?')) return; try { await comm.deleteSignal(s.id); closeSheet(); toast('Señal borrada'); RENDER.senales(); } catch (x) { toast(x.message); } return; }
      const b = e.target.closest('[data-st]'); if (!b) return; const st = b.dataset.st;
      let rp = res(st);
      if (st === 'cerrada') { const bx = $('#cl-box'); if (bx.hidden) { bx.hidden = false; b.textContent = '⏹ Confirmar cierre'; return; } rp = pipsOf(s.symbol, +s.entry, num($('#cl-px').value), s.side); }
      if (st === 'activa' || st === 'cancelada') rp = null;
      try { await comm.saveSignal({ id: s.id, status: st, result_pips: rp }); closeSheet(); toast('Señal actualizada'); RENDER.senales(); } catch (x) { toast(x.message); }
    };
  });
}

// =============== LIGA FORTUNA: RETOS, XP Y DIVISIONES ===============
const TIERS = [[0, 'Bronce', '🥉', '#cd7f32'], [300, 'Plata', '🥈', '#cfd8dc'], [800, 'Oro', '🥇', '#f2c14e'], [1500, 'Platino', '💠', '#7fdbff'], [3000, 'Diamante', '💎', '#b388ff'], [6000, 'Leyenda', '👑', '#ff8a65']];
const tierOf = xp => { let i = 0; TIERS.forEach((t, k) => { if (xp >= t[0]) i = k; }); return { t: TIERS[i], nx: TIERS[i + 1] || null }; };
const KINDS = { beneficio: ['📈', 'Rentabilidad', 'Gana al menos un {t} % en el periodo', ' %'], racha: ['🔥', 'Racha', 'Encadena {t} operaciones ganadoras seguidas', ''], dias_verdes: ['🟢', 'Días en verde', 'Cierra {t} días en positivo', ' días'], winrate: ['🎯', 'Precisión', 'Acierta al menos el {t} % de tus operaciones', ' %'], con_sl: ['🛡️', 'Disciplina', 'Pon stop loss en el {t} % de tus operaciones', ' %'], operaciones: ['⚡', 'Actividad', 'Haz {t} operaciones', ''], manual: ['🏅', 'Especial', 'Lo valida el administrador', ''] };
let lgTab = 'retos', CH = [], JOINS = [], MYV = {}, RANK = [];
const left = t => { const s = (new Date(t) - Date.now()) / 1000; if (s <= 0) return 'Terminado'; const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600); return d ? `Quedan ${d} d ${h} h` : `Quedan ${h} h ${Math.floor(s % 3600 / 60)} min`; };
const goalTxt = c => KINDS[c.kind][2].replace('{t}', nf(+c.target, c.kind === 'beneficio' ? 1 : 0)) + (c.min_trades > 0 && ['winrate', 'con_sl', 'beneficio', 'racha', 'dias_verdes'].includes(c.kind) ? ` (mín. ${c.min_trades} operaciones)` : '');
async function renderLiga() {
  const box = $('#lg'); if (!box) return;
  if (!canSec('liga')) { box.innerHTML = '<div class="lockbox" style="margin-top:20px"><div class="lk">🔒</div><h2>Liga y retos</h2><p>El administrador todavía no te ha dado acceso a la liga.</p></div>'; return; }
  if (!box.dataset.ready) box.innerHTML = '<div class="acc-wait"><div class="spin"></div></div>';
  const me = comm.me() && comm.me().id;
  try { [CH, JOINS, RANK] = await Promise.all([comm.challenges(), comm.joins(), comm.ranking()]); } catch (e) { box.innerHTML = `<div class="card rej">No se pudo cargar la liga: ${esc(e.message)}</div>`; return; }
  const mine = new Set(JOINS.filter(j => j.user_id === me).map(j => j.challenge_id));
  await Promise.all([...mine].map(async id => { try { MYV[id] = Number(await comm.challengeValue(id, me)) || 0; } catch (e) {} }));
  box.dataset.ready = 1;
  const r = RANK.findIndex(x => x.user_id === me), xp = r >= 0 ? Number(RANK[r].xp) : 0, { t, nx } = tierOf(xp), pctN = nx ? Math.min(100, (xp - t[0]) / (nx[0] - t[0]) * 100) : 100;
  const now = Date.now(), act = CH.filter(c => new Date(c.ends_at) > now && new Date(c.starts_at) <= now), soon = CH.filter(c => new Date(c.starts_at) > now), done = CH.filter(c => new Date(c.ends_at) <= now);
  const chCard = c => { const [ic, kn] = KINDS[c.kind], j = mine.has(c.id), v = MYV[c.id] || 0, ok = j && v >= +c.target, n = JOINS.filter(x => x.challenge_id === c.id).length, pc = Math.min(100, v / (+c.target || 1) * 100);
    return `<div class="card chc${ok ? ' ok' : ''}" data-c="${esc(c.id)}"><div class="chh"><span class="chi">${esc(c.icon || ic)}</span><div style="flex:1;min-width:0"><b>${esc(c.title)}</b><small class="sub">${kn} · ${goalTxt(c)}</small></div><span class="xp">+${c.xp} XP</span></div>
      ${c.description ? `<p class="snote">${esc(c.description)}</p>` : ''}
      ${j ? `<div class="pbar"><i style="width:${pc}%"></i></div><div class="chm"><span>${ok ? '✅ ¡Completado!' : `Tu progreso: <b>${nf(v, c.kind === 'beneficio' ? 2 : 0)}${KINDS[c.kind][3]}</b> de ${nf(+c.target, c.kind === 'beneficio' ? 1 : 0)}${KINDS[c.kind][3]}`}</span></div>` : ''}
      <div class="chm"><small class="sub">👥 ${n} · ${new Date(c.starts_at) > now ? 'Empieza ' + new Date(c.starts_at).toLocaleDateString('es-ES') : left(c.ends_at)}</small><span class="row2">${!j && new Date(c.ends_at) > now ? '<button class="btn gold sm" data-la="join" type="button">Unirme</button>' : ''}<button class="btn ghost sm" data-la="board" type="button">Clasificación</button>${ADMIN ? '<button class="btn ghost sm" data-la="edit" type="button">⚙</button>' : ''}</span></div></div>`; };
  const tabs = `<div class="segm" style="margin:12px 0">${[['retos', 'Retos'], ['rank', 'Clasificación'], ['info', 'Cómo funciona']].map(([k, l]) => `<button type="button" data-lt="${k}" aria-pressed="${k === lgTab}">${l}</button>`).join('')}</div>`;
  let body = '';
  if (lgTab === 'retos') body = (ADMIN ? '<button class="btn gold full" id="lg-new" type="button">+ Crear reto</button>' : '') + (act.length ? '<h3 class="sec">En marcha</h3>' + act.map(chCard).join('') : '<p class="sub" style="text-align:center;margin:20px 0">No hay retos en marcha ahora mismo.</p>') + (soon.length ? '<h3 class="sec">Próximamente</h3>' + soon.map(chCard).join('') : '') + (done.length ? '<h3 class="sec">Terminados</h3>' + done.slice(0, 8).map(chCard).join('') : '');
  else if (lgTab === 'rank') { const top = RANK.slice(0, 3), ord = [top[1], top[0], top[2]];
    body = (ADMIN ? '<button class="btn ghost full" id="lg-xp" type="button">+ Dar XP a alguien</button>' : '') + (RANK.length ? `<div class="podium2">${ord.map((x, i) => x ? `<div class="pd p${[2, 1, 3][i]}">${avHTML({ alias: x.alias, avatar_url: x.avatar_url }, i === 1 ? 62 : 50)}<b>${esc(x.alias)}</b><small>${tierOf(+x.xp).t[2]} ${nf(+x.xp, 0)} XP</small><div class="blk">${['2', '1', '3'][i]}</div></div>` : '<div></div>').join('')}</div>` + RANK.map((x, i) => `<div class="rk2${x.user_id === me ? ' me' : ''}"><span class="pos">${i + 1}</span>${avHTML({ alias: x.alias, avatar_url: x.avatar_url }, 36)}<div style="flex:1;min-width:0"><b>${esc(x.alias)}</b> ${roleBadge(x.user_id)}<small class="sub">${tierOf(+x.xp).t[2]} ${tierOf(+x.xp).t[1]} · ${x.retos} reto${+x.retos === 1 ? '' : 's'}</small></div><b class="xpv">${nf(+x.xp, 0)} XP</b></div>`).join('') : '<p class="sub" style="text-align:center;margin:20px 0">Todavía nadie ha completado un reto. ¡Sé el primero!</p>'); }
  else body = `<div class="card"><h3 style="margin-top:0">Cómo funciona la Liga Fortuna</h3><ol class="steps"><li>Conecta tu cuenta de MetaTrader en <b>Diario → Conectar MT</b>. Solo cuentan las operaciones verificadas que llegan de tu MT.</li><li>Únete a los retos que quieras. Tu progreso se calcula solo con tus operaciones dentro de las fechas del reto.</li><li>Cada reto completado te da <b>XP</b>. Con XP subes de división.</li><li>El admin puede dar XP extra por buenos análisis o por ayudar en la comunidad.</li></ol></div>
    <div class="card"><h3 style="margin-top:0">Divisiones</h3>${TIERS.map(x => `<div class="tierr"><span>${x[2]}</span><b style="color:${x[3]}">${x[1]}</b><small class="sub">desde ${nf(x[0], 0)} XP</small></div>`).join('')}</div>
    <button class="btn gold full" data-go="diario" type="button">Conectar mi MetaTrader</button>`;
  box.innerHTML = `<div class="card tierc" style="--tc:${t[3]}"><div class="tt"><span class="tic">${t[2]}</span><div style="flex:1"><small class="sub">Tu división</small><b>${t[1]}</b></div><div style="text-align:right"><b>${nf(xp, 0)} XP</b><small class="sub">${r >= 0 ? 'Puesto ' + (r + 1) + ' de ' + RANK.length : 'Sin clasificar'}</small></div></div>
    <div class="pbar"><i style="width:${pctN}%;background:${t[3]}"></i></div><small class="sub">${nx ? `Te faltan ${nf(nx[0] - xp, 0)} XP para ${nx[2]} ${nx[1]}` : '¡Has llegado a lo más alto!'}</small></div>${tabs}${body}`;
  box.onclick = async e => {
    const tb = e.target.closest('[data-lt]'); if (tb) { lgTab = tb.dataset.lt; renderLiga(); return; }
    if (e.target.id === 'lg-new') return challengeSheet(null);
    if (e.target.id === 'lg-xp') return xpSheet();
    const b = e.target.closest('[data-la]'); if (!b) return; const c = CH.find(x => x.id === b.closest('[data-c]').dataset.c);
    if (b.dataset.la === 'join') { try { await comm.join(c.id); toast('¡Te has unido al reto ' + c.title + '!'); renderLiga(); } catch (x) { toast(x.message); } }
    if (b.dataset.la === 'edit') challengeSheet(c);
    if (b.dataset.la === 'board') boardSheet(c);
  };
}
async function boardSheet(c) {
  let list = []; try { list = await comm.challengeBoard(c.id); } catch (e) { return toast(e.message); }
  const me = comm.me() && comm.me().id, unit = KINDS[c.kind][3];
  sheet(c.title, `<p class="sub">${goalTxt(c)} · +${c.xp} XP · ${left(c.ends_at)}</p>
    ${list.map((x, i) => `<div class="rk2${x.user_id === me ? ' me' : ''}"><span class="pos">${i + 1}</span>${avHTML({ alias: x.alias, avatar_url: x.avatar_url }, 32)}<div style="flex:1;min-width:0"><b>${esc(x.alias)}</b><div class="pbar sm"><i style="width:${Math.min(100, x.value / (+c.target || 1) * 100)}%"></i></div></div><b class="${x.done ? 'u' : ''}">${x.done ? '✅ ' : ''}${nf(+x.value, c.kind === 'beneficio' ? 2 : 0)}${unit}</b>${ADMIN && c.kind === 'manual' ? `<button class="btn ${x.done ? 'ghost' : 'gold'} sm" data-md="${esc(x.user_id)}" data-v="${x.done ? 0 : 1}" type="button">${x.done ? 'Quitar' : 'Validar'}</button>` : ''}</div>`).join('') || '<p class="sub">Nadie se ha unido todavía.</p>'}
    ${list.some(x => x.user_id === me) ? '<button class="btn ghost full" id="bd-leave" type="button" style="margin-top:12px">Salir del reto</button>' : ''}`, el => {
    el.onclick = async e => {
      const m = e.target.closest('[data-md]'); if (m) { try { await comm.setManualDone(c.id, m.dataset.md, m.dataset.v === '1'); closeSheet(); boardSheet(c); renderLiga(); } catch (x) { toast(x.message); } return; }
      if (e.target.id === 'bd-leave') { try { await comm.leave(c.id); closeSheet(); toast('Has salido del reto'); renderLiga(); } catch (x) { toast(x.message); } }
    };
  });
}
function challengeSheet(c) {
  const nw = !c, d = new Date(), e7 = new Date(Date.now() + 7 * 864e5); c = c || { title: '', icon: '🏆', kind: 'racha', target: 5, min_trades: 0, xp: 150, starts_at: d.toISOString(), ends_at: e7.toISOString(), description: '' };
  const dIn = t => { const x = new Date(t), p = n => String(n).padStart(2, '0'); return `${x.getFullYear()}-${p(x.getMonth() + 1)}-${p(x.getDate())}`; };
  sheet(nw ? 'Nuevo reto' : 'Editar reto', `<div class="fgrid"><label class="fl">Icono<input id="ch-ic" maxlength="4" value="${esc(c.icon)}"></label><label class="fl">Título<input id="ch-t" maxlength="60" value="${esc(c.title)}" placeholder="Ej.: Semana del francotirador"></label></div>
    <label class="fl">Tipo de reto<select id="ch-k">${Object.entries(KINDS).map(([k, v]) => `<option value="${k}"${c.kind === k ? ' selected' : ''}>${v[0]} ${v[1]} — ${v[2].replace('{t}', 'X')}</option>`).join('')}</select></label>
    <div class="fgrid3"><label class="fl">Objetivo (X)<input id="ch-tg" inputmode="decimal" value="${c.target}"></label><label class="fl">Mín. operaciones<input id="ch-mt" inputmode="numeric" value="${c.min_trades}"></label><label class="fl">Premio XP<input id="ch-xp" inputmode="numeric" value="${c.xp}"></label></div>
    <div class="fgrid"><label class="fl">Empieza<input type="date" id="ch-s" value="${dIn(c.starts_at)}"></label><label class="fl">Termina<input type="date" id="ch-e" value="${dIn(c.ends_at)}"></label></div>
    <label class="fl">Descripción (opcional)<textarea id="ch-d" rows="3" maxlength="300">${esc(c.description || '')}</textarea></label>
    <button class="btn gold full" id="ch-go" type="button">${nw ? 'Publicar reto' : 'Guardar'}</button>${nw ? '' : '<button class="btn danger full" id="ch-del" type="button" style="margin-top:10px">Borrar reto</button>'}`, el => {
    el.onclick = async e => {
      if (e.target.id === 'ch-del') { if (!confirm('¿Borrar este reto y su clasificación?')) return; try { await comm.deleteChallenge(c.id); closeSheet(); toast('Reto borrado'); renderLiga(); } catch (x) { toast(x.message); } return; }
      if (e.target.id !== 'ch-go') return;
      const o = { title: $('#ch-t').value.trim(), icon: $('#ch-ic').value.trim() || '🏆', kind: $('#ch-k').value, target: num($('#ch-tg').value), min_trades: parseInt($('#ch-mt').value) || 0, xp: parseInt($('#ch-xp').value) || 0, starts_at: new Date($('#ch-s').value + 'T00:00:00').toISOString(), ends_at: new Date($('#ch-e').value + 'T23:59:59').toISOString(), description: $('#ch-d').value.trim() || null };
      if (o.kind === 'manual') o.target = 1;
      if (o.title.length < 3) return toast('Pon un título'); if (!(o.target > 0)) return toast('El objetivo tiene que ser mayor que 0'); if (new Date(o.ends_at) <= new Date(o.starts_at)) return toast('La fecha de fin tiene que ser después del inicio');
      try { await comm.saveChallenge(nw ? o : { ...o, id: c.id }); closeSheet(); toast('🏆 Reto guardado'); renderLiga(); } catch (x) { toast(x.message); }
    };
  });
}
async function xpSheet() {
  let mem = []; try { mem = await comm.members(); } catch (e) {}
  sheet('Dar XP', `<label class="fl">Miembro<select id="xp-u">${mem.map(m => `<option value="${esc(m.id)}">${esc(m.alias)}</option>`).join('')}</select></label><div class="fgrid"><label class="fl">XP<input id="xp-n" inputmode="numeric" value="100"></label><label class="fl">Motivo<input id="xp-r" maxlength="120" placeholder="Mejor análisis de la semana"></label></div><button class="btn gold full" id="xp-go" type="button">Dar XP</button>`, () => {
    $('#xp-go').onclick = async () => { const n = parseInt($('#xp-n').value), r = $('#xp-r').value.trim(); if (!n || !r) return toast('Pon XP y motivo'); try { await comm.giveXp($('#xp-u').value, n, r); closeSheet(); toast('✅ XP entregado'); renderLiga(); } catch (x) { toast(x.message); } };
  });
}

// =============== DIARIO DE OPERACIONES (conectado a MetaTrader) ===============
let jMonth = (() => { const d = new Date(); d.setDate(1); d.setHours(0, 0, 0, 0); return d; })(), jDay = null, jTab = 'cal', JT = [], JACC = [];
const MES = new Intl.DateTimeFormat('es-ES', { month: 'long', year: 'numeric' });
const dayKey = t => { const d = new Date(t); return d.getFullYear() + '-' + d.getMonth() + '-' + d.getDate(); };
const short$ = v => (v < 0 ? '−' : '+') + (Math.abs(v) >= 1000 ? nf(Math.abs(v) / 1000, 1) + 'k' : nf(Math.abs(v), 0));
RENDER.diario = async () => {
  const box = $('#jr'), to = new Date(jMonth.getFullYear(), jMonth.getMonth() + 1, 1);
  if (!box.dataset.ready) box.innerHTML = '<div class="acc-wait"><div class="spin"></div></div>';
  try { [JT, JACC] = await Promise.all([comm.trades(jMonth.toISOString(), to.toISOString()), comm.mtAccounts()]); } catch (e) { box.innerHTML = `<div class="card rej">No se pudo cargar el diario: ${esc(e.message)}. ¿Has ejecutado <b>fortuna-v3-supabase.sql</b>?</div>`; return; }
  box.dataset.ready = 1;
  const T = JT.slice().sort((a, b) => new Date(a.close_time) - new Date(b.close_time)), pr = x => Number(x.profit) || 0;
  const wins = T.filter(x => pr(x) > 0), loss = T.filter(x => pr(x) < 0), net = T.reduce((a, x) => a + pr(x), 0), gw = wins.reduce((a, x) => a + pr(x), 0), gl = -loss.reduce((a, x) => a + pr(x), 0);
  const lots = T.reduce((a, x) => a + (Number(x.lots) || 0), 0), pips = T.reduce((a, x) => a + (Number(x.pips) || 0), 0);
  const byDay = {}; T.forEach(x => { const k = dayKey(x.close_time); (byDay[k] = byDay[k] || { p: 0, n: 0, w: 0, l: 0, lots: 0 }); byDay[k].p += pr(x); byDay[k].n++; byDay[k].lots += Number(x.lots) || 0; pr(x) > 0 ? byDay[k].w++ : pr(x) < 0 && byDay[k].l++; });
  const days = Object.values(byDay), green = days.filter(d => d.p > 0).length, red = days.filter(d => d.p < 0).length, maxAbs = Math.max(1, ...days.map(d => Math.abs(d.p)));
  // calendario (semanas de lunes a domingo + total de la semana)
  const first = new Date(jMonth), off = (first.getDay() + 6) % 7, nDays = new Date(jMonth.getFullYear(), jMonth.getMonth() + 1, 0).getDate(), today = dayKey(Date.now());
  let cells = ''; let wk = { p: 0, n: 0 }, col = 0;
  for (let i = 0; i < off; i++) { cells += '<div class="cd empty"></div>'; col++; }
  for (let d = 1; d <= nDays; d++) {
    const k = dayKey(new Date(jMonth.getFullYear(), jMonth.getMonth(), d)), x = byDay[k];
    if (x) { wk.p += x.p; wk.n += x.n; }
    const a = x ? Math.min(.75, .18 + Math.abs(x.p) / maxAbs * .57) : 0;
    cells += `<button class="cd${x ? (x.p >= 0 ? ' pos' : ' neg') : ''}${k === today ? ' today' : ''}${jDay === k ? ' sel' : ''}" data-day="${k}" type="button" style="${x ? `--a:${a}` : ''}"><span class="dn">${d}</span>${x ? `<b>${short$(x.p)}</b><small>${x.n} op.</small>` : ''}</button>`;
    col++;
    if (col % 7 === 0 || d === nDays) { while (col % 7) { cells += '<div class="cd empty"></div>'; col++; } cells += `<div class="cw ${wk.p > 0 ? 'u' : wk.p < 0 ? 'd' : ''}"><small>Sem</small><b>${wk.n ? short$(wk.p) : '—'}</b><small>${wk.n ? wk.n + ' op.' : ''}</small></div>`; wk = { p: 0, n: 0 }; }
  }
  const tRow = x => `<div class="tr2" data-t="${x.id}"><div class="tl2"><span class="side ${x.side}">${x.side === 'compra' ? '▲' : '▼'}</span><div><b>${esc(x.symbol)} · ${nf(+x.lots, 2)} lotes</b><small class="sub">${new Date(x.close_time).toLocaleString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}${x.open_price ? ' · ' + nf(+x.open_price, 2) + ' → ' + nf(+x.close_price, 2) : ''}${x.sl ? ' · con SL' : ''}${x.source === 'ea' ? ' · <span class="ver">MT ✓</span>' : ' · manual'}</small>${x.note ? `<small class="snote">📝 ${esc(x.note)}</small>` : ''}</div></div><div style="text-align:right"><b class="${pr(x) >= 0 ? 'u' : 'd'}">${money(pr(x))}</b>${x.pips != null ? `<small class="sub">${x.pips > 0 ? '+' : ''}${nf(+x.pips, 1)} pips</small>` : ''}</div></div>`;
  const dayList = jDay ? T.filter(x => dayKey(x.close_time) === jDay) : [];
  const tabs = `<div class="segm" style="margin:12px 0">${[['cal', 'Calendario'], ['ops', 'Operaciones'], ['mt', 'Conectar MT']].map(([k, l]) => `<button type="button" data-jt="${k}" aria-pressed="${k === jTab}">${l}</button>`).join('')}</div>`;
  const old = LS.get('fr.journal') || [];
  let body = '';
  if (jTab === 'cal') body = `<div class="calh"><span>L</span><span>M</span><span>X</span><span>J</span><span>V</span><span>S</span><span>D</span><span></span></div><div class="cal">${cells}</div>
    ${jDay ? `<h3 class="sec">${new Date(+jDay.split('-')[0], +jDay.split('-')[1], +jDay.split('-')[2]).toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}</h3>${dayList.map(tRow).join('') || '<p class="sub">Sin operaciones este día.</p>'}` : '<p class="sub" style="text-align:center">Toca un día para ver sus operaciones.</p>'}`;
  else if (jTab === 'ops') body = '<button class="btn gold full" id="j-add" type="button">+ Añadir operación a mano</button>' + (old.length ? `<button class="btn ghost full" id="j-imp" type="button" style="margin-top:8px">Pasar mis ${old.length} operaciones antiguas al diario nuevo</button>` : '') + (T.slice().reverse().map(tRow).join('') || '<p class="sub" style="text-align:center;margin:20px 0">No hay operaciones este mes.</p>');
  else { const key = await comm.journalKey().catch(e => null);
    body = `${JACC.length ? JACC.map(a => `<div class="card accm"><div><b>Cuenta ${esc(a.account)}</b><small class="sub">${esc(a.server || '')} · actualizado ${agoTxt(a.updated_at)}</small></div><div class="accsum"><div><span>Balance</span><b>${nf(+a.balance)} ${esc(a.currency || '')}</b></div><div><span>Equidad</span><b>${nf(+a.equity)} ${esc(a.currency || '')}</b></div></div></div>`).join('') : '<div class="card"><b>Todavía no hay ninguna cuenta conectada.</b><p class="sub" style="margin:6px 0 0">Sigue los pasos de abajo. Tus operaciones aparecerán solas en el calendario.</p></div>'}
    <div class="card"><h3 style="margin-top:0">Tu clave personal del diario</h3>${key ? `<div class="linkbox"><span id="j-key" data-k="${esc(key)}">${esc(key.slice(0, 10))}••••••••••</span><button class="btn ghost sm" id="j-copy" type="button">Copiar</button></div><button class="linkb" id="j-renew" type="button">Generar una clave nueva (la anterior deja de funcionar)</button>` : '<p class="sub">No se pudo obtener la clave. ¿Tienes acceso al diario?</p>'}<p class="sub" style="margin:8px 0 0">Es solo tuya: no la compartas.</p></div>
    <div class="card"><h3 style="margin-top:0">Conectar MetaTrader en 4 pasos</h3><ol class="steps"><li>Descarga el robot para tu MetaTrader (en el ordenador):<div class="row2" style="margin-top:8px"><a class="btn ghost sm" href="descargas/FortunaDiario.mq5" download>MT5 · FortunaDiario.mq5</a><a class="btn ghost sm" href="descargas/FortunaDiario.mq4" download>MT4 · FortunaDiario.mq4</a></div></li><li>MT: <b>Archivo → Abrir carpeta de datos → MQL5</b> (o MQL4) <b>→ Experts</b>, pega el archivo y compílalo con <b>F7</b> en MetaEditor.</li><li><b>Herramientas → Opciones → Asesores Expertos</b>: marca <b>Permitir WebRequest</b> y añade <code>${esc(window.FR_SUPABASE_URL || 'https://…supabase.co')}</code>.</li><li>Arrastra <b>FortunaDiario</b> a cualquier gráfico, pega tu <b>clave personal</b> en «Tu clave del diario» y pulsa Aceptar. Arriba a la izquierda verás <b>«Diario conectado»</b>.</li></ol><p class="sub" style="margin:8px 0 0">El robot no opera: solo lee tus operaciones cerradas, el balance y la equidad. Para que se actualice, MT tiene que estar abierto (o en un VPS).</p></div>`; }
  box.innerHTML = `<div class="jnav"><button class="ib" data-jm="-1" type="button" aria-label="Mes anterior">‹</button><b>${MES.format(jMonth).replace(/^\w/, c => c.toUpperCase())}</b><button class="ib" data-jm="1" type="button" aria-label="Mes siguiente">›</button></div>
    <div class="jst"><div class="big ${net >= 0 ? 'u' : 'd'}"><span>Resultado del mes</span><b>${money(net)}</b><small>${T.length} operaciones · ${nf(lots, 2)} lotes${pips ? ' · ' + (pips > 0 ? '+' : '') + nf(pips, 1) + ' pips' : ''}</small></div>
      <div><span>Ganadoras</span><b class="u">${wins.length}</b></div><div><span>Perdedoras</span><b class="d">${loss.length}</b></div><div><span>Acierto</span><b>${T.length ? Math.round(wins.length / T.length * 100) + ' %' : '—'}</b></div>
      <div><span>Factor de beneficio</span><b>${gl > 0 ? nf(gw / gl, 2) : wins.length ? '∞' : '—'}</b></div><div><span>Media ganadora</span><b class="u">${wins.length ? money(gw / wins.length) : '—'}</b></div><div><span>Media perdedora</span><b class="d">${loss.length ? money(-gl / loss.length) : '—'}</b></div>
      <div><span>Días en verde</span><b class="u">${green}</b></div><div><span>Días en rojo</span><b class="d">${red}</b></div><div><span>Lotes</span><b>${nf(lots, 2)}</b></div></div>
    ${tabs}${body}`;
  box.onclick = async e => {
    const m = e.target.closest('[data-jm]'); if (m) { jMonth = new Date(jMonth.getFullYear(), jMonth.getMonth() + +m.dataset.jm, 1); jDay = null; RENDER.diario(); return; }
    const tb = e.target.closest('[data-jt]'); if (tb) { jTab = tb.dataset.jt; RENDER.diario(); return; }
    const d = e.target.closest('[data-day]'); if (d) { jDay = jDay === d.dataset.day ? null : d.dataset.day; RENDER.diario(); return; }
    if (e.target.id === 'j-add') return tradeSheet(null);
    if (e.target.id === 'j-copy') { try { await navigator.clipboard.writeText($('#j-key').dataset.k); toast('Clave copiada'); } catch (x) { $('#j-key').textContent = $('#j-key').dataset.k; } return; }
    if (e.target.id === 'j-renew') { if (!confirm('¿Generar una clave nueva? Tendrás que ponerla otra vez en el robot.')) return; try { await comm.journalKey(true); toast('Clave nueva creada'); RENDER.diario(); } catch (x) { toast(x.message); } return; }
    if (e.target.id === 'j-imp') { let n = 0; for (const j of old) { try { await comm.addTrade({ symbol: 'XAUUSD', side: j.dir > 0 ? 'compra' : 'venta', lots: j.lots, open_price: j.in, close_price: j.out, profit: Math.round((j.out - j.in) * j.dir * j.lots * 100 * 100) / 100, close_time: new Date(j.ts).toISOString(), note: j.note || null }); n++; } catch (x) {} } LS.set('fr.journal', []); toast(`${n} operaciones pasadas al diario`); RENDER.diario(); return; }
    const t = e.target.closest('[data-t]'); if (t) tradeSheet(JT.find(x => String(x.id) === t.dataset.t));
  };
};
function tradeSheet(x) {
  const nw = !x, ea = x && x.source === 'ea'; x = x || { symbol: 'XAUUSD', side: 'compra', lots: '', open_price: '', close_price: '', sl: '', tp: '', profit: '', close_time: new Date().toISOString(), note: '' };
  const lt = t => { const d = new Date(t), p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`; };
  const f = (id, l, v) => `<label class="fl">${l}<input id="${id}" inputmode="decimal" value="${v == null ? '' : esc(v)}"${ea ? ' disabled' : ''}></label>`;
  sheet(nw ? 'Añadir operación' : `${x.symbol} · ${x.side}`, `${ea ? '<div class="demo-note">Operación verificada de MetaTrader: solo puedes añadir una nota.</div>' : ''}
    ${ea ? '' : `<div class="segm" id="tr-side"><button type="button" data-v="compra" aria-pressed="${x.side === 'compra'}">▲ Compra</button><button type="button" data-v="venta" aria-pressed="${x.side === 'venta'}">▼ Venta</button></div>`}
    <div class="fgrid"><label class="fl">Mercado<input id="tr-sym" value="${esc(x.symbol)}"${ea ? ' disabled' : ''}></label>${f('tr-lots', 'Lotes', x.lots)}</div>
    <div class="fgrid">${f('tr-op', 'Precio de entrada', x.open_price)}${f('tr-cp', 'Precio de salida', x.close_price)}</div>
    <div class="fgrid">${f('tr-sl', 'Stop loss', x.sl)}${f('tr-tp', 'Take profit', x.tp)}</div>
    <div class="fgrid">${f('tr-pr', 'Resultado ($)', x.profit)}<label class="fl">Fecha de cierre<input type="datetime-local" id="tr-ct" value="${lt(x.close_time)}"${ea ? ' disabled' : ''}></label></div>
    <label class="fl">Nota (qué aprendiste, por qué entraste…)<textarea id="tr-note" rows="3" maxlength="1000">${esc(x.note || '')}</textarea></label>
    <button class="btn gold full" id="tr-go" type="button">Guardar</button>${!nw && !ea ? '<button class="btn danger full" id="tr-del" type="button" style="margin-top:10px">Borrar operación</button>' : ''}`, el => {
    let side = x.side;
    el.onclick = async e => {
      const sd = e.target.closest('#tr-side [data-v]'); if (sd) { side = sd.dataset.v; $$('#tr-side button').forEach(b => b.setAttribute('aria-pressed', b === sd)); return; }
      if (e.target.id === 'tr-del') { if (!confirm('¿Borrar esta operación?')) return; try { await comm.deleteTrade(x.id); closeSheet(); RENDER.diario(); } catch (z) { toast(z.message); } return; }
      if (e.target.id !== 'tr-go') return;
      const v = id => { const s = $(id).value.trim(); return s === '' ? null : num(s); };
      try {
        if (ea) await comm.updateTrade(x.id, { note: $('#tr-note').value.trim() || null });
        else { const o = { symbol: $('#tr-sym').value.trim().toUpperCase() || 'XAUUSD', side, lots: v('#tr-lots') || 0, open_price: v('#tr-op'), close_price: v('#tr-cp'), sl: v('#tr-sl'), tp: v('#tr-tp'), close_time: new Date($('#tr-ct').value).toISOString(), note: $('#tr-note').value.trim() || null };
          o.profit = v('#tr-pr'); if (o.profit == null) return toast('Pon el resultado en dólares (en negativo si perdiste)');
          if (nw) await comm.addTrade(o); else await comm.updateTrade(x.id, { ...o, pips: null }); }
        closeSheet(); toast('Operación guardada'); RENDER.diario();
      } catch (z) { toast(z.message); }
    };
  });
}

// =============== CUENTA: registro, entrada, perfil y foto ===============
let authMode = 'register', recovery = false, pendingAvatar = null;
const CAM = '<svg viewBox="0 0 24 24"><path d="M9 3 7.2 5H4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-3.2L15 3zm3 15a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-2a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/></svg>';
const NORMAS = ['Respeto: nada de insultos, acoso ni discriminación.', 'Nada de spam, publicidad ni venta de señales o cursos.', 'Comparte análisis, no promesas: nadie garantiza resultados.', 'No pidas ni compartas contraseñas o datos de cuentas.', 'Los mentores pueden borrar mensajes y expulsar a quien no cumpla las normas.'];
RENDER.cuenta = () => {
  const el = $('#acct'), me = comm.me(), back = gate() === 'ok' ? '<a class="back" href="#mas">‹ Más</a>' : '';
  const demo = comm.mode === 'demo' ? '<div class="demo-note">Modo demo: tu perfil se guarda solo en este móvil. Cuando conectes la comunidad (Supabase), el registro será real y todos os veréis.</div>' : '';
  if (recovery) {
    el.innerHTML = back + `<div class="auth-hero"><img src="icons/logo-192.png" alt=""><h1>Nueva contraseña</h1></div><form class="card authbox" id="newpass"><label>Nueva contraseña<input id="np" type="password" minlength="8" autocomplete="new-password" required></label><p class="err" id="np-err" role="alert"></p><button class="btn gold full">Guardar contraseña</button></form>`;
    return;
  }
  if (!me) {
    const reg = authMode === 'register';
    el.innerHTML = back + `<div class="auth-hero"><img src="icons/logo-192.png" alt=""><h1>${reg ? 'Únete a la comunidad' : 'Bienvenido de nuevo'}</h1><p class="sub" style="margin:0">${reg ? 'Paso 1 de 2 · Crea tu cuenta. Después vincularás tu cuenta MT5 del bróker y el equipo la verificará.' : 'Entra con tu correo y contraseña.'}</p></div>
    <div class="segm"><button type="button" data-am="register" aria-pressed="${reg}">Crear cuenta</button><button type="button" data-am="login" aria-pressed="${!reg}">Entrar</button></div>
    <form class="card authbox" id="auth" novalidate>
      ${reg ? `<button type="button" class="avpick" id="avpick" aria-label="Elegir foto de perfil">${pendingAvatar ? `<img src="${esc(pendingAvatar.url)}" alt="">` : 'Añadir<br>foto'}<span class="cam">${CAM}</span></button>
      <label>Alias (tu nombre en la comunidad)<input id="a-alias" maxlength="20" autocomplete="nickname" required></label>` : ''}
      <label>Correo electrónico<input id="a-mail" type="email" inputmode="email" autocomplete="email" required></label>
      <label>Contraseña<input id="a-pass" type="password" minlength="8" autocomplete="${reg ? 'new-password' : 'current-password'}" required></label>
      ${reg ? `<label class="check"><input type="checkbox" id="a-ok"><span>Acepto las <button type="button" class="linkb" id="normas" style="padding:0;min-height:0">normas de la comunidad</button> y que la app es informativa, no asesoramiento financiero.</span></label>` : '<button type="button" class="linkb" id="forgot">¿Has olvidado la contraseña?</button>'}
      <p class="err" id="a-err" role="alert"></p>
      <button class="btn gold full" id="a-go">${reg ? 'Crear mi cuenta' : 'Entrar'}</button>
    </form>${demo}`;
    return;
  }
  ranked(); const mt = traders.find(t => t.me);
  el.innerHTML = back + `<div class="pcard"><span class="pa" id="pa" role="button" aria-label="Cambiar foto de perfil">${avHTML(me, 84)}<span class="pcam">${CAM}</span></span><div style="min-width:0"><h2>${esc(me.alias)}</h2><span class="sub">${esc(me.email || '')}</span><br><span class="sub">Miembro desde ${new Date(me.created_at || Date.now()).toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}</span></div></div>
  <form class="card authbox" id="prof"><label>Alias<input id="p-alias" maxlength="20" value="${esc(me.alias)}" required></label><label>Sobre mí<textarea class="in2" id="p-bio" maxlength="140" placeholder="Qué operas, tu estilo…">${esc(me.bio || '')}</textarea></label><p class="err" id="p-err" role="alert"></p><button class="btn gold full">Guardar perfil</button></form>
  <h2 class="sec">Liga de trading</h2>
  ${mt ? `<div class="kpis"><div><span>Posición</span><b>${mt.ok ? mt.pos + 'º' : '–'}</b></div><div><span>Puntos</span><b>${mt.score}</b></div><div><span>Ganancia</span><b class="${mt.gain >= 0 ? 'u' : 'd'}">${sg(mt.gain, 1)} %</b></div><div><span>Drawdown máx.</span><b>${dec(mt.dd, 1)} %</b></div></div><button class="btn ghost full" id="unlink">Desvincular cuenta MetaTrader</button>`
  : `<form class="card authbox" id="link" novalidate><p class="sub" style="margin:0">Vincula tu MetaTrader con la <b>contraseña de inversor</b> (solo lectura).</p><div class="radio"><label><input type="radio" name="pl" value="MT5" checked>MetaTrader 5</label><label><input type="radio" name="pl" value="MT4">MetaTrader 4</label></div><label>Número de cuenta<input id="f-login" inputmode="numeric" required></label><label>Servidor del bróker<input id="f-server" placeholder="p. ej. ICMarketsSC-Demo" required></label><label>Contraseña de inversor<input id="f-pass" type="password" autocomplete="off" required></label><p class="err" id="f-err" role="alert"></p><ol class="lsteps" id="lsteps" hidden></ol><button class="btn gold full" id="go">Vincular y entrar en la liga</button></form>`}
  ${demo}
  <button class="btn ghost full" id="logout" style="margin-top:12px">Cerrar sesión</button>
  <button class="btn full" id="delacc" style="margin-top:10px;background:none;color:var(--dn);border:1px solid rgba(255,95,95,.4)">Eliminar mi cuenta</button>`;
};
async function pickPhoto(f) {
  if (!f || !/^image\//.test(f.type)) { toast('Elige una imagen'); return null; }
  try { return await shrink(f, 360, true); } catch (e) { toast(e.message); return null; }
}
let avatarTarget = 'profile';
$('#f-avatar').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; const blob = await pickPhoto(f); if (!blob) return;
  if (avatarTarget === 'signup') { if (pendingAvatar) URL.revokeObjectURL(pendingAvatar.url); pendingAvatar = { blob, url: URL.createObjectURL(blob) }; RENDER.cuenta(); return; }
  toast('Subiendo foto…');
  try { await comm.uploadAvatar(blob); syncUser(); RENDER.cuenta(); toast('Foto de perfil actualizada'); } catch (x) { toast(x.message); }
};
$('#acct').addEventListener('click', async e => {
  const am = e.target.closest('[data-am]'); if (am) { authMode = am.dataset.am; RENDER.cuenta(); return; }
  if (e.target.closest('#avpick')) { avatarTarget = 'signup'; $('#f-avatar').click(); return; }
  if (e.target.closest('#pa')) { avatarTarget = 'profile'; $('#f-avatar').click(); return; }
  if (e.target.id === 'normas') { sheet('Normas de la comunidad', `<ol class="steps" style="margin-bottom:14px">${NORMAS.map(n => `<li>${n}</li>`).join('')}</ol>`); return; }
  if (e.target.id === 'forgot') {
    const mail = ($('#a-mail').value || '').trim(), err = $('#a-err');
    if (!/^\S+@\S+\.\S+$/.test(mail)) { err.textContent = 'Escribe arriba tu correo y vuelve a pulsar.'; return; }
    try { await comm.resetPassword(mail); err.textContent = ''; toast('Te hemos enviado un correo para cambiar la contraseña'); } catch (x) { err.textContent = x.message; }
    return;
  }
  if (e.target.id === 'delacc') {
    const b = e.target; if (!b.dataset.sure) { b.dataset.sure = 1; b.textContent = 'Toca otra vez para borrar tu cuenta y tus mensajes'; return; }
    try { await comm.deleteAccount(); } catch (x) { return toast(x.message); }
    ['fr.mt', 'fr.journal', 'fr.book', 'fr.course'].forEach(k => LS.del(k)); traders = traders.filter(t => !t.me); journal = [];
    syncUser(); RENDER.cuenta(); toast('Cuenta eliminada'); return;
  }
  if (e.target.id === 'logout') { try { await comm.signOut(); } catch (x) {} LS.del('fr.mt'); traders = traders.filter(t => !t.me); syncUser(); authMode = 'login'; RENDER.cuenta(); toast('Sesión cerrada'); return; }
  if (e.target.id === 'unlink') { if (LIVE) { try { await api('/api/accounts/mine', { method: 'DELETE' }); await loadLeague(); } catch (x) { return toast(x.message); } } else { traders = traders.filter(t => !t.me); LS.del('fr.mt'); } toast('Cuenta desvinculada'); RENDER.cuenta(); }
});
$('#acct').addEventListener('submit', async e => {
  e.preventDefault();
  const id = e.target.id;
  if (id === 'newpass') {
    const pw = $('#np').value; if (pw.length < 8) { $('#np-err').textContent = 'Mínimo 8 caracteres.'; return; }
    try { await comm.setPassword(pw); recovery = false; toast('Contraseña cambiada'); syncUser(); RENDER.cuenta(); } catch (x) { $('#np-err').textContent = x.message; }
    return;
  }
  if (id === 'auth') {
    const err = $('#a-err'), go = $('#a-go'), mail = $('#a-mail').value.trim(), pass = $('#a-pass').value; err.textContent = '';
    if (!/^\S+@\S+\.\S+$/.test(mail)) return err.textContent = 'Escribe un correo válido.';
    if (pass.length < 8) return err.textContent = 'La contraseña necesita al menos 8 caracteres.';
    go.disabled = true;
    try {
      if (authMode === 'register') {
        const alias = $('#a-alias').value.trim();
        if (!/^[\p{L}\p{N}_.\-]{3,20}$/u.test(alias)) throw new Error('Alias de 3 a 20 caracteres: letras, números, punto o guiones.');
        if (!$('#a-ok').checked) throw new Error('Acepta las normas de la comunidad para continuar.');
        const r = await comm.signUp({ alias, email: mail, password: pass, avatar: pendingAvatar && pendingAvatar.blob });
        pendingAvatar = null;
        if (r.needsConfirm) { authMode = 'login'; RENDER.cuenta(); sheet('Revisa tu correo', `<p>Te hemos enviado un enlace a <b>${esc(mail)}</b>. Púlsalo para activar tu cuenta y después entra aquí.</p><p class="sub">Si no lo ves, mira en la carpeta de spam.</p>`); return; }
        toast('¡Bienvenido a Fortuna Radiante, ' + alias + '!');
      } else { await comm.signIn({ email: mail, password: pass }); toast('¡Hola de nuevo!'); }
      syncUser(); if (comm.mode === 'demo') boot(); else RENDER.cuenta();
    } catch (x) { err.textContent = x.message; go.disabled = false; }
    return;
  }
  if (id === 'prof') {
    const alias = $('#p-alias').value.trim(), bio = $('#p-bio').value.trim().slice(0, 140), err = $('#p-err'); err.textContent = '';
    if (!/^[\p{L}\p{N}_.\-]{3,20}$/u.test(alias)) return err.textContent = 'Alias de 3 a 20 caracteres: letras, números, punto o guiones.';
    try { await comm.updateProfile({ alias, bio }); syncUser(); toast('Perfil guardado'); RENDER.cuenta(); } catch (x) { err.textContent = x.message; }
    return;
  }
  if (id !== 'link') return;
  const err = $('#f-err'), login = $('#f-login').value.trim(), server = $('#f-server').value.trim(), password = $('#f-pass').value, platform = $('input[name=pl]:checked').value; err.textContent = '';
  if (!/^\d{4,12}$/.test(login)) return err.textContent = 'El número de cuenta solo lleva dígitos.';
  if (server.length < 3) return err.textContent = 'Indica el servidor exacto del bróker.';
  if (password.length < 4) return err.textContent = 'Introduce la contraseña de inversor.';
  const go = $('#go'), st = $('#lsteps'); go.disabled = true; st.hidden = false;
  const L = ['Conectando con el bróker', 'Verificando contraseña de inversor', 'Sincronizando historial', 'Calculando puntos'];
  const mark = i => st.innerHTML = L.map((t, k) => `<li class="${k < i ? 'ok' : k === i ? 'now' : ''}">${k < i ? '✓' : k === i ? '…' : '·'} ${t}</li>`).join('');
  try {
    if (LIVE) { mark(0); await api('/api/accounts', { method: 'POST', body: { login, server, password, platform } }); await loadLeague(); }
    else { for (let i = 0; i < 4; i++) { mark(i); await wait(600); } const me = stats({ id: 'me', me: true, alias: user.alias, platform, server, loginMasked: '•••' + login.slice(-3), curve: curve(.004, .022), trades: Math.round(12 + rnd() * 80), win: Math.round(45 + rnd() * 25) }); traders = traders.filter(t => !t.me); traders.push(me); LS.set('fr.mt', me); }
    toast('Cuenta vinculada. ¡Ya estás en la liga!'); RENDER.cuenta();
  } catch (x) { err.textContent = x.message; st.hidden = true; go.disabled = false; $('#f-pass').value = ''; }
});
comm.onAuth(ev => { if (ev === 'recovery') { recovery = true; show('cuenta'); } syncUser(); loadAlerts(); boot(); if (view === 'cuenta') RENDER.cuenta(); if (view === 'comunidad') RENDER.comunidad(); });

// =============== NOTIFICACIONES Y ALERTAS DE PRECIO ===============
const VAPID = String(window.FR_VAPID_PUBLIC || '');
const isCap = !!window.Capacitor, isIOS = /iPhone|iPad|iPod/.test(navigator.userAgent);
const standalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
const capPush = () => { try { return isCap && window.Capacitor.isPluginAvailable && window.Capacitor.isPluginAvailable('PushNotifications') ? window.Capacitor.Plugins.PushNotifications : null; } catch (e) { return null; } };
const pushOK = () => !isCap && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
const b64u = s => { const p = '='.repeat((4 - s.length % 4) % 4), b = atob((s + p).replace(/-/g, '+').replace(/_/g, '/')); return Uint8Array.from(b, c => c.charCodeAt(0)); };
const swReady = () => Promise.race([navigator.serviceWorker.ready, wait(6000).then(() => null)]);
async function currentSub() { if (!pushOK()) return null; const reg = await swReady(); return reg ? reg.pushManager.getSubscription() : null; }
async function loadAlerts() { try { ALERTS = await comm.alerts(); } catch (e) { ALERTS = []; } if (view === 'avisos') RENDER.avisos(); }
async function enableCapPush() {
  const P = capPush(); if (!P) throw new Error('Instala el APK nuevo');
  if (!comm.me()) throw new Error('Entra en tu cuenta primero');
  let perm = await P.checkPermissions(); if (perm.receive !== 'granted') perm = await P.requestPermissions();
  if (perm.receive !== 'granted') throw new Error('No has dado permiso para las notificaciones');
  try { await P.createChannel({ id: 'avisos', name: 'Avisos de Fortuna Radiante', importance: 4, visibility: 1, lights: true, vibration: true }); } catch (e) {}
  const token = await new Promise((ok, ko) => {
    const t = setTimeout(() => ko(new Error('Firebase no responde. Revisa la configuración (google-services.json).')), 20000);
    P.addListener('registration', r => { clearTimeout(t); ok(r.value); });
    P.addListener('registrationError', er => { clearTimeout(t); ko(new Error('Error de Firebase: ' + (er && er.error || ''))); });
    P.register().catch(er => { clearTimeout(t); ko(er); });
  });
  await comm.savePush({ endpoint: 'fcm:' + token, p256dh: 'fcm', auth: 'fcm', chat_pref: 'mentions' });
  return token;
}
if (capPush()) { try { capPush().addListener('pushNotificationActionPerformed', a => { const u = a && a.notification && a.notification.data && a.notification.data.url; if (u) show(String(u).replace('#', '')); }); capPush().addListener('pushNotificationReceived', n => { if (n && n.title) toast(n.title + (n.body ? ' · ' + n.body : '')); }); } catch (e) {} }
const PREFS = [['all', 'Todos los mensajes'], ['mentions', 'Solo cuando me mencionan'], ['none', 'Ninguno del chat']];
RENDER.avisos = async () => {
  const box = $('#av-push'), me = comm.me();
  let html = '';
  if (comm.mode === 'demo') html = '<p class="sub" style="margin:0">Las notificaciones en el móvil funcionan cuando la comunidad está conectada (Supabase). Las alertas de precio de abajo sí avisan mientras la app está abierta.</p>';
  else if (!me) html = '<p class="sub" style="margin:0 0 10px">Entra en tu cuenta para activar las notificaciones.</p><button class="btn gold full" data-go="cuenta">Entrar o crear cuenta</button>';
  else if (isCap && !capPush()) html = '<p style="margin:0 0 8px"><b>Instala el APK nuevo para activar las notificaciones.</b></p><p class="sub" style="margin:0">Descárgalo en GitHub → Actions → «Android · instalador APK» → Artifacts e instálalo encima de esta app. Mientras tanto, te avisa dentro de la app cuando la tienes abierta.</p>';
  else if (isCap) {
    const tok = LS.get('fr.fcm');
    if (tok) {
      let pref = 'mentions'; try { pref = (await comm.pushPref('fcm:' + tok)) || pref; } catch (e) {}
      html = `<p style="margin:0 0 10px"><b class="u">● Notificaciones activadas en este móvil</b></p><div class="lbl" style="margin-bottom:6px">Avisos del chat</div><div class="list">${PREFS.map(([k, l]) => `<button class="opt" data-pref="${k}" aria-pressed="${k === pref}" style="padding:10px 12px"><span>${l}</span>${k === pref ? '<span class="u">✓</span>' : ''}</button>`).join('')}</div><p class="sub">Las alertas de precio siempre te avisan.</p><button class="btn ghost full" id="av-off">Desactivar</button>`;
    } else html = `<p style="margin:0 0 12px">Recibe un aviso aunque tengas la app cerrada cuando te mencionen en el chat o se cumpla una alerta de precio.</p><button class="btn gold full" id="av-on">Activar notificaciones</button>`;
  }
  else if (isIOS && !standalone()) html = '<p style="margin:0 0 8px"><b>En iPhone, primero instala la app desde Safari.</b></p><p class="sub" style="margin:0">Compartir → Añadir a pantalla de inicio. Ábrela desde el icono y vuelve aquí para activarlas (iOS 16.4 o superior).</p>';
  else if (!pushOK()) html = '<p class="sub" style="margin:0">Este navegador no admite notificaciones. Prueba con Chrome o Safari.</p>';
  else if (!VAPID) html = '<p class="sub" style="margin:0">Falta configurar las notificaciones en la app (clave VAPID).</p>';
  else if (Notification.permission === 'denied') html = '<p style="margin:0 0 8px"><b>Has bloqueado las notificaciones.</b></p><p class="sub" style="margin:0">Actívalas en los ajustes del móvil: Ajustes → Notificaciones → Fortuna Radiante (o en los permisos del navegador) y vuelve aquí.</p>';
  else {
    const sub = await currentSub();
    if (sub) {
      let pref = 'mentions'; try { pref = (await comm.pushPref(sub.endpoint)) || pref; } catch (e) {}
      html = `<p style="margin:0 0 10px"><b class="u">● Notificaciones activadas en este móvil</b></p><div class="lbl" style="margin-bottom:6px">Avisos del chat</div><div class="list" id="av-pref">${PREFS.map(([k, l]) => `<button class="opt" data-pref="${k}" aria-pressed="${k === pref}" style="padding:10px 12px"><span>${l}</span>${k === pref ? '<span class="u">✓</span>' : ''}</button>`).join('')}</div><p class="sub">Las alertas de precio siempre te avisan.</p><div class="grid2" style="margin-top:10px"><button class="btn ghost" id="av-test">Probar</button><button class="btn ghost" id="av-off">Desactivar</button></div>`;
    } else html = `<p style="margin:0 0 12px">Recibe un aviso aunque tengas la app cerrada cuando te mencionen en el chat o se cumpla una alerta de precio.</p><button class="btn gold full" id="av-on">Activar notificaciones</button>`;
  }
  box.innerHTML = html;
  // alertas
  const sel = $('#al-sym'); if (sel.options.length !== VIS().length) sel.innerHTML = VIS().map(s => `<option value="${s}">${s} · ${SY[s].n}</option>`).join('');
  if (!$('#al-price').value) $('#al-price').value = px[sel.value] != null ? px[sel.value].toFixed(SY[sel.value].d) : '';
  const act = ALERTS.filter(x => x.active), done = ALERTS.filter(x => !x.active).slice(0, 5);
  $('#al-list').innerHTML = (act.length ? act.map(x => `<div class="jr"><div><b>${esc(x.symbol)} ${x.above ? '▲ si sube a' : '▼ si baja a'} ${dec(x.price, (SY[x.symbol] || { d: 2 }).d)}</b><small>Ahora: ${px[x.symbol] != null ? dec(px[x.symbol], SY[x.symbol].d) : '—'}</small></div><span></span><button class="x" data-al="${esc(x.id)}" aria-label="Borrar alerta">×</button></div>`).join('') : '<p class="sub">No tienes alertas activas.</p>')
    + (done.length ? '<h3 class="sec" style="font-size:15px">Cumplidas</h3>' + done.map(x => `<div class="jr" style="opacity:.6"><div><b>${esc(x.symbol)} ${dec(x.price, (SY[x.symbol] || { d: 2 }).d)}</b><small>${x.triggered_at ? new Date(x.triggered_at).toLocaleString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : ''}</small></div><span class="u">✓</span><button class="x" data-al="${esc(x.id)}" aria-label="Borrar">×</button></div>`).join('') : '');
};
$('#al-sym').onchange = () => { const s = $('#al-sym').value; $('#al-price').value = px[s] != null ? px[s].toFixed(SY[s].d) : ''; };
$('#al-f').onsubmit = async e => {
  e.preventDefault();
  if (comm.mode === 'online' && !comm.me()) { toast('Entra en tu cuenta para guardar alertas'); show('cuenta'); return; }
  const s = $('#al-sym').value, price = num($('#al-price').value), now = px[s];
  if (!(price > 0)) return toast('Escribe un precio');
  if (now != null && Math.abs(price - now) < 10 ** -SY[s].d) return toast('Ese es el precio actual: elige otro');
  try { const al = { active: true, ...(await comm.addAlert({ symbol: s, price, above: now == null ? true : price > now })) }; ALERTS.unshift(al); toast(`Alerta creada: ${s} ${al.above ? 'sube a' : 'baja a'} ${dec(price, SY[s].d)}`); RENDER.avisos(); } catch (x) { toast(x.message); }
};
$('#v-avisos').addEventListener('click', async e => {
  const d = e.target.closest('[data-al]');
  if (d) { const id = isNaN(+d.dataset.al) ? d.dataset.al : +d.dataset.al; try { await comm.delAlert(id); ALERTS = ALERTS.filter(x => x.id !== id); RENDER.avisos(); } catch (x) { toast(x.message); } return; }
  if (e.target.id === 'av-on' && isCap) {
    const b = e.target; b.disabled = true; b.textContent = 'Activando…';
    try { const tok = await enableCapPush(); LS.set('fr.fcm', tok); toast('Notificaciones activadas ✓'); } catch (x) { toast(x.message || 'No se pudieron activar'); }
    RENDER.avisos(); return;
  }
  if (e.target.id === 'av-on') {
    const b = e.target; b.disabled = true; b.textContent = 'Activando…';
    try {
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') throw new Error('No has dado permiso para las notificaciones');
      const reg = await swReady(); if (!reg) throw new Error('La app aún se está instalando. Ciérrala, ábrela otra vez y repite.');
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64u(VAPID) });
      const j = sub.toJSON(); await comm.savePush({ endpoint: j.endpoint, p256dh: j.keys.p256dh, auth: j.keys.auth, chat_pref: 'mentions' });
      toast('Notificaciones activadas ✓');
    } catch (x) { toast(x.message || 'No se pudieron activar'); }
    RENDER.avisos(); return;
  }
  const p = e.target.closest('[data-pref]');
  if (p && isCap) { const tok = LS.get('fr.fcm'); if (!tok) return; try { await comm.savePush({ endpoint: 'fcm:' + tok, p256dh: 'fcm', auth: 'fcm', chat_pref: p.dataset.pref }); toast('Guardado'); } catch (x) { toast(x.message); } RENDER.avisos(); return; }
  if (p) { const sub = await currentSub(); if (!sub) return; const j = sub.toJSON(); try { await comm.savePush({ endpoint: j.endpoint, p256dh: j.keys.p256dh, auth: j.keys.auth, chat_pref: p.dataset.pref }); toast('Guardado'); } catch (x) { toast(x.message); } RENDER.avisos(); return; }
  if (e.target.id === 'av-test') { const reg = await swReady(); if (reg) reg.showNotification('Fortuna Radiante', { body: 'Así verás tus avisos de chat y alertas de precio ✨', icon: 'icons/icon-192.png', badge: 'icons/logo-96.png' }); return; }
  if (e.target.id === 'av-off' && isCap) { const tok = LS.get('fr.fcm'); if (tok) { try { await comm.deletePush('fcm:' + tok); } catch (x) {} } try { await capPush().unregister(); } catch (x) {} LS.del('fr.fcm'); toast('Notificaciones desactivadas'); RENDER.avisos(); return; }
  if (e.target.id === 'av-off') { const sub = await currentSub(); if (sub) { try { await comm.deletePush(sub.endpoint); } catch (x) {} await sub.unsubscribe(); } toast('Notificaciones desactivadas'); RENDER.avisos(); }
});

// =============== INSTALAR (PWA) ===============
let installEvt = null;
addEventListener('beforeinstallprompt', e => { e.preventDefault(); installEvt = e; $('#inst-btn').hidden = false; });
$('#inst-btn').onclick = async () => { if (!installEvt) return; installEvt.prompt(); try { await installEvt.userChoice; } catch (e) {} installEvt = null; $('#inst-btn').hidden = true; };
try { if (!window.Capacitor && 'serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost') && !/claude\.ai|claudeusercontent/.test(location.hostname)) navigator.serviceWorker.register('sw.js').catch(() => {}); } catch (e) {}

// =============== arranque ===============
setTimeout(() => { const sp = $('#splash'); sp.classList.add('out'); setTimeout(() => sp.remove(), 700); }, reduce ? 300 : 1400);
syncUser();
initRefs(); demoLeague(); demoMent(); buildTicker(); requestAnimationFrame(tkLoop);
comm.init().then(() => { syncUser(); loadAlerts(); boot(); feedPoll(); if (['comunidad', 'cuenta', 'avisos'].includes(view)) RENDER[view](); }).catch(e => toast('Comunidad: ' + e.message));
if (comm.mode === 'demo') loadAlerts();
setInterval(feedPoll, 2000);
setInterval(resyncCandles, 60000);
show(location.hash.slice(1) || 'inicio');
getSampler().then(s => { if (!FT.mode && !(LIVE && FEAT.ai)) { FT.mode = s ? 'sample' : 'offline'; if (view === 'fortunaty') renderFT(); } });

let tickN = 0;
function demoTick() {
  if (!(LIVE && FEAT.prices)) ORDER.forEach(s => { if (!isReal(s)) { applyPrice(s, px[s] * (1 + (rnd() - .5) * 2 * SY[s].v * .7)); checkAlerts(s); } });
  updTicker(); tickN++;
  if (view === 'inicio') { renderHero(); if (tickN % 3 === 0) renderMarkets(); }
  if (view === 'grafico') panes.forEach(p => { const c = LAY.panes[p.i], k = c.sym + '|' + c.tf; if (series[k]) { p.chart.setExtra(extraFor(c, p.chart.getInd()), true); p.chart.setData(series[k], null, null, true); legend(p, null); indEvents(p); } paneHead(p); });
}
setInterval(demoTick, 1000);
setInterval(leagueTick, 3000);
setInterval(() => { if (view === 'inicio') { renderPulse(); sessMini(); } if (view === 'utiles') sessions(); }, 30000);

fetch(API + '/api/health').then(r => r.ok ? r.json() : null).then(async j => {
  if (!j || !j.ok) return;
  LIVE = true; FEAT = j.features || {}; $('#mode').textContent = 'En directo';
  FT.mode = null;
  if (FEAT.candles) { for (const k in series) delete series[k]; await Promise.all(ORDER.map(s => getSeries(s, 15))); ORDER.forEach(s => { const a = series[s + '|15']; if (a && a.length) { px[s] = a[a.length - 1].close; ref[s] = a[Math.max(0, a.length - 97)].close; } }); await Promise.all([60, 240, 1440].map(m => getSeries('XAUUSD', m))); }
  if (FEAT.prices) { const poll = async () => { try { const p = await api('/api/prices'); for (const s in p.prices) if (SY[s] && p.prices[s]) applyPrice(s, (p.prices[s].bid + p.prices[s].ask) / 2); } catch (e) {} }; await poll(); setInterval(poll, 2000); }
  await Promise.all([loadLeague().catch(() => {}), loadMent()]);
  show(view);
  setInterval(() => loadLeague().catch(() => {}), 60000);
}).catch(() => {});
}
