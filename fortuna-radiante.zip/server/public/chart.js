// FortunaChart — gráfico financiero interactivo estilo TradingView, sin dependencias.
// Arrastrar para mover · pellizcar o rueda para zoom · arrastrar la escala de precios para estirar
// (doble toque en la escala = automática) · pulsación larga = cruz · herramientas de dibujo editables.
(function () {
  // ---------- indicadores (funciones puras) ----------
  const ema = (a, n) => { const k = 2 / (n + 1), o = new Array(a.length); for (let i = 0; i < a.length; i++) o[i] = i ? a[i] * k + o[i - 1] * (1 - k) : a[i]; return o; };
  function bands(c, n, k) {
    const U = [], M = [], D = []; let s = 0, s2 = 0;
    for (let i = 0; i < c.length; i++) {
      s += c[i]; s2 += c[i] * c[i];
      if (i >= n) { s -= c[i - n]; s2 -= c[i - n] * c[i - n]; }
      if (i < n - 1) { U.push(null); M.push(null); D.push(null); continue; }
      const m = s / n, sd = Math.sqrt(Math.max(0, s2 / n - m * m)); M.push(m); U.push(m + k * sd); D.push(m - k * sd);
    }
    return { U, M, D };
  }
  function rsi(c, n) {
    const o = [null]; let g = 0, l = 0;
    for (let i = 1; i < c.length; i++) {
      const d = c[i] - c[i - 1], u = Math.max(d, 0), w = Math.max(-d, 0);
      if (i <= n) { g += u / n; l += w / n; o.push(i < n ? null : 100 - 100 / (1 + g / (l || 1e-12))); continue; }
      g = (g * (n - 1) + u) / n; l = (l * (n - 1) + w) / n; o.push(100 - 100 / (1 + g / (l || 1e-12)));
    }
    return o;
  }
  function macd(c, f, s, g) { const a = ema(c, f), b = ema(c, s), m = c.map((_, i) => a[i] - b[i]), sg = ema(m, g); return { m, sg, h: m.map((v, i) => v - sg[i]) }; }
  function pivots(d, step) {
    if (d.length < 2) return [];
    let prev;
    if (step >= 864e5) { const p = d[d.length - 2]; prev = { h: p.high, l: p.low, c: p.close }; }
    else {
      const day = t => Math.floor(t / 864e5), today = day(d[d.length - 1].time); let h = -Infinity, l = Infinity, c = null, found = null;
      for (let i = d.length - 1; i >= 0; i--) { const k = day(d[i].time); if (k === today) continue; if (found === null) found = k; if (k !== found) break; h = Math.max(h, d[i].high); l = Math.min(l, d[i].low); if (c === null) c = d[i].close; }
      if (found === null) return []; prev = { h, l, c };
    }
    const P = (prev.h + prev.l + prev.c) / 3, r = prev.h - prev.l;
    return [['R2', P + r], ['R1', 2 * P - prev.l], ['P', P], ['S1', 2 * P - prev.h], ['S2', P - r]];
  }
  function heikin(d) { const o = []; d.forEach((x, i) => { const c = (x.open + x.high + x.low + x.close) / 4, op = i ? (o[i - 1].open + o[i - 1].close) / 2 : (x.open + x.close) / 2; o.push({ time: x.time, open: op, close: c, high: Math.max(x.high, op, c), low: Math.min(x.low, op, c) }); }); return o; }
  // Divergencias RSI: el precio hace un mínimo más bajo y el RSI uno más alto (alcista), o al revés (bajista)
  function divergences(d, r, L = 4, maxGap = 70) {
    const lows = [], highs = [], out = [];
    for (let i = L; i < d.length - L; i++) {
      let lo = r[i] != null, hi = r[i] != null;
      for (let k = 1; k <= L && (lo || hi); k++) { if (d[i - k].low <= d[i].low || d[i + k].low < d[i].low) lo = false; if (d[i - k].high >= d[i].high || d[i + k].high > d[i].high) hi = false; }
      if (lo) lows.push(i); if (hi) highs.push(i);
    }
    for (let j = 1; j < lows.length; j++) { const a = lows[j - 1], b = lows[j]; if (b - a < 5 || b - a > maxGap) continue; if (d[b].low < d[a].low && r[b] > r[a] + 1 && r[a] < 45) out.push({ type: 'bull', a, b, pa: d[a].low, pb: d[b].low, ra: r[a], rb: r[b] }); }
    for (let j = 1; j < highs.length; j++) { const a = highs[j - 1], b = highs[j]; if (b - a < 5 || b - a > maxGap) continue; if (d[b].high > d[a].high && r[b] < r[a] - 1 && r[a] > 55) out.push({ type: 'bear', a, b, pa: d[a].high, pb: d[b].high, ra: r[a], rb: r[b] }); }
    return out.sort((x, y) => x.b - y.b).slice(-14);
  }
  // Perfil de volumen: reparte el volumen de cada vela entre los precios que recorrió
  function volumeProfile(d, from, to, lo, hi, bins) {
    const h = (hi - lo) / bins, v = new Array(bins).fill(0); if (!(h > 0)) return null;
    for (let i = Math.max(0, from); i <= Math.min(d.length - 1, to); i++) {
      const c = d[i], vol = c.vol > 0 ? c.vol : 1, l = Math.max(lo, c.low), t = Math.min(hi, c.high); if (t < l) continue;
      const b0 = Math.max(0, Math.floor((l - lo) / h)), b1 = Math.min(bins - 1, Math.floor((t - lo) / h)), per = vol / (b1 - b0 + 1);
      for (let k = b0; k <= b1; k++) v[k] += per;
    }
    const tot = v.reduce((a, b) => a + b, 0); if (!tot) return null;
    let poc = 0; v.forEach((x, k) => { if (x > v[poc]) poc = k; });
    let a = poc, b = poc, acc = v[poc];
    while (acc < tot * .7 && (a > 0 || b < bins - 1)) { const dn = a > 0 ? v[a - 1] : -1, up = b < bins - 1 ? v[b + 1] : -1; if (up >= dn) acc += v[++b]; else acc += v[--a]; }
    const px = k => lo + (k + .5) * h;
    return { v, h, lo, poc, va: [a, b], pocPrice: px(poc), vah: lo + (b + 1) * h, val: lo + a * h, real: d.some(x => x.vol > 0) };
  }
  // ---------- Zonas de compras / ventas (lógica del indicador Pine del usuario) ----------
  const ZDEF = { cur: true, htf: true, htfTf: 60, len: 7, hlen: 5, max: 4, minAtr: 0.4, del: true, ext: 15, buy: '#00E676', sell: '#FF1744' };
  function atrArr(H, L, C, n = 14) {
    const o = new Array(H.length).fill(null); let a = null, pc = null, k = 0;
    for (let i = 0; i < H.length; i++) {
      if (H[i] == null) { o[i] = a; continue; }
      const tr = pc == null ? H[i] - L[i] : Math.max(H[i] - L[i], Math.abs(H[i] - pc), Math.abs(L[i] - pc)); k++;
      a = a == null ? tr : k <= n ? (a * (k - 1) + tr) / k : (a * (n - 1) + tr) / n; o[i] = a; pc = C[i];
    }
    return o;
  }
  function emaN(a, n) { const k = 2 / (n + 1), o = new Array(a.length).fill(null); let p = null; for (let i = 0; i < a.length; i++) { if (a[i] == null) { o[i] = p; continue; } p = p == null ? a[i] : a[i] * k + p * (1 - k); o[i] = p; } return o; }
  function isPH(H, p, L) { if (p - L < 0 || p + L >= H.length || H[p] == null) return false; for (let k = 1; k <= L; k++) { if (H[p - k] == null || H[p + k] == null || H[p - k] >= H[p] || H[p + k] > H[p]) return false; } return true; }
  function isPL(Lw, p, L) { if (p - L < 0 || p + L >= Lw.length || Lw[p] == null) return false; for (let k = 1; k <= L; k++) { if (Lw[p - k] == null || Lw[p + k] == null || Lw[p - k] <= Lw[p] || Lw[p + k] < Lw[p]) return false; } return true; }
  // Zonas de temporalidad alta: solo aparecen cuando la vela alta que confirma el pivote ya ha cerrado (sin repintado)
  function htfEvents(hd, len, minAtr, step) {
    if (!hd || hd.length < len * 2 + 2) return [];
    const O = hd.map(x => x.open), H = hd.map(x => x.high), L = hd.map(x => x.low), C = hd.map(x => x.close), atr = atrArr(H, L, C), ev = [];
    for (let j = 2 * len; j < hd.length; j++) {
      const p = j - len, at = j + 1 < hd.length ? hd[j + 1].time : Infinity, w = (atr[j] || 0) * minAtr;
      if (isPH(H, p, len)) { const top = H[p]; let bot = Math.max(O[p], C[p]); if (top - bot < w) bot = top - w; ev.push({ at, left: hd[p].time, top, bot, buy: false }); }
      if (isPL(L, p, len)) { const bot = L[p]; let top = Math.min(O[p], C[p]); if (top - bot < w) top = bot + w; ev.push({ at, left: hd[p].time, top, bot, buy: true }); }
    }
    return ev;
  }
  function pineZones(T, O, H, L, C, o, ev) {
    const n = T.length, atr = atrArr(H, L, C), sup = [], dem = [], hs = [], hd = [], broken = []; let e = 0;
    const manage = (arr, up, c, t) => { for (let i = arr.length - 1; i >= 0; i--) { const z = arr[i]; if (up ? c > z.top : c < z.bot) { arr.splice(i, 1); if (!o.del) { z.end = t; broken.push(z); if (broken.length > 80) broken.shift(); } } } };
    const push = (arr, z) => { arr.unshift(z); if (arr.length > o.max) arr.pop(); };
    for (let i = 0; i < n; i++) {
      const c = C[i]; if (c == null) continue; const t = T[i];
      if (o.cur) {
        manage(sup, true, c, t); manage(dem, false, c, t);
        const p = i - o.len, w = (atr[i] || 0) * o.minAtr;
        if (isPH(H, p, o.len)) { const top = H[p]; let bot = Math.max(O[p], C[p]); if (top - bot < w) bot = top - w; push(sup, { buy: false, top, bot, left: T[p], htf: false }); }
        if (isPL(L, p, o.len)) { const bot = L[p]; let top = Math.min(O[p], C[p]); if (top - bot < w) top = bot + w; push(dem, { buy: true, top, bot, left: T[p], htf: false }); }
      }
      if (ev) { manage(hs, true, c, t); manage(hd, false, c, t); while (e < ev.length && ev[e].at <= t) { const z = ev[e++]; push(z.buy ? hd : hs, { ...z, htf: true }); } }
    }
    return { live: [...sup, ...dem, ...hs, ...hd], broken };
  }
  function alignTo(main, other) {
    const n = main.length, O = new Array(n).fill(null), H = O.slice(), L = O.slice(), C = O.slice(); let j = 0;
    if (other && other.length) for (let i = 0; i < n; i++) { const t = main[i].time; while (j + 1 < other.length && other[j + 1].time <= t) j++; const x = other[j]; if (x.time <= t) { O[i] = x.open; H[i] = x.high; L[i] = x.low; C[i] = x.close; } }
    return { O, H, L, C };
  }
  function corrAt(a, b, i, len) {
    let n = 0, sa = 0, sb = 0, saa = 0, sbb = 0, sab = 0;
    for (let k = Math.max(0, i - len + 1); k <= i; k++) { if (a[k] == null || b[k] == null) continue; n++; sa += a[k]; sb += b[k]; saa += a[k] * a[k]; sbb += b[k] * b[k]; sab += a[k] * b[k]; }
    if (n < 5) return null; const cv = sab / n - sa / n * sb / n, va = saa / n - (sa / n) ** 2, vb = sbb / n - (sb / n) ** 2; return va > 0 && vb > 0 ? cv / Math.sqrt(va * vb) : null;
  }
  const tfName = m => m >= 10080 ? 'W' : m >= 1440 ? 'D' : m >= 60 ? 'H' + Math.round(m / 60) : 'M' + Math.round(m);
  function zonesOf(d, o, ev) { o = { ...ZDEF, ...(o || {}) }; return pineZones(d.map(x => x.time), d.map(x => x.open), d.map(x => x.high), d.map(x => x.low), d.map(x => x.close), o, ev); }
  // ---------- Radiant Fortune Zones · FVG + VI + liquidez + rango + señales (indicador Pine del usuario) ----------
  // ProZones en la app: solo las zonas de compra y venta (sin liquidez, rango, señales ni panel)
  const ZONLY = { range: false, liq: false, pd: false, pw: false, sig: false, panel: false, tint: false, alSweep: false, alSig: false };
  const RDEF = { htf: true, htfMode: 'Auto', htfTf: 240, local: true, fvg: true, vi: true, atrLen: 14, minGap: 0.25, minBody: 0.5, maxLocal: 4, maxVi: 2, maxHtf: 3, hideMit: false, mit: 'Cierre', range: true, rngLen: 100, rngPct: 25, liq: true, pivLen: 5, eqTol: 0.15, maxPools: 6, pd: true, pw: true, sweepLook: 20, rsiLen: 14, ob: 70, os: 30, rsiFilter: true, tint: false, sig: true, trend: false, emaLen: 200, minScore: 2, fill: 60, border: 0, bw: 2, buy: '#00E676', sell: '#FF1744', liqC: '#FFD600', mid: true, tags: true, panel: true, pos: 'Abajo izquierda', size: 'Pequeño', alSweep: false, alSig: false };
  const SH = 6 * 36e5; // los días del bróker empiezan unas horas antes de las 00:00 UTC
  function bucket(t, m) { if (m >= 43200) { const d = new Date(t + SH); return d.getUTCFullYear() * 12 + d.getUTCMonth(); } if (m >= 10080) return Math.floor(((t + SH) / 864e5 + 3) / 7); if (m >= 1440) return Math.floor((t + SH) / 864e5); return Math.floor(t / (m * 6e4)); }
  function aggregate(d, m) { const o = []; let k = null; for (const x of d || []) { const b = bucket(x.time, m); if (b !== k) { k = b; o.push({ time: x.time, open: x.open, high: x.high, low: x.low, close: x.close }); } else { const l = o[o.length - 1]; l.high = Math.max(l.high, x.high); l.low = Math.min(l.low, x.low); l.close = x.close; } } return o; }
  const autoTf = m => m >= 10080 ? 43200 : m >= 1440 ? 10080 : m > 30 ? 1440 : m > 5 ? 240 : 60;
  const tfN = m => m >= 43200 ? 'MN' : m >= 10080 ? 'W1' : m >= 1440 ? 'D1' : m >= 60 ? 'H' + Math.floor(m / 60) : 'M' + Math.floor(m);
  const fstr = g => g >= 1 ? 'FUERTE' : g >= .5 ? 'MEDIA' : 'NORMAL';
  function rfzCalc(d, o, step, htfRaw, dayRaw) {
    o = { ...RDEF, ...(o || {}) }; const n = d.length; if (n < 10) return null;
    const T = d.map(x => x.time), Op = d.map(x => x.open), H = d.map(x => x.high), L = d.map(x => x.low), C = d.map(x => x.close);
    const m = Math.max(1, Math.round(step / 6e4)), htfTf = o.htfMode === 'Auto' ? autoTf(m) : +o.htfTf, htfOk = o.htf && htfTf > m;
    const atr = atrArr(H, L, C, Math.max(1, o.atrLen)), em = ema(C, Math.max(1, o.emaLen)), rs = rsi(C, Math.max(2, o.rsiLen));
    // FVG de la temporalidad superior (solo velas cerradas)
    const ev = [], hd = htfOk ? aggregate(htfRaw && htfRaw.length ? htfRaw : d, htfTf) : [];
    if (htfOk) { const ha = atrArr(hd.map(x => x.high), hd.map(x => x.low), hd.map(x => x.close), Math.max(1, o.atrLen));
      for (let j = 2; j < hd.length; j++) { const at = j + 1 < hd.length ? hd[j + 1].time : Infinity, a = ha[j] || 1e-12, left = hd[j - 1].time;
        if (hd[j].low > hd[j - 2].high && hd[j - 1].close > hd[j - 1].open) ev.push({ at, j, buy: true, top: hd[j].low, bot: hd[j - 2].high, g: (hd[j].low - hd[j - 2].high) / a, left });
        if (hd[j].high < hd[j - 2].low && hd[j - 1].close < hd[j - 1].open) ev.push({ at, j, buy: false, top: hd[j - 2].low, bot: hd[j].high, g: (hd[j - 2].low - hd[j].high) / a, left }); } }
    const zs = [], dead = [], pools = [], poolsDead = [], cH = [], cL = [], sigs = [], sweeps = [];
    let lsb = null, lss = null, lastSig = '—', e = 0;
    const addZone = (top, bot, typ, src, left, str) => {
      zs.push({ top, bot, typ, src, left, str, touched: false, tf: src === 1 ? tfN(htfTf) : tfN(m) });
      const bull = typ > 0, lim = src === 1 ? o.maxHtf : src === 2 ? o.maxVi : o.maxLocal; let cnt = 0;
      zs.forEach(z => { if ((z.typ > 0) === bull && z.src === src) cnt++; });
      if (cnt > lim) { const k = zs.findIndex(z => (z.typ > 0) === bull && z.src === src); zs.splice(k, 1); }
    };
    const addPool = (px, b, high) => { pools.push({ px, b, high }); if (pools.length > o.maxPools) pools.shift(); };
    // zonas HTF anteriores al primer dato: se descartan las que ya se mitigaron antes
    while (e < ev.length && ev[e].at <= T[0]) {
      const z = ev[e++]; if (!o.fvg || z.g < o.minGap) continue; let mit = false;
      for (let k = z.j + 1; k < hd.length && hd[k].time < T[0]; k++) { const x = hd[k]; if (z.buy ? (o.mit === 'Cierre' ? x.close : x.low) < z.bot : (o.mit === 'Cierre' ? x.close : x.high) > z.top) { mit = true; break; } }
      if (!mit) addZone(z.top, z.bot, z.buy ? 1 : -1, 1, z.left, fstr(z.g));
    }
    for (let i = 0; i < n - 1; i++) { // solo velas cerradas
      let bR = false, sR = false, bH = false, sH = false, swB = false, swS = false;
      for (let k = zs.length - 1; k >= 0; k--) {
        const z = zs[k], bull = z.typ > 0, mit = bull ? (o.mit === 'Cierre' ? C[i] < z.bot : L[i] < z.bot) : (o.mit === 'Cierre' ? C[i] > z.top : H[i] > z.top);
        if (mit) { zs.splice(k, 1); if (!o.hideMit) { z.end = T[i]; dead.push(z); if (dead.length > 150) dead.shift(); } }
        else if (!z.touched && (bull ? L[i] <= z.top : H[i] >= z.bot)) { z.touched = true; if (bull && C[i] > Op[i]) { bR = true; if (z.src === 1) bH = true; } if (!bull && C[i] < Op[i]) { sR = true; if (z.src === 1) sH = true; } }
      }
      for (let k = pools.length - 1; k >= 0; k--) {
        const p = pools[k]; if (!(p.high ? H[i] > p.px : L[i] < p.px)) continue;
        if (p.high && C[i] < p.px) { swS = true; lss = i; } if (!p.high && C[i] > p.px) { swB = true; lsb = i; }
        pools.splice(k, 1); p.end = i; poolsDead.push(p); if (poolsDead.length > 60) poolsDead.shift();
      }
      if (o.liq) {
        for (let k = cH.length - 1; k >= 0; k--) if (H[i] > cH[k].px) cH.splice(k, 1);
        for (let k = cL.length - 1; k >= 0; k--) if (L[i] < cL[k].px) cL.splice(k, 1);
        const pp = i - o.pivLen, tol = (atr[i] || 0) * o.eqTol;
        if (isPH(H, pp, o.pivLen)) { const ph = H[pp]; let f = -1; for (let k = cH.length - 1; k >= 0; k--) if (Math.abs(cH[k].px - ph) <= tol) { f = k; break; }
          if (f >= 0) { addPool(Math.max(cH[f].px, ph), cH[f].b, true); cH.splice(f, 1); } else { cH.push({ px: ph, b: pp }); if (cH.length > 40) cH.shift(); } }
        if (isPL(L, pp, o.pivLen)) { const pl = L[pp]; let f = -1; for (let k = cL.length - 1; k >= 0; k--) if (Math.abs(cL[k].px - pl) <= tol) { f = k; break; }
          if (f >= 0) { addPool(Math.min(cL[f].px, pl), cL[f].b, false); cL.splice(f, 1); } else { cL.push({ px: pl, b: pp }); if (cL.length > 40) cL.shift(); } }
      }
      while (e < ev.length && ev[e].at <= T[i]) { const z = ev[e++]; if (o.fvg && z.g >= o.minGap) addZone(z.top, z.bot, z.buy ? 1 : -1, 1, z.left, fstr(z.g)); }
      if (o.local && i >= 2) {
        const a = atr[i] || 0, imp = o.minBody === 0 || Math.abs(C[i - 1] - Op[i - 1]) >= a * o.minBody;
        if (o.fvg && L[i] > H[i - 2] && L[i] - H[i - 2] >= a * o.minGap && C[i - 1] > Op[i - 1] && imp) addZone(L[i], H[i - 2], 1, 0, T[i - 1], fstr((L[i] - H[i - 2]) / (a || 1e-12)));
        if (o.fvg && H[i] < L[i - 2] && L[i - 2] - H[i] >= a * o.minGap && C[i - 1] < Op[i - 1] && imp) addZone(L[i - 2], H[i], -1, 0, T[i - 1], fstr((L[i - 2] - H[i]) / (a || 1e-12)));
        const vbt = Math.min(Op[i], C[i]), vbb = Math.max(Op[i - 1], C[i - 1]); if (o.vi && vbt > vbb && L[i] <= H[i - 1] && vbt - vbb >= a * o.minGap * .5) addZone(vbt, vbb, 2, 2, T[i - 1], 'VI');
        const vst = Math.min(Op[i - 1], C[i - 1]), vsb = Math.max(Op[i], C[i]); if (o.vi && vsb < vst && H[i] >= L[i - 1] && vst - vsb >= a * o.minGap * .5) addZone(vst, vsb, -2, 2, T[i - 1], 'VI');
      }
      const r = rs[i] == null ? 50 : rs[i];
      if (o.sig && bR) { const tr = C[i] > em[i], sc = 1 + (bH ? 1 : 0) + (tr ? 1 : 0) + (r < 50 ? 1 : 0) + (lsb != null && i - lsb <= o.sweepLook ? 1 : 0);
        if (sc >= o.minScore && (!o.rsiFilter || r < o.ob) && (!o.trend || tr)) { sigs.push({ i, buy: true, sc }); lastSig = 'COMPRA ' + sc + '/5'; } }
      if (o.sig && sR) { const tr = !(C[i] > em[i]), sc = 1 + (sH ? 1 : 0) + (tr ? 1 : 0) + (r > 50 ? 1 : 0) + (lss != null && i - lss <= o.sweepLook ? 1 : 0);
        if (sc >= o.minScore && (!o.rsiFilter || r > o.os) && (!o.trend || tr)) { sigs.push({ i, buy: false, sc }); lastSig = 'VENTA ' + sc + '/5'; } }
      if (swB) sweeps.push({ i, bull: true }); if (swS) sweeps.push({ i, bull: false });
    }
    // máx/mín del día y la semana anteriores
    const src = dayRaw && dayRaw.length ? dayRaw : d, days = aggregate(src, 1440), weeks = aggregate(src, 10080);
    const prevArr = arr => { const hi = new Array(n).fill(null), lo = hi.slice(); let j = 0; for (let i = 0; i < n; i++) { while (j + 1 < arr.length && arr[j + 1].time <= T[i]) j++; if (arr[j] && arr[j].time <= T[i] && j > 0) { hi[i] = arr[j - 1].high; lo[i] = arr[j - 1].low; } } return [hi, lo]; };
    const [pdh, pdl] = prevArr(days), [pwh, pwl] = prevArr(weeks);
    const tint = o.tint ? rs.map(v => v == null ? null : v >= o.ob ? o.sell : v <= o.os ? o.buy : null) : null;
    let range = null; if (o.range) { const s = Math.max(0, n - o.rngLen); let hi = -Infinity, lo = Infinity; for (let i = s; i < n; i++) { hi = Math.max(hi, H[i]); lo = Math.min(lo, L[i]); } if (hi > lo) range = { left: s, hi, lo, sz: hi - lo }; }
    const c = C[n - 1]; let nB = 0, nS = 0, pB = null, dB = null, pS = null, dS = null, eqh = null, eql = null;
    zs.forEach(z => { if (z.typ > 0) { nB++; const k = Math.max(0, c - z.top); if (dB == null || k < dB) { dB = k; pB = z.top; } } else { nS++; const k = Math.max(0, z.bot - c); if (dS == null || k < dS) { dS = k; pS = z.bot; } } });
    pools.forEach(p => { if (p.high && p.px > c && (eqh == null || p.px < eqh)) eqh = p.px; if (!p.high && p.px < c && (eql == null || p.px > eql)) eql = p.px; });
    const info = { nB, nS, pB, dB, pS, dS, eqh, eql, rsi: rs[n - 1], up: c > em[n - 1], lastSig, chart: tfN(m), htf: tfN(htfTf), htfOk };
    return { o, zs, dead, pools, poolsDead, sigs, sweeps, tint, pdh, pdl, pwh, pwl, range, info, lastT: T[n - 2] };
  }
  function analyze(d, step) {
    if (!d || d.length < 30) return null;
    const c = d.map(x => x.close), n = c.length - 1, e20 = ema(c, 20), e50 = ema(c, 50), e200 = ema(c, 200), r = rsi(c, 14), m = macd(c, 12, 26, 9), b = bands(c, 20, 2), w = d.slice(-50);
    const back = Math.min(n, Math.max(1, Math.round(864e5 / step)));
    return { close: c[n], ema20: e20[n], ema50: e50[n], ema200: e200[n], rsi14: r[n], macd: m.m[n], macdSignal: m.sg[n], bbUpper: b.U[n], bbLower: b.D[n], swingHigh50: Math.max(...w.map(x => x.high)), swingLow50: Math.min(...w.map(x => x.low)), ...(() => { const w2 = d.slice(-200), vp = volumeProfile(w2, 0, w2.length - 1, Math.min(...w2.map(x => x.low)), Math.max(...w2.map(x => x.high)), 40), dv = divergences(d, rsi(c, 14)).filter(x => x.b >= n - 30).slice(-1)[0]; return { poc200: vp ? vp.pocPrice : null, vah200: vp ? vp.vah : null, val200: vp ? vp.val : null, divergenciaReciente: dv ? (dv.type === 'bull' ? 'alcista' : 'bajista') + ' hace ' + (n - dv.b) + ' velas' : 'ninguna' }; })(), ...(() => { const R = rfzCalc(d, { tags: false }, step), r = v => v == null ? null : +v.toFixed(3); if (!R) return {}; return { zonasCompra: R.zs.filter(x => x.typ > 0).map(x => [r(x.bot), r(x.top), x.tf, x.src === 2 ? 'VI' : 'FVG', x.str]), zonasVenta: R.zs.filter(x => x.typ < 0).map(x => [r(x.bot), r(x.top), x.tf, x.src === 2 ? 'VI' : 'FVG', x.str]), liquidezArriba: r(R.info.eqh), liquidezAbajo: r(R.info.eql), ultimaSenal: R.info.lastSig, rangoPremium: R.range ? [r(R.range.hi - R.range.sz * .25), r(R.range.hi)] : null, rangoDescuento: R.range ? [r(R.range.lo), r(R.range.lo + R.range.sz * .25)] : null }; })(), change24hPct: (c[n] / c[n - back] - 1) * 100, pivots: Object.fromEntries(pivots(d, step)) };
  }

  const FIB = [0, .236, .382, .5, .618, .786, 1];

  function FortunaChart(wrap) {
    const cv = document.createElement('canvas'); cv.setAttribute('aria-label', 'Gráfico de precios interactivo'); wrap.appendChild(cv);
    const ctx = cv.getContext('2d');
    const S = { data: [], src: [], step: 36e5, digits: 2, type: 'candles', right: 0, barW: 8, auto: true, lo: 0, hi: 1, tool: 'cursor', magnet: false, sel: null, drawings: [], cross: null, measure: null };
    const ind = { ema: { on: false, p: [20, 50, 200] }, bb: { on: false, p: 20, k: 2 }, piv: { on: false }, rsi: { on: false, p: 14 }, macd: { on: false, f: 12, s: 26, g: 9 }, zones: { on: false, ...RDEF }, vp: { on: false, bins: 40 }, div: { on: false }, dxy: { on: false, ema: 50, corr: 50, table: true, alert: false, up: '#26A69A', dn: '#EF5350', emaCol: '#D4AF37', ...ZDEF } };
    S.ext = {};
    let C = {}, K = {}, lay = { W: 0, H: 0, PW: 0, AX: 60, TB: 24, mainH: 0, subH: 0, subs: [] }, raf = 0;
    const cbs = { change: () => {}, cross: () => {}, select: () => {}, tool: () => {} };

    function colors() {
      const p = document.createElement('span'); document.body.appendChild(p);
      const g = v => { p.style.color = `var(${v})`; return getComputedStyle(p).color; };
      C = { ink: g('--ink'), mute: g('--mute'), line: g('--line'), up: g('--up'), dn: g('--dn'), gold: g('--gold'), blue: g('--sky'), bg: g('--surface'), violet: g('--violet'), coral: g('--coral') };
      p.remove();
    }
    function compute() {
      const c = S.data.map(d => d.close);
      K.ema = ind.ema.p.map(n => ema(c, n));
      K.bb = bands(c, ind.bb.p, ind.bb.k);
      K.rsi = rsi(c, ind.rsi.p);
      K.macd = macd(c, ind.macd.f, ind.macd.s, ind.macd.g);
      K.piv = pivots(S.data, S.step);
      const T = S.data.map(d => d.time), ex = S.ext || {};
      K.rf = ind.zones.on ? rfzCalc(S.data, { ...ind.zones, ...ZONLY }, S.step, ex.htf, ex.day) : null;
      K.dx = null;
      if (ind.dxy.on && ex.dxy && ex.dxy.length && S.data.length) {
        const o = { ...ZDEF, ...ind.dxy }, A = alignTo(S.data, ex.dxy), prevD = new Array(T.length).fill(null); let pd = null, lastC = null, day = null;
        for (let i = 0; i < T.length; i++) { if (S.step >= 864e5) { prevD[i] = i ? A.C[i - 1] : null; continue; } const dd = Math.floor(T[i] / 864e5); if (day !== null && dd !== day) pd = lastC; day = dd; if (A.C[i] != null) lastC = A.C[i]; prevD[i] = pd; }
        K.dx = { ...A, ema: emaN(A.C, Math.max(2, o.ema)), prevD, z: pineZones(T, A.O, A.H, A.L, A.C, o, o.htf && o.htfTf * 6e4 >= S.step ? htfEvents(ex.dxyHtf && ex.dxyHtf.length ? ex.dxyHtf : aggregate(ex.dxy, o.htfTf), o.hlen, o.minAtr, o.htfTf * 6e4) : null) };
      }
      K.div = divergences(S.data, rsi(c, ind.rsi.p || 14));
      S.src = S.type === 'heikin' ? heikin(S.data) : S.data;
    }

    // ---------- coordenadas ----------
    const X = i => lay.PW - (S.right - i) * S.barW;
    const I = x => S.right - (lay.PW - x) / S.barW;
    const Y = p => 6 + (S.hi - p) / (S.hi - S.lo) * (lay.mainH - 12);
    const P = y => S.hi - (y - 6) / (lay.mainH - 12) * (S.hi - S.lo);
    function tAt(i) {
      const d = S.data, n = d.length - 1; if (!d.length) return 0;
      if (i <= 0) return d[0].time + i * S.step;
      if (i >= n) return d[n].time + (i - n) * S.step;
      const a = Math.floor(i), f = i - a; return d[a].time + (d[a + 1].time - d[a].time) * f;
    }
    function iAt(t) {
      const d = S.data, n = d.length - 1; if (!d.length) return 0;
      if (t <= d[0].time) return (t - d[0].time) / S.step;
      if (t >= d[n].time) return n + (t - d[n].time) / S.step;
      let lo = 0, hi = n; while (hi - lo > 1) { const m = (lo + hi) >> 1; d[m].time <= t ? lo = m : hi = m; }
      return lo + (t - d[lo].time) / (d[hi].time - d[lo].time);
    }
    const fmtP = v => v == null || !isFinite(v) ? '' : Number(v).toFixed(S.digits);
    function niceStep(r) { const p = 10 ** Math.floor(Math.log10(r)), m = r / p; return (m < 1.5 ? 1 : m < 3 ? 2 : m < 7 ? 5 : 10) * p; }
    const tf = new Intl.DateTimeFormat('es-ES', { hour: '2-digit', minute: '2-digit' }), df = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short' }), ff = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

    function clampView() {
      const n = S.data.length; if (!n) return;
      S.barW = Math.max(1.5, Math.min(60, S.barW));
      const vis = lay.PW / S.barW; S.right = Math.max(Math.min(vis * .3, n - 1), Math.min(S.right, n - 1 + vis * .7));
    }
    function autoRange() {
      const a = Math.max(0, Math.floor(I(0))), b = Math.min(S.src.length - 1, Math.ceil(I(lay.PW)));
      let hi = -Infinity, lo = Infinity;
      for (let i = a; i <= b; i++) { hi = Math.max(hi, S.src[i].high); lo = Math.min(lo, S.src[i].low); if (ind.bb.on && K.bb.U[i] != null) { hi = Math.max(hi, K.bb.U[i]); lo = Math.min(lo, K.bb.D[i]); } }
      if (!isFinite(hi)) return; const pad = (hi - lo) * .08 || hi * .001; S.hi = hi + pad; S.lo = lo - pad;
    }
    const req = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; draw(); }); };

    // ---------- dibujo ----------
    function draw() {
      if (!C.ink) colors();
      const W = wrap.clientWidth, H = wrap.clientHeight, dpr = window.devicePixelRatio || 1; if (!W || !H) return;
      if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); cv.style.width = W + 'px'; cv.style.height = H + 'px'; }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
      const subs = H < 250 ? [] : [ind.dxy.on && 'dxy', ind.rsi.on && 'rsi', ind.macd.on && 'macd'].filter(Boolean).slice(0, H < 380 ? 1 : H < 600 ? 2 : 3);
      lay = { W, H, AX: W < 520 ? 58 : 66, TB: 24, subs }; lay.PW = W - lay.AX; lay.subH = subs.length ? Math.round(H * (subs.length > 2 ? .14 : subs.length > 1 ? .16 : .2)) : 0; lay.hs = subs.map(s => s === 'dxy' ? Math.round(lay.subH * (subs.length > 1 ? 1.5 : 1.45)) : lay.subH); lay.mainH = H - lay.TB - lay.hs.reduce((x, y) => x + y, 0);
      if (!S.data.length) return;
      clampView(); if (S.auto) autoRange();
      const { PW, AX, TB, mainH } = lay, a = Math.max(0, Math.floor(I(0)) - 1), b = Math.min(S.src.length - 1, Math.ceil(I(PW)) + 1);
      ctx.font = '11px Outfit, system-ui, sans-serif'; ctx.textBaseline = 'middle'; ctx.lineWidth = 1;
      // rejilla horizontal + escala de precios
      const st = niceStep((S.hi - S.lo) / Math.max(3, Math.round(mainH / 60)));
      ctx.strokeStyle = C.line; ctx.fillStyle = C.mute; ctx.textAlign = 'left';
      for (let v = Math.ceil(S.lo / st) * st; v <= S.hi; v += st) { const y = Math.round(Y(v)) + .5; ctx.globalAlpha = .55; ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(PW, y); ctx.stroke(); ctx.globalAlpha = 1; ctx.fillText(fmtP(v), PW + 7, y); }
      // rejilla vertical + tiempos
      const every = Math.max(1, Math.ceil(84 / S.barW)); ctx.textAlign = 'center';
      for (let i = Math.floor(b / every) * every; i >= a; i -= every) {
        const x = Math.round(X(i)) + .5; if (x < 20 || x > PW - 20 || !S.data[i]) continue;
        ctx.globalAlpha = .35; ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H - TB); ctx.stroke(); ctx.globalAlpha = 1;
        const t = S.data[i].time, prev = S.data[i - every]; const newDay = !prev || Math.floor(prev.time / 864e5) !== Math.floor(t / 864e5);
        ctx.fillText(S.step >= 864e5 || newDay ? df.format(t) : tf.format(t), x, H - TB / 2);
      }
      ctx.save(); ctx.beginPath(); ctx.rect(0, 0, PW, mainH); ctx.clip();
      // Bollinger
      if (ind.bb.on) {
        ctx.fillStyle = C.blue; ctx.globalAlpha = .07; ctx.beginPath(); let f = true;
        for (let i = a; i <= b; i++) if (K.bb.U[i] != null) { f ? ctx.moveTo(X(i), Y(K.bb.U[i])) : ctx.lineTo(X(i), Y(K.bb.U[i])); f = false; }
        for (let i = b; i >= a; i--) if (K.bb.D[i] != null) ctx.lineTo(X(i), Y(K.bb.D[i]));
        ctx.fill(); ctx.globalAlpha = 1; line(K.bb.U, C.blue, 1, a, b, Y); line(K.bb.D, C.blue, 1, a, b, Y); line(K.bb.M, C.blue, 1, a, b, Y, [4, 4]);
      }
      if (ind.vp.on) {
        const vp = volumeProfile(S.data, a, b, S.lo, S.hi, ind.vp.bins || 40);
        if (vp) {
          const mx = Math.max(...vp.v), maxW = PW * .3;
          vp.v.forEach((x, k) => { if (!x) return; const y1 = Y(vp.lo + (k + 1) * vp.h), y2 = Y(vp.lo + k * vp.h), w = x / mx * maxW, inVA = k >= vp.va[0] && k <= vp.va[1];
            ctx.fillStyle = k === vp.poc ? C.gold : inVA ? C.gold : C.mute; ctx.globalAlpha = k === vp.poc ? .55 : inVA ? .26 : .14; ctx.fillRect(PW - w, y1 + .5, w, Math.max(1, y2 - y1 - 1)); });
          ctx.globalAlpha = 1; ctx.strokeStyle = C.gold; ctx.setLineDash([6, 4]); const yp = Y(vp.pocPrice); ctx.beginPath(); ctx.moveTo(0, yp); ctx.lineTo(PW, yp); ctx.stroke(); ctx.setLineDash([]);
          ctx.fillStyle = C.gold; ctx.textAlign = 'right'; ctx.font = '600 11px Outfit, system-ui, sans-serif'; ctx.fillText('POC ' + fmtP(vp.pocPrice) + (vp.real ? '' : ' · por tiempo'), PW - 6, yp - 8);
          ctx.globalAlpha = .6; ctx.font = '11px Outfit, system-ui, sans-serif'; ctx.fillText('VAH', PW - 6, Y(vp.vah) - 7); ctx.fillText('VAL', PW - 6, Y(vp.val) + 9); ctx.globalAlpha = 1;
        }
      }
      if (ind.zones.on && K.rf) drawRfz(K.rf, a, b);
      series(a, b);
      if (ind.ema.on) { const cs = [C.gold, C.blue, C.violet]; K.ema.forEach((e, k) => line(e, cs[k], 1.5, a, b, Y)); }
      if (ind.div.on && K.div) K.div.forEach(v => {
        if (v.b < a - 80 || v.a > b) return; const bull = v.type === 'bull', col = bull ? C.up : C.dn, off = bull ? 10 : -10;
        ctx.strokeStyle = col; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(X(v.a), Y(v.pa) + off); ctx.lineTo(X(v.b), Y(v.pb) + off); ctx.stroke(); ctx.lineWidth = 1;
        [v.a, v.b].forEach((i, k) => { ctx.beginPath(); ctx.arc(X(i), Y(k ? v.pb : v.pa) + off, 3, 0, 7); ctx.fillStyle = col; ctx.fill(); });
        ctx.font = '600 11px Outfit, system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = col; ctx.fillText(bull ? '▲ Div. alcista' : '▼ Div. bajista', X(v.b), Y(v.pb) + off + (bull ? 14 : -14)); ctx.font = '11px Outfit, system-ui, sans-serif';
      });
      if (ind.piv.on) K.piv.forEach(([k, v]) => { const y = Y(v); ctx.strokeStyle = k === 'P' ? C.mute : k[0] === 'R' ? C.dn : C.up; ctx.setLineDash([2, 4]); ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(PW, y); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = ctx.strokeStyle; ctx.textAlign = 'left'; ctx.fillText(k, 6, y - 8); });
      drawings();
      if (S.measure) measure();
      if (ind.zones.on && K.rf) { rfzTags(K.rf); rfzPanel(K.rf); }
      ctx.restore();
      // último precio + cuenta atrás
      const last = S.data[S.data.length - 1], up = last.close >= last.open, ly = Y(last.close);
      if (ly > 0 && ly < mainH) {
        ctx.strokeStyle = up ? C.up : C.dn; ctx.setLineDash([1, 3]); ctx.beginPath(); ctx.moveTo(0, ly); ctx.lineTo(PW, ly); ctx.stroke(); ctx.setLineDash([]);
        const left = last.time + S.step - Date.now(), cd = left > 0 ? (left >= 36e5 ? `${Math.floor(left / 36e5)}:` : '') + new Date(left).toISOString().slice(left >= 36e5 ? 14 : 14, 19) : '';
        tag(fmtP(last.close), ly, up ? C.up : C.dn, '#fff', cd);
      }
      S.drawings.forEach(d => { if (d.type === 'hline') tag(fmtP(d.p[0].price), Y(d.p[0].price), d.color, '#111'); });
      { let tp = mainH; subs.forEach((s, k) => { sub(s, tp, lay.hs[k], a, b); tp += lay.hs[k]; }); }
      // cruz
      if (S.cross) {
        const { x, y } = S.cross, i = Math.round(I(x)), cx = S.data[i] ? X(i) : x;
        ctx.strokeStyle = C.mute; ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.moveTo(cx, 0); ctx.lineTo(cx, H - TB); ctx.stroke();
        if (y < mainH) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(PW, y); ctx.stroke(); ctx.setLineDash([]); tag(fmtP(P(y)), y, C.ink, C.bg); }
        ctx.setLineDash([]);
        const t = tAt(i), txt = S.step >= 864e5 ? df.format(t) : ff.format(t); ctx.font = '11px Outfit, system-ui, sans-serif'; const tw = ctx.measureText(txt).width + 14;
        ctx.fillStyle = C.ink; roundRect(Math.min(PW - tw, Math.max(0, cx - tw / 2)), H - TB + 2, tw, TB - 4, 5); ctx.fill(); ctx.fillStyle = C.bg; ctx.textAlign = 'center'; ctx.fillText(txt, Math.min(PW - tw / 2, Math.max(tw / 2, cx)), H - TB / 2);
        cbs.cross(S.data[i] ? i : null);
      }
    }
    function series(a, b) {
      const src = S.src, bw = Math.max(1, S.barW * .7);
      if (S.type === 'line' || S.type === 'area') {
        ctx.beginPath(); for (let i = a; i <= b; i++) { const x = X(i), y = Y(src[i].close); i === a ? ctx.moveTo(x, y) : ctx.lineTo(x, y); }
        if (S.type === 'area') { ctx.save(); ctx.lineTo(X(b), lay.mainH); ctx.lineTo(X(a), lay.mainH); ctx.closePath(); const g = ctx.createLinearGradient(0, 0, 0, lay.mainH); g.addColorStop(0, C.gold.replace('rgb(', 'rgba(').replace(')', ',.35)')); g.addColorStop(1, C.gold.replace('rgb(', 'rgba(').replace(')', ',0)')); ctx.fillStyle = g; ctx.fill(); ctx.restore(); ctx.beginPath(); for (let i = a; i <= b; i++) { const x = X(i), y = Y(src[i].close); i === a ? ctx.moveTo(x, y) : ctx.lineTo(x, y); } }
        ctx.strokeStyle = C.gold; ctx.lineWidth = 2; ctx.stroke(); ctx.lineWidth = 1; return;
      }
      for (let i = a; i <= b; i++) {
        const d = src[i], x = Math.round(X(i)) + .5, up = d.close >= d.open, tc = ind.zones.on && K.rf && K.rf.tint && K.rf.tint[i]; ctx.strokeStyle = ctx.fillStyle = tc || (up ? C.up : C.dn);
        if (S.type === 'bars') { const t = Math.max(2, bw / 2); ctx.beginPath(); ctx.moveTo(x, Y(d.high)); ctx.lineTo(x, Y(d.low)); ctx.moveTo(x - t, Y(d.open)); ctx.lineTo(x, Y(d.open)); ctx.moveTo(x, Y(d.close)); ctx.lineTo(x + t, Y(d.close)); ctx.stroke(); continue; }
        ctx.beginPath(); ctx.moveTo(x, Y(d.high)); ctx.lineTo(x, Y(d.low)); ctx.stroke();
        const y1 = Y(Math.max(d.open, d.close)), y2 = Y(Math.min(d.open, d.close)); ctx.fillRect(Math.round(x - bw / 2), y1, Math.max(1, Math.round(bw)), Math.max(1, y2 - y1));
      }
    }
    function line(arr, color, w, a, b, Yf, dash) { ctx.strokeStyle = color; ctx.lineWidth = w; ctx.setLineDash(dash || []); ctx.beginPath(); let f = true; for (let i = a; i <= b; i++) { if (arr[i] == null) continue; f ? ctx.moveTo(X(i), Yf(arr[i])) : ctx.lineTo(X(i), Yf(arr[i])); f = false; } ctx.stroke(); ctx.setLineDash([]); ctx.lineWidth = 1; }
    function roundRect(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    function tag(text, y, bg, fg, extra) {
      if (y < 0 || y > lay.mainH) return; const h = extra ? 32 : 20; ctx.fillStyle = bg; roundRect(lay.PW + 2, y - 10, lay.AX - 4, h, 5); ctx.fill();
      ctx.fillStyle = fg; ctx.textAlign = 'left'; ctx.font = '600 11px Outfit, system-ui, sans-serif'; ctx.fillText(text, lay.PW + 7, y); ctx.font = '11px Outfit, system-ui, sans-serif';
      if (extra) { ctx.globalAlpha = .85; ctx.fillText(extra, lay.PW + 7, y + 13); ctx.globalAlpha = 1; }
    }
    // ---------- Radiant Fortune Zones: dibujo ----------
    const hexA = (h, a) => { h = String(h || '#888').replace('#', ''); if (h.length === 3) h = h.split('').map(x => x + x).join(''); const v = parseInt(h.slice(0, 6), 16); return `rgba(${v >> 16 & 255},${v >> 8 & 255},${v & 255},${Math.max(0, Math.min(1, a))})`; };
    function box(x0, x1, yt, yb, fill, stroke, w, dash) {
      if (x1 < 0 || x0 > lay.PW) return; const y1 = Math.min(yt, yb), hh = Math.max(1, Math.abs(yb - yt));
      ctx.fillStyle = fill; ctx.fillRect(x0, y1, x1 - x0, hh);
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = w || 1; ctx.setLineDash(dash || []); ctx.strokeRect(x0 + .5, y1 + .5, x1 - x0, hh); ctx.setLineDash([]); ctx.lineWidth = 1; }
    }
    function hseg(x0, x1, y, col, w, dash) { if (x1 < 0 || x0 > lay.PW) return; ctx.strokeStyle = col; ctx.lineWidth = w || 1; ctx.setLineDash(dash || []); ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke(); ctx.setLineDash([]); ctx.lineWidth = 1; }
    function stepLine(arr, col, w, a, b) {
      ctx.strokeStyle = col; ctx.lineWidth = w; ctx.beginPath(); let prev = null;
      for (let i = a; i <= b; i++) { const v = arr[i]; if (v == null) { prev = null; continue; } const x = X(i), y = Y(v); if (prev !== v) ctx.moveTo(x - S.barW / 2, y); ctx.lineTo(x + S.barW / 2, y); prev = v; }
      ctx.stroke(); ctx.lineWidth = 1;
    }
    function pill(x, y, text, bg, fg, font, alignRight) {
      ctx.font = font || '600 10px Outfit, system-ui, sans-serif'; const w = ctx.measureText(text).width + 10; let x0 = alignRight ? x - w : x;
      ctx.fillStyle = bg; roundRect(x0, y - 8, w, 16, 4); ctx.fill(); ctx.fillStyle = fg; ctx.textAlign = 'left'; ctx.fillText(text, x0 + 5, y + .5); return w;
    }
    function drawRfz(R, a, b) {
      const o = R.o, n = S.data.length, PW = lay.PW, right = PW;
      if (o.range && R.range) { const g = R.range, x0 = X(g.left) - S.barW / 2, x1 = X(n - 1 + 10), k = g.sz * o.rngPct / 100;
        box(x0, x1, Y(g.hi), Y(g.hi - k), hexA(o.sell, .12), hexA(o.sell, .6), 1, [5, 4]); box(x0, x1, Y(g.lo + k), Y(g.lo), hexA(o.buy, .12), hexA(o.buy, .6), 1, [5, 4]); }
      R.dead.forEach(z => { const col = z.typ > 0 ? o.buy : o.sell, x0 = X(iAt(z.left)), x1 = X(iAt(z.end)); box(x0, x1, Y(z.top), Y(z.bot), hexA(col, .07), hexA(col, .3), 1, [4, 3]); if (o.mid) hseg(x0, x1, Y((z.top + z.bot) / 2), hexA(col, .15), 1, [1, 3]); });
      R.zs.forEach(z => {
        const isH = z.src === 1, isVi = Math.abs(z.typ) === 2, col = z.typ > 0 ? o.buy : o.sell;
        let fT = Math.max(0, Math.min(100, o.fill - (isH ? 6 : 0) + (isVi ? 5 : 0) - (z.str === 'FUERTE' ? 4 : 0))); if (z.touched) fT = Math.min(100, o.fill + 15);
        const x0 = Math.max(-2, X(iAt(z.left)));
        box(x0, right, Y(z.top), Y(z.bot), hexA(col, (100 - fT) / 100), hexA(col, (100 - o.border) / 100), isH ? o.bw + 1 : o.bw, isVi ? [5, 4] : null);
        if (o.mid) hseg(x0, right, Y((z.top + z.bot) / 2), hexA(col, .5), 1, [1, 3]);
      });
      R.poolsDead.forEach(p => hseg(X(p.b), X(p.end), Y(p.px), hexA('#868993', .5), 1, [1, 3]));
      R.pools.forEach(p => hseg(X(p.b), right, Y(p.px), o.liqC, 1, [5, 4]));
      if (o.pd) { stepLine(R.pdh, hexA(o.liqC, .65), 1, a, b); stepLine(R.pdl, hexA(o.liqC, .65), 1, a, b); }
      if (o.pw) { stepLine(R.pwh, hexA(o.liqC, .4), 2, a, b); stepLine(R.pwl, hexA(o.liqC, .4), 2, a, b); }
      R.sweeps.forEach(s => { if (s.i < a || s.i > b) return; const d = S.data[s.i], x = X(s.i), y = s.bull ? Y(d.low) + 9 : Y(d.high) - 9, t = 4.5; ctx.fillStyle = o.liqC; ctx.beginPath(); if (s.bull) { ctx.moveTo(x, y - t); ctx.lineTo(x - t, y + t); ctx.lineTo(x + t, y + t); } else { ctx.moveTo(x, y + t); ctx.lineTo(x - t, y - t); ctx.lineTo(x + t, y - t); } ctx.fill(); });
      R.sigs.forEach(s => { if (s.i < a || s.i > b) return; const d = S.data[s.i], x = X(s.i), txt = (s.buy ? 'COMPRA  ' : 'VENTA  ') + s.sc + '/5', col = s.buy ? o.buy : o.sell;
        ctx.font = '700 10px Outfit, system-ui, sans-serif'; const w = ctx.measureText(txt).width + 10, y = s.buy ? Y(d.low) + 24 : Y(d.high) - 24;
        ctx.fillStyle = col; ctx.beginPath(); if (s.buy) { ctx.moveTo(x, y - 14); ctx.lineTo(x - 5, y - 8); ctx.lineTo(x + 5, y - 8); } else { ctx.moveTo(x, y + 14); ctx.lineTo(x - 5, y + 8); ctx.lineTo(x + 5, y + 8); } ctx.fill();
        roundRect(x - w / 2, y - 8, w, 16, 4); ctx.fill(); ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.fillText(txt, x, y + .5); });
      ctx.font = '11px Outfit, system-ui, sans-serif';
    }
    function rfzTags(R) {
      const o = R.o; if (!o.tags) return; const n = S.data.length, items = [], f = v => fmtP(v);
      R.zs.forEach(z => { const col = z.typ > 0 ? o.buy : o.sell; items.push({ p: (z.top + z.bot) / 2, t: (z.typ > 0 ? 'ZONA DE COMPRA ' : 'ZONA DE VENTA ') + z.tf + ' · ' + z.str + (z.touched ? ' · TESTEADA' : ''), bg: hexA(col, .9), fg: '#fff', big: z.src === 1 }); });
      R.pools.forEach(p => items.push({ p: p.px, t: (p.high ? 'LIQUIDEZ ↑ ' : 'LIQUIDEZ ↓ ') + f(p.px), bg: o.liqC, fg: '#131722' }));
      const L = R.pdh.length - 1;
      if (o.pd && R.pdh[L] != null) { items.push({ p: R.pdh[L], t: 'PDH ' + f(R.pdh[L]), bg: hexA(o.liqC, .2), fg: o.liqC }); items.push({ p: R.pdl[L], t: 'PDL ' + f(R.pdl[L]), bg: hexA(o.liqC, .2), fg: o.liqC }); }
      if (o.pw && R.pwh[L] != null) { items.push({ p: R.pwh[L], t: 'PWH ' + f(R.pwh[L]), bg: hexA(o.liqC, .2), fg: o.liqC }); items.push({ p: R.pwl[L], t: 'PWL ' + f(R.pwl[L]), bg: hexA(o.liqC, .2), fg: o.liqC }); }
      if (o.range && R.range) { const g = R.range; items.push({ p: g.hi - g.sz * o.rngPct / 200, t: 'VENTA · PREMIUM (rango)', bg: hexA(o.sell, .65), fg: '#fff' }); items.push({ p: g.lo + g.sz * o.rngPct / 200, t: 'COMPRA · DESCUENTO (rango)', bg: hexA(o.buy, .65), fg: '#fff' }); }
      const vis = items.map(it => ({ ...it, y: Y(it.p) })).filter(it => it.y > 8 && it.y < lay.mainH - 8).sort((p, q) => p.y - q.y);
      for (let k = 1; k < vis.length; k++) if (vis[k].y - vis[k - 1].y < 17) vis[k].y = vis[k - 1].y + 17;
      const x = X(n - 1 + 3);
      vis.forEach(it => { ctx.font = (it.big ? '700 ' : '600 ') + '10px Outfit, system-ui, sans-serif'; const w = ctx.measureText(it.t).width + 10, x0 = Math.min(x, lay.PW - w - 3); pill(x0, it.y, it.t, it.bg, it.fg, ctx.font); });
      ctx.font = '11px Outfit, system-ui, sans-serif';
    }
    function table(rows, corner, fs, top, h) {
      // rows: [[izq, der, colorDer, fondoDer?]]; la primera fila es la cabecera
      ctx.font = `${fs}px Outfit, system-ui, sans-serif`; const rh = fs + 6, pad = 6;
      const w0 = Math.max(...rows.map(r => ctx.measureText(r[0]).width)), w1 = Math.max(...rows.map(r => ctx.measureText(r[1] || '').width)), W = Math.min(lay.PW - 8, w0 + w1 + pad * 4), Ht = rows.length * rh;
      const x = corner.includes('derecha') ? lay.PW - W - 6 : 6, y = corner.includes('Abajo') ? top + h - Ht - 6 : top + 6;
      ctx.fillStyle = 'rgba(11,14,20,.9)'; roundRect(x, y, W, Ht, 6); ctx.fill(); ctx.strokeStyle = 'rgba(212,175,55,.45)'; ctx.stroke();
      rows.forEach((r, k) => { const yy = y + k * rh + rh / 2;
        if (r[3]) { ctx.fillStyle = r[3]; ctx.fillRect(k ? x + pad * 2 + w0 : x + 1, yy - rh / 2 + 1, k ? W - w0 - pad * 2 - 1 : W - 2, rh - 2); }
        ctx.textAlign = 'left'; ctx.fillStyle = k ? '#868993' : (r[2] || '#d1d4dc'); ctx.font = `${k ? '' : '700 '}${fs}px Outfit, system-ui, sans-serif`; ctx.fillText(r[0], x + pad, yy);
        if (r[1]) { ctx.fillStyle = r[2] || '#d1d4dc'; ctx.font = `600 ${fs}px Outfit, system-ui, sans-serif`; ctx.fillText(r[1], x + pad * 3 + w0, yy); } });
      ctx.font = '11px Outfit, system-ui, sans-serif';
    }
    function rfzPanel(R) {
      const o = R.o, I2 = R.info, f = v => fmtP(v); if (!o.panel) return;
      const rv = I2.rsi == null ? 50 : I2.rsi, filled = Math.round(rv / 10), gauge = Array.from({ length: 10 }, (_, g) => g < filled ? '▮' : '▯').join('');
      const st = rv >= o.ob ? 'SOBRECOMPRA' : rv <= o.os ? 'SOBREVENTA' : 'NEUTRAL', sc = rv >= o.ob ? o.sell : rv <= o.os ? o.buy : '#d1d4dc';
      const fs = o.size === 'Grande' ? 13 : o.size === 'Normal' ? 11 : 10;
      table([
        ['Radiant Fortune Zones', '', o.liqC],
        ['Activo', (S.ext && S.ext.sym) || '', '#d1d4dc'],
        ['Temporalidad', I2.chart + (I2.htfOk ? '  →  zonas ' + I2.htf : '  (HTF desactivada)'), '#d1d4dc'],
        [`Sesgo (EMA ${o.emaLen})`, I2.up ? 'ALCISTA ▲' : 'BAJISTA ▼', I2.up ? o.buy : o.sell],
        [`RSI (${o.rsiLen})`, rv.toFixed(1) + '  ' + gauge, sc],
        ['Estado RSI', st, sc],
        ['Zonas compra / venta', I2.nB + '  /  ' + I2.nS, '#d1d4dc'],
        ['Zona de compra cercana', I2.pB == null ? '—' : f(I2.pB) + (I2.dB === 0 ? '  · EN ZONA' : '  (−' + I2.dB.toFixed(2) + ')'), o.buy],
        ['Zona de venta cercana', I2.pS == null ? '—' : f(I2.pS) + (I2.dS === 0 ? '  · EN ZONA' : '  (+' + I2.dS.toFixed(2) + ')'), o.sell],
        ['Liquidez ↑ / ↓', (I2.eqh == null ? '—' : f(I2.eqh)) + '  /  ' + (I2.eql == null ? '—' : f(I2.eql)), o.liqC],
        ['Última señal', I2.lastSig, I2.lastSig.startsWith('COMPRA') ? o.buy : I2.lastSig.startsWith('VENTA') ? o.sell : '#d1d4dc'],
      ], o.pos, fs, o.pos.includes('Arriba') ? 58 : 0, lay.mainH - (o.pos.includes('Arriba') ? 58 : 0));
    }
    // ---------- Panel DXY ----------
    function subDxy(top, h, a, b) {
      const D = K.dx, o = ind.dxy, ci = S.cross ? Math.max(0, Math.min(S.data.length - 1, Math.round(I(S.cross.x)))) : S.data.length - 1;
      ctx.fillStyle = C.mute; ctx.textAlign = 'left';
      if (!D) { ctx.fillText('DXY · cargando datos…', 8, top + 12); return; }
      let hi = -Infinity, lo = Infinity; for (let i = a; i <= b; i++) { if (D.H[i] == null) continue; hi = Math.max(hi, D.H[i]); lo = Math.min(lo, D.L[i]);  }
      if (!isFinite(hi)) { ctx.fillText('DXY · sin datos en esta zona', 8, top + 12); return; }
      const pad = (hi - lo) * .08 || hi * .0005; hi += pad; lo -= pad;
      const y = v => top + 18 + (hi - v) / (hi - lo) * (h - 24), n = S.data.length, tag2 = tfName(Math.round(S.step / 6e4));
      ctx.save(); ctx.beginPath(); ctx.rect(0, top, lay.PW, h); ctx.clip();
      const zb = (z, live) => { const col = z.buy ? o.buy : o.sell, x0 = X(iAt(z.left)), x1 = live ? X(n - 1 + o.ext) : X(iAt(z.end)), y1 = y(z.top), y2 = y(z.bot);
        if (!live) { box(x0, x1, y1, y2, 'rgba(128,128,128,.08)', 'rgba(128,128,128,.25)', 1); return; }
        box(x0, x1, y1, y2, hexA(col, z.htf ? .22 : .12), hexA(col, .85), z.htf ? 2 : 1, z.htf ? null : [5, 4]);
        if (Math.abs(y2 - y1) >= 9) { ctx.font = '600 9px Outfit, system-ui, sans-serif'; ctx.fillStyle = col; ctx.textAlign = 'right'; ctx.fillText((z.buy ? 'ZONA DE COMPRAS' : 'ZONA DE VENTAS') + '  ·  ' + (z.htf ? tfName(o.htfTf) : tag2), Math.min(x1, lay.PW) - 4, (y1 + y2) / 2); ctx.font = '11px Outfit, system-ui, sans-serif'; } };
      D.z.broken.forEach(z => zb(z, false)); D.z.live.forEach(z => zb(z, true));
      const bw = Math.max(1, S.barW * .7);
      for (let i = a; i <= b; i++) { if (D.C[i] == null) continue; const x = Math.round(X(i)) + .5, col = D.C[i] >= D.O[i] ? o.up : o.dn; ctx.strokeStyle = ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(x, y(D.H[i])); ctx.lineTo(x, y(D.L[i])); ctx.stroke(); const y1 = y(Math.max(D.O[i], D.C[i])), y2 = y(Math.min(D.O[i], D.C[i])); ctx.fillRect(Math.round(x - bw / 2), y1, Math.max(1, Math.round(bw)), Math.max(1, y2 - y1)); }
      ctx.restore();
      // escala
      ctx.fillStyle = C.mute; ctx.textAlign = 'left'; ctx.font = '10px Outfit, system-ui, sans-serif';
      const st = niceStep((hi - lo) / Math.max(2, Math.round(h / 45))); for (let v = Math.ceil(lo / st) * st; v <= hi; v += st) { const yy = y(v); if (yy > top + 10 && yy < top + h - 4) ctx.fillText(v.toFixed(2), lay.PW + 7, yy); }
      const lc = D.C[n - 1]; if (lc != null) { const yy = y(lc); if (yy > top && yy < top + h) { ctx.fillStyle = lc >= D.O[n - 1] ? o.up : o.dn; roundRect(lay.PW + 2, yy - 9, lay.AX - 4, 18, 5); ctx.fill(); ctx.fillStyle = '#fff'; ctx.font = '600 10px Outfit, system-ui, sans-serif'; ctx.fillText(lc.toFixed(3), lay.PW + 6, yy); } }
      ctx.font = '11px Outfit, system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.fillStyle = C.mute; ctx.fillText('DXY · zonas de compras y ventas', 8, top + 10);
      if (false && o.table && D.C[ci] != null) {
        const dC = D.C[ci], pd = D.prevD[ci], ch = pd ? (dC - pd) / pd * 100 : null, up = D.ema[ci] != null && dC > D.ema[ci], cr = corrAt(S.data.map(x => x.close), D.C, ci, o.corr);
        const bias = cr != null && cr < -0.3 ? (up ? 'VENTAS ▼' : 'COMPRAS ▲') : 'NEUTRAL', bc = cr != null && cr < -0.3 ? (up ? '#FF1744' : '#00E676') : '#787b86';
        table([['DXY', dC.toFixed(3), '#000', '#D4AF37'], ['Cambio diario', ch == null ? '—' : (ch >= 0 ? '+' : '') + ch.toFixed(2) + '%', ch >= 0 ? o.up : o.dn], ['Tendencia DXY', up ? 'Alcista ▲' : 'Bajista ▼', up ? o.up : o.dn], ['Correlación oro/DXY', cr == null ? '—' : cr.toFixed(2), cr != null && cr < 0 ? '#00BCD4' : '#FFEB3B'], ['Sesgo para el oro', bias, '#000', bc]], 'Arriba derecha', h < 130 ? 8 : 9, top, h);
      }
    }
    function sub(s, top, h, a, b) {
      ctx.strokeStyle = C.line; ctx.beginPath(); ctx.moveTo(0, top + .5); ctx.lineTo(lay.W, top + .5); ctx.stroke();
      const ci = S.cross ? Math.round(I(S.cross.x)) : S.data.length - 1;
      ctx.textAlign = 'left'; ctx.fillStyle = C.mute;
      ctx.save(); ctx.beginPath(); ctx.rect(0, top, lay.W, h); ctx.clip();
      if (s === 'dxy') subDxy(top, h, a, b);
      else if (s === 'rsi') {
        const y = v => top + 6 + (100 - v) / 100 * (h - 12);
        ctx.fillStyle = C.violet; ctx.globalAlpha = .06; ctx.fillRect(0, y(70), lay.PW, y(30) - y(70)); ctx.globalAlpha = 1;
        [30, 70].forEach(v => { ctx.setLineDash([3, 3]); ctx.strokeStyle = C.line; ctx.beginPath(); ctx.moveTo(0, y(v)); ctx.lineTo(lay.PW, y(v)); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = C.mute; ctx.fillText(v, lay.PW + 7, y(v)); });
        ctx.save(); ctx.beginPath(); ctx.rect(0, top, lay.PW, h); ctx.clip(); line(K.rsi, C.violet, 1.5, a, b, y); if (ind.div.on && K.div) K.div.forEach(v => { if (v.b < a - 80 || v.a > b) return; ctx.strokeStyle = v.type === 'bull' ? C.up : C.dn; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(X(v.a), y(K.rsi[v.a])); ctx.lineTo(X(v.b), y(K.rsi[v.b])); ctx.stroke(); ctx.lineWidth = 1; }); ctx.restore();
        ctx.fillStyle = C.mute; ctx.fillText(`RSI ${ind.rsi.p}  `, 8, top + 12); const v = K.rsi[ci]; if (v != null) { ctx.fillStyle = C.violet; ctx.fillText(v.toFixed(1), 8 + ctx.measureText(`RSI ${ind.rsi.p}  `).width, top + 12); }
      } else {
        let m = 1e-12; for (let i = a; i <= b; i++) if (K.macd.m[i] != null) m = Math.max(m, Math.abs(K.macd.m[i]), Math.abs(K.macd.sg[i]), Math.abs(K.macd.h[i]));
        const y = v => top + h / 2 - v / m * (h / 2 - 8), bw = Math.max(1, S.barW * .6);
        for (let i = a; i <= b; i++) { if (X(i) > lay.PW) break; const v = K.macd.h[i]; ctx.fillStyle = v >= 0 ? C.up : C.dn; ctx.globalAlpha = .45; ctx.fillRect(X(i) - bw / 2, Math.min(y(0), y(v)), bw, Math.abs(y(v) - y(0))); }
        ctx.globalAlpha = 1; ctx.save(); ctx.beginPath(); ctx.rect(0, top, lay.PW, h); ctx.clip(); line(K.macd.m, C.blue, 1.4, a, b, y); line(K.macd.sg, C.coral, 1.4, a, b, y); ctx.restore();
        ctx.fillStyle = C.mute; ctx.fillText(`MACD ${ind.macd.f} ${ind.macd.s} ${ind.macd.g}`, 8, top + 12);
      }
      ctx.restore();
    }
    // ---------- herramientas de dibujo ----------
    const sp = q => ({ x: X(iAt(q.t)), y: Y(q.price) });
    function drawings() {
      for (const d of S.drawings) {
        const sel = d.id === S.sel, pts = d.p.map(sp); ctx.strokeStyle = ctx.fillStyle = d.color; ctx.lineWidth = sel ? 2.2 : 1.6;
        if (d.type === 'trend') { ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y); ctx.lineTo(pts[1].x, pts[1].y); ctx.stroke(); }
        else if (d.type === 'hline') { ctx.beginPath(); ctx.moveTo(0, pts[0].y); ctx.lineTo(lay.PW, pts[0].y); ctx.stroke(); }
        else if (d.type === 'rect') { const x = Math.min(pts[0].x, pts[1].x), y = Math.min(pts[0].y, pts[1].y), w = Math.abs(pts[1].x - pts[0].x), h = Math.abs(pts[1].y - pts[0].y); ctx.globalAlpha = .14; ctx.fillRect(x, y, w, h); ctx.globalAlpha = 1; ctx.strokeRect(x, y, w, h); }
        else if (d.type === 'fib') {
          const x1 = Math.min(pts[0].x, pts[1].x), p1 = d.p[0].price, p2 = d.p[1].price; ctx.textAlign = 'left'; ctx.font = '11px Outfit, system-ui, sans-serif';
          FIB.forEach((f, k) => { const pr = p2 + (p1 - p2) * f, y = Y(pr); ctx.globalAlpha = k === 0 || k === FIB.length - 1 ? 1 : .8; ctx.beginPath(); ctx.moveTo(x1, y); ctx.lineTo(lay.PW, y); ctx.stroke(); ctx.globalAlpha = 1; ctx.fillText(`${f} (${fmtP(pr)})`, x1 + 4, y - 7); });
          ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y); ctx.lineTo(pts[1].x, pts[1].y); ctx.stroke(); ctx.setLineDash([]);
        }
        ctx.lineWidth = 1;
        if (sel) (d.type === 'hline' ? [{ x: lay.PW / 2, y: pts[0].y }] : pts).forEach(p => { ctx.beginPath(); ctx.arc(p.x, p.y, 6, 0, 7); ctx.fillStyle = C.bg; ctx.fill(); ctx.strokeStyle = d.color; ctx.lineWidth = 2; ctx.stroke(); ctx.lineWidth = 1; });
      }
    }
    function measure() {
      const m = S.measure, a = { x: X(m.a.i), y: Y(m.a.price) }, b = { x: X(m.b.i), y: Y(m.b.price) }, up = m.b.price >= m.a.price;
      ctx.fillStyle = up ? C.blue : C.coral; ctx.globalAlpha = .16; ctx.fillRect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y)); ctx.globalAlpha = 1;
      const d = m.b.price - m.a.price, pct = d / m.a.price * 100, bars = Math.round(m.b.i - m.a.i);
      const txt = `${d >= 0 ? '+' : ''}${fmtP(d)} (${pct >= 0 ? '+' : ''}${pct.toFixed(2)} %) · ${bars} velas`;
      ctx.font = '600 12px Outfit, system-ui, sans-serif'; const w = ctx.measureText(txt).width + 16, cx = Math.min(lay.PW - w / 2 - 4, Math.max(w / 2 + 4, (a.x + b.x) / 2)), cy = Math.max(16, Math.min(b.y, a.y) - 18);
      ctx.fillStyle = up ? C.blue : C.coral; roundRect(cx - w / 2, cy - 12, w, 24, 6); ctx.fill(); ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.fillText(txt, cx, cy); ctx.font = '11px Outfit, system-ui, sans-serif';
    }
    function distSeg(p, a, b) { const dx = b.x - a.x, dy = b.y - a.y, l = dx * dx + dy * dy; let t = l ? ((p.x - a.x) * dx + (p.y - a.y) * dy) / l : 0; t = Math.max(0, Math.min(1, t)); return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy)); }
    function hit(p, touch) {
      const tol = touch ? 18 : 9;
      const order = [...S.drawings].sort((x, y) => (y.id === S.sel) - (x.id === S.sel));
      for (const d of order) {
        const pts = d.p.map(sp);
        if (d.type === 'hline') { if (Math.abs(p.y - pts[0].y) < tol) return { d, h: -1 }; continue; }
        for (let k = 0; k < pts.length; k++) if (Math.hypot(p.x - pts[k].x, p.y - pts[k].y) < tol + 4) return { d, h: k };
        if (d.type === 'trend' && distSeg(p, pts[0], pts[1]) < tol) return { d, h: -1 };
        if (d.type === 'rect') { const x1 = Math.min(pts[0].x, pts[1].x), x2 = Math.max(pts[0].x, pts[1].x), y1 = Math.min(pts[0].y, pts[1].y), y2 = Math.max(pts[0].y, pts[1].y); if (p.x > x1 - tol && p.x < x2 + tol && p.y > y1 - tol && p.y < y2 + tol) return { d, h: -1 }; }
        if (d.type === 'fib') { const x1 = Math.min(pts[0].x, pts[1].x); if (p.x > x1 - tol && FIB.some(f => Math.abs(p.y - Y(d.p[1].price + (d.p[0].price - d.p[1].price) * f)) < tol)) return { d, h: -1 }; }
      }
      return null;
    }
    function snap(p) {
      let i = I(p.x), price = P(p.y);
      if (S.magnet) { const k = Math.max(0, Math.min(S.data.length - 1, Math.round(i))), c = S.data[k]; let best = null; for (const v of [c.open, c.high, c.low, c.close]) if (best === null || Math.abs(Y(v) - p.y) < Math.abs(Y(best) - p.y)) best = v; if (Math.abs(Y(best) - p.y) < 40) { i = k; price = best; } }
      return { i, price, t: tAt(i) };
    }
    const COLOR = { trend: '#f2c14e', hline: '#4fc3f7', rect: '#b388ff', fib: '#f2c14e' };
    const uid = () => Math.random().toString(36).slice(2, 9);

    // ---------- gestos ----------
    const ptrs = new Map(); let G = null, longT = 0;
    const pos = e => { const r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
    cv.addEventListener('pointerdown', e => {
      try { cv.setPointerCapture(e.pointerId); } catch (x) {} const p = pos(e), touch = e.pointerType !== 'mouse'; ptrs.set(e.pointerId, p);
      if (ptrs.size === 2) { clearTimeout(longT); const [p1, p2] = [...ptrs.values()], mid = (p1.x + p2.x) / 2; G = { mode: 'pinch', d0: Math.abs(p1.x - p2.x) || 1, w0: S.barW, anchor: I(mid), mid }; S.cross = null; req(); return; }
      if (S.measure && S.tool !== 'measure') { S.measure = null; }
      if (p.x > lay.PW && p.y < lay.mainH) { G = { mode: 'yscale', y0: p.y, lo: S.lo, hi: S.hi, touch }; if (S.auto) { S.auto = false; } G.lo = S.lo; G.hi = S.hi; return; }
      if (p.y > lay.H - lay.TB) { G = { mode: 'xscale', x0: p.x, w0: S.barW }; return; }
      if (p.y > lay.mainH) { G = { mode: 'pan', x0: p.x, y0: p.y, r0: S.right, lo: S.lo, hi: S.hi, moved: false, touch, sub: true }; return; }
      if (S.tool !== 'cursor') {
        const q = snap(p);
        if (S.tool === 'measure') { S.measure = { a: q, b: q }; G = { mode: 'measure' }; req(); return; }
        const d = { id: uid(), type: S.tool, color: COLOR[S.tool], p: S.tool === 'hline' ? [{ t: q.t, price: q.price }] : [{ t: q.t, price: q.price }, { t: q.t, price: q.price }] };
        S.drawings.push(d); S.sel = d.id; G = { mode: 'handle', d, h: S.tool === 'hline' ? -1 : 1, creating: true, start: q, orig: d.p.map(x => ({ ...x })) }; req(); return;
      }
      const h = hit(p, touch);
      if (h) { S.sel = h.d.id; const q = { i: I(p.x), price: P(p.y) }; G = { mode: h.h >= 0 ? 'handle' : 'body', d: h.d, h: h.h, start: q, orig: h.d.p.map(x => ({ i: iAt(x.t), price: x.price })) }; cbs.select(h.d); req(); return; }
      if (S.sel) { S.sel = null; cbs.select(null); }
      G = { mode: 'pan', x0: p.x, y0: p.y, r0: S.right, lo: S.lo, hi: S.hi, moved: false, touch };
      if (touch) longT = setTimeout(() => { if (G && G.mode === 'pan' && !G.moved) { G.mode = 'cross'; S.cross = p; req(); if (navigator.vibrate) try { navigator.vibrate(8); } catch (e) {} } }, 380);
      req();
    });
    cv.addEventListener('pointermove', e => {
      const p = pos(e); if (ptrs.has(e.pointerId)) ptrs.set(e.pointerId, p);
      if (!G) { if (e.pointerType === 'mouse') { S.cross = p.x < lay.PW && p.y < lay.H - lay.TB ? p : null; if (!S.cross) cbs.cross(null); req(); } return; }
      if (G.mode === 'pinch' && ptrs.size >= 2) { const [p1, p2] = [...ptrs.values()], d = Math.abs(p1.x - p2.x) || 1, mid = (p1.x + p2.x) / 2; S.barW = G.w0 * d / G.d0; clampView(); S.right = G.anchor + (lay.PW - mid) / S.barW; req(); return; }
      if (G.mode === 'yscale') { const f = Math.exp((p.y - G.y0) * .006), c = (G.hi + G.lo) / 2, r = (G.hi - G.lo) / 2 * f; S.lo = c - r; S.hi = c + r; req(); return; }
      if (G.mode === 'xscale') { const r0 = S.right; S.barW = G.w0 * Math.exp((p.x - G.x0) * .006); S.right = r0; req(); return; }
      if (G.mode === 'cross') { S.cross = p; req(); return; }
      if (G.mode === 'measure') { S.measure.b = snap(p); req(); return; }
      if (G.mode === 'pan') {
        const dx = p.x - G.x0, dy = p.y - G.y0; if (Math.hypot(dx, dy) > 6) { G.moved = true; clearTimeout(longT); }
        if (e.pointerType === 'mouse') S.cross = null;
        S.right = G.r0 - dx / S.barW;
        if (!S.auto && !G.sub) { const k = (G.hi - G.lo) / (lay.mainH - 12) * dy; S.lo = G.lo + k; S.hi = G.hi + k; }
        req(); return;
      }
      if (G.mode === 'handle' || G.mode === 'body') {
        const d = G.d;
        if (G.mode === 'handle') { const q = snap(p); if (d.type === 'hline') d.p[0] = { t: q.t, price: q.price }; else d.p[G.h] = { t: q.t, price: q.price }; }
        else { const di = I(p.x) - G.start.i, dp = P(p.y) - G.start.price; d.p = G.orig.map(o => ({ t: tAt(o.i + di), price: o.price + dp })); }
        req();
      }
    });
    function end(e) {
      ptrs.delete(e.pointerId); clearTimeout(longT);
      if (!G) return;
      if (G.mode === 'pinch') { if (ptrs.size === 1) { const p = [...ptrs.values()][0]; G = { mode: 'pan', x0: p.x, y0: p.y, r0: S.right, lo: S.lo, hi: S.hi, moved: true, touch: true }; } else G = null; return; }
      if (ptrs.size) return;
      if (G.mode === 'cross') { cbs.cross(null); S.cross = null; }
      if (G.mode === 'pan' && !G.moved && G.touch && S.cross) { S.cross = null; cbs.cross(null); }
      if (G.mode === 'handle' && G.creating) {
        const d = G.d, a = d.p[0], b = d.p[1];
        if (b && Math.abs(X(iAt(a.t)) - X(iAt(b.t))) < 8 && Math.abs(Y(a.price) - Y(b.price)) < 8) { // toque sin arrastrar: tamaño por defecto
          const i0 = iAt(a.t), span = Math.max(8, 60 / S.barW), dp = (S.hi - S.lo) * .12;
          d.p[1] = { t: tAt(i0 + span), price: a.price + (d.type === 'trend' ? dp : -dp) };
        }
        S.tool = 'cursor'; cbs.tool('cursor'); cbs.select(d);
      }
      if (G.mode === 'measure') { S.tool = 'cursor'; cbs.tool('cursor'); }
      if (G.mode === 'handle' || G.mode === 'body') cbs.change();
      G = null; req();
    }
    cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
    cv.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse' && !G) { S.cross = null; cbs.cross(null); req(); } });
    cv.addEventListener('wheel', e => { e.preventDefault(); const p = pos(e), anchor = I(p.x); S.barW *= e.deltaY > 0 ? 1 / 1.12 : 1.12; clampView(); S.right = anchor + (lay.PW - p.x) / S.barW; req(); }, { passive: false });
    let lastTap = 0;
    cv.addEventListener('pointerup', e => { const p = pos(e); if (p.x > lay.PW && p.y < lay.mainH) { const now = Date.now(); if (now - lastTap < 350) { S.auto = true; req(); } lastTap = now; } });
    cv.addEventListener('dblclick', e => { const p = pos(e); if (p.x > lay.PW) { S.auto = true; req(); } });
    const ro = new ResizeObserver(req); ro.observe(wrap);
    const mo = new MutationObserver(() => { colors(); req(); }); mo.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { colors(); req(); }); } catch (e) {}

    return {
      setData(d, step, digits, keep) {
        const oldLen = S.data.length, follow = S.right >= oldLen - 1.5;
        S.data = d; if (step) S.step = step; if (digits != null) S.digits = digits; compute();
        if (!keep) { S.barW = Math.max(4, Math.min(12, (wrap.clientWidth || 360) / 60)); S.right = d.length - 1 + 5; S.auto = true; S.cross = null; S.measure = null; }
        else if (follow && d.length > oldLen) S.right += d.length - oldLen;
        req();
      },
      setExtra(o, quiet) { const old = S.ext || {}, nw = o || {}, ch = ['htf', 'day', 'dxy', 'dxyHtf', 'sym'].some(k => old[k] !== nw[k] || (nw[k] && nw[k].length !== (old['_' + k] || 0))); S.ext = { ...nw }; ['htf', 'day', 'dxy', 'dxyHtf'].forEach(k => { S.ext['_' + k] = nw[k] ? nw[k].length : 0; }); if (ch && !quiet && S.data.length) { compute(); req(); } return ch; },
      events() { const R = K.rf, D = K.dx, n = S.data.length, out = []; if (n < 3) return out; const t = S.data[n - 2].time;
        if (R && R.o.alSweep) R.sweeps.filter(s => s.i === n - 2).forEach(s => out.push({ k: 'sweep' + (s.bull ? 'B' : 'S'), t, title: s.bull ? 'Sweep de liquidez inferior (posible rebote)' : 'Sweep de liquidez superior (posible caída)', body: s.bull ? 'Barrido de mínimos iguales con cierre por encima' : 'Barrido de máximos iguales con cierre por debajo' }));
        if (R && R.o.alSig) R.sigs.filter(s => s.i === n - 2).forEach(s => out.push({ k: 'sig', t, title: (s.buy ? 'Señal de COMPRA ' : 'Señal de VENTA ') + s.sc + '/5', body: 'Retest de zona · Radiant Fortune Zones' }));
        if (false && D && ind.dxy.alert) { const a = D.C[n - 3], b = D.C[n - 2], ea = D.ema[n - 3], eb = D.ema[n - 2]; if (a != null && b != null && ea != null && eb != null) { if (a <= ea && b > eb) out.push({ k: 'dxyU', t, title: 'DXY cruza EMA al alza', body: 'DXY se vuelve alcista: presión bajista para el oro' }); if (a >= ea && b < eb) out.push({ k: 'dxyD', t, title: 'DXY cruza EMA a la baja', body: 'DXY se vuelve bajista: viento a favor para el oro' }); } }
        return out; },
      setType(t) { S.type = t; compute(); req(); }, getType: () => S.type,
      setInd(o) { for (const k in o) Object.assign(ind[k], o[k]); if (S.data.length) compute(); req(); }, getInd: () => JSON.parse(JSON.stringify(ind)),
      setTool(t) { S.tool = t; if (t !== 'cursor') { S.sel = null; cbs.select(null); } req(); }, getTool: () => S.tool,
      setMagnet(v) { S.magnet = v; }, getMagnet: () => S.magnet,
      setDrawings(a) { S.drawings = a || []; S.sel = null; req(); }, getDrawings: () => S.drawings,
      deleteSelected() { S.drawings = S.drawings.filter(d => d.id !== S.sel); S.sel = null; cbs.select(null); cbs.change(); req(); },
      colorSelected(c) { const d = S.drawings.find(x => x.id === S.sel); if (d) { d.color = c; cbs.change(); req(); } },
      clearDrawings() { S.drawings = []; S.sel = null; cbs.select(null); cbs.change(); req(); },
      resetView() { S.barW = Math.max(4, Math.min(12, wrap.clientWidth / 60)); S.right = S.data.length - 1 + 5; S.auto = true; req(); },
      zoom(f) { const a = I(lay.PW * .75); S.barW *= f; clampView(); S.right = a + lay.PW * .25 / S.barW; req(); },
      isAuto: () => S.auto,
      candleAt: i => S.data[i], values(i) { return { e: K.ema.map(a => a[i]), rsi: K.rsi[i] }; },
      on(ev, fn) { cbs[ev] = fn; }, redraw: req,
    };
  }
  FortunaChart.analyze = analyze; FortunaChart.RDEF = RDEF; FortunaChart.ZDEF = ZDEF; FortunaChart.autoTf = autoTf; FortunaChart.rfzCalc = rfzCalc; FortunaChart.divergences = divergences; FortunaChart.rsi = rsi;
  window.FortunaChart = FortunaChart;
})();
