-- =====================================================================
-- Fortuna Radiante · v5: seguridad, aviso si el robot se para, invitaciones con XP,
-- resumen semanal automático y dibujos del gráfico guardados en tu cuenta.
-- Supabase → SQL Editor → New query → pega TODO → Run. Se puede repetir.
-- Necesita haber ejecutado antes fortuna-v4-supabase.sql.
-- =====================================================================

-- 1) Nunca se guardan contraseñas de inversor (y se borran las que hubiera)
update public.access set investor_pw = null where investor_pw is not null;
create or replace function public.no_investor_pw() returns trigger language plpgsql as $$
begin new.investor_pw := null; return new; end $$;
drop trigger if exists no_investor_pw on public.access;
create trigger no_investor_pw before insert or update on public.access for each row execute function public.no_investor_pw();

-- 2) Aviso al administrador si el robot de precios deja de enviar (días de mercado)
create or replace function public.feed_watch() returns void
language plpgsql security definer set search_path = public as $$
declare last timestamptz; wd int; h int; flag text;
begin
  select max(ts) into last from public.prices;
  if last is null then return; end if;
  wd := extract(isodow from now() at time zone 'America/New_York');
  h := extract(hour from now() at time zone 'America/New_York');
  -- mercado cerrado: viernes desde las 17 h de Nueva York hasta el domingo a las 18 h
  if wd = 6 or (wd = 5 and h >= 17) or (wd = 7 and h < 18) then return; end if;
  select value into flag from private.settings where key = 'feed_alerted';
  if now() - last > interval '10 minutes' then
    if flag is null or flag <> last::text then
      insert into private.settings (key, value) values ('feed_alerted', last::text)
        on conflict (key) do update set value = excluded.value;
      perform public.notify_push(jsonb_build_object('type', 'feed', 'record', jsonb_build_object('last', last)));
    end if;
  end if;
end $$;
revoke all on function public.feed_watch() from public, anon, authenticated;

-- 3) Invitaciones: quien invita gana 150 XP cuando su invitado es aprobado
create table if not exists public.referrals (
  user_id uuid primary key references auth.users (id) on delete cascade,
  referrer uuid not null references auth.users (id) on delete cascade,
  rewarded boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.referrals enable row level security;
drop policy if exists "ver mis invitados" on public.referrals;
create policy "ver mis invitados" on public.referrals for select to authenticated using (referrer = auth.uid() or public.is_admin());
grant select on public.referrals to authenticated;

create or replace function public.on_new_user_ref() returns trigger
language plpgsql security definer set search_path = public as $$
declare r uuid;
begin
  begin r := nullif(new.raw_user_meta_data ->> 'ref', '')::uuid; exception when others then r := null; end;
  if r is not null and r <> new.id and exists (select 1 from auth.users where id = r) then
    insert into public.referrals (user_id, referrer) values (new.id, r) on conflict do nothing;
  end if;
  return new;
end $$;
drop trigger if exists on_new_user_ref on auth.users;
create trigger on_new_user_ref after insert on auth.users for each row execute function public.on_new_user_ref();

create or replace function public.on_access_ref() returns trigger
language plpgsql security definer set search_path = public as $$
declare rf record;
begin
  if new.status = 'aprobado' and (tg_op = 'INSERT' or old.status is distinct from 'aprobado') then
    update public.referrals set rewarded = true where user_id = new.user_id and not rewarded returning * into rf;
    if rf.user_id is not null then
      insert into public.xp_awards (user_id, xp, reason)
      values (rf.referrer, 150, left('Invitación: ' || coalesce((select alias from public.profiles where id = new.user_id), 'nuevo miembro'), 120));
    end if;
  end if;
  return new;
end $$;
drop trigger if exists on_access_ref on public.access;
create trigger on_access_ref after insert or update on public.access for each row execute function public.on_access_ref();

-- 4) Dibujos del gráfico guardados en tu cuenta (los ves igual en el móvil y en el PC)
create table if not exists public.drawings (
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  symbol text not null check (char_length(symbol) between 2 and 20),
  data jsonb not null default '[]',
  updated_at timestamptz not null default now(),
  primary key (user_id, symbol),
  check (pg_column_size(data) < 200000)
);
alter table public.drawings enable row level security;
drop policy if exists "mis dibujos" on public.drawings;
create policy "mis dibujos" on public.drawings for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
grant select, insert, update, delete on public.drawings to authenticated;

-- 5) Resumen semanal automático (domingos 19:00 hora de España): se publica en Noticias y avisa a todos
create or replace function public.weekly_summary() returns text
language plpgsql security definer set search_path = public as $$
declare n int; w int; p numeric; ch text; body text; bias text; t text;
begin
  select count(*), count(*) filter (where result_pips > 0), coalesce(round(sum(result_pips), 1), 0) into n, w, p
    from public.signals where closed_at > now() - interval '7 days' and result_pips is not null and status <> 'cancelada';
  select string_agg(c.icon || ' ' || c.title || ': ' || coalesce(x.names, 'sin ganadores'), E'\n') into ch from public.challenges c
    left join lateral (
      select string_agg(pr.alias, ', ') names from public.challenge_joins j join public.profiles pr on pr.id = j.user_id
      where j.challenge_id = c.id and public.challenge_value(c.id, j.user_id) >= c.target
    ) x on true
    where c.ends_at between now() - interval '7 days' and now();
  select value -> 'market' ->> 'comment' into bias from public.app_config where key = 'app';
  t := 'Resumen semanal de Fortuna Radiante';
  body := '📡 Señales Fortuna de la semana: ' || case when n = 0 then 'no se cerró ninguna señal.'
          else n || ' cerradas, ' || round(100.0 * w / n) || ' % de acierto, ' || case when p > 0 then '+' else '' end || p || ' pips.' end
       || E'\n\n🏆 Retos terminados:\n' || coalesce(ch, 'Esta semana no terminó ningún reto.')
       || case when coalesce(bias, '') <> '' then E'\n\n🧭 Sesgo del equipo: ' || bias else '' end
       || E'\n\nResultados pasados no garantizan resultados futuros. No es asesoramiento financiero.';
  insert into public.news (id, channel, post_id, posted_at, title, body, topic, has_media)
  values ('fortuna/semana-' || to_char(now(), 'IYYY-IW'), 'fortuna', null, now(), t, body, 'mercados', false)
  on conflict (id) do update set body = excluded.body, posted_at = excluded.posted_at;
  perform public.notify_push(jsonb_build_object('type', 'weekly', 'record', jsonb_build_object('title', t, 'body', left(body, 180))));
  return body;
end $$;
revoke all on function public.weekly_summary() from public, anon, authenticated;

do $$
begin
  create extension if not exists pg_cron;
  if exists (select 1 from cron.job where jobname = 'robot-vigilancia') then perform cron.unschedule('robot-vigilancia'); end if;
  perform cron.schedule('robot-vigilancia', '*/5 * * * *', 'select public.feed_watch()');
  if exists (select 1 from cron.job where jobname = 'resumen-semanal') then perform cron.unschedule('resumen-semanal'); end if;
  perform cron.schedule('resumen-semanal', '0 18 * * 0', 'select public.weekly_summary()');  -- 18:00 UTC = 19:00 en España (invierno)
exception when others then
  raise notice 'No se pudieron programar las tareas automáticas (%). Activa pg_cron en Database → Extensions y vuelve a ejecutar este archivo.', sqlerrm;
end $$;
