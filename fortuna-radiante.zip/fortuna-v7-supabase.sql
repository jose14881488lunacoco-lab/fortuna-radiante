-- =====================================================================
-- Fortuna Radiante · v7: SOPORTE (chat privado de cada persona con el administrador)
-- Supabase → SQL Editor → New query → pega TODO → Run. Se puede repetir.
-- Necesita haber ejecutado antes fortuna-v5-supabase.sql.
-- =====================================================================
create table if not exists public.support_messages (
  id bigserial primary key,
  user_id uuid not null references auth.users (id) on delete cascade,   -- de quién es la conversación
  sender uuid not null references auth.users (id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  from_admin boolean not null default false,
  read_user boolean not null default false,
  read_admin boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists support_user_id on public.support_messages (user_id, id desc);
alter table public.support_messages enable row level security;

-- cualquiera con cuenta (aunque aún no esté aprobado) puede escribir a soporte; el admin lo ve todo
drop policy if exists "ver soporte" on public.support_messages;
create policy "ver soporte" on public.support_messages for select to authenticated using (user_id = auth.uid() or public.is_admin());
drop policy if exists "escribir soporte" on public.support_messages;
create policy "escribir soporte" on public.support_messages for insert to authenticated
  with check (sender = auth.uid() and (user_id = auth.uid() or public.is_admin()));
grant select, insert on public.support_messages to authenticated;
grant usage, select on sequence public.support_messages_id_seq to authenticated;

create or replace function public.support_fix() returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.from_admin := public.is_admin() and new.user_id <> new.sender;
  new.read_admin := new.from_admin; new.read_user := not new.from_admin; new.created_at := now();
  if not new.from_admin and exists (select 1 from public.bans where user_id = new.sender) then raise exception 'No puedes enviar mensajes'; end if;
  return new;
end $$;
drop trigger if exists support_fix on public.support_messages;
create trigger support_fix before insert on public.support_messages for each row execute function public.support_fix();

create or replace function public.support_push() returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.notify_push(jsonb_build_object('type', 'support', 'record', jsonb_build_object('user_id', new.user_id, 'from_admin', new.from_admin, 'body', left(new.body, 140),
    'alias', (select alias from public.profiles where id = new.user_id))));
  return new;
end $$;
drop trigger if exists support_push on public.support_messages;
create trigger support_push after insert on public.support_messages for each row execute function public.support_push();

-- marcar como leído (cada uno lo suyo)
create or replace function public.support_read(p_user uuid default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_user is not null and public.is_admin() then
    update public.support_messages set read_admin = true where user_id = p_user and not read_admin;
  else
    update public.support_messages set read_user = true where user_id = auth.uid() and not read_user;
  end if;
end $$;
grant execute on function public.support_read(uuid) to authenticated;

-- lista de conversaciones para el administrador
create or replace function public.support_inbox()
returns table (user_id uuid, alias text, avatar_url text, email text, status text, last_body text, last_at timestamptz, last_from_admin boolean, unread bigint)
language sql stable security definer set search_path = public as $$
  select m.user_id, p.alias, p.avatar_url, u.email, a.status,
         (select body from public.support_messages x where x.user_id = m.user_id order by id desc limit 1),
         max(m.created_at), (select from_admin from public.support_messages x where x.user_id = m.user_id order by id desc limit 1),
         count(*) filter (where not m.read_admin)
  from public.support_messages m left join public.profiles p on p.id = m.user_id left join auth.users u on u.id = m.user_id
  left join public.access a on a.user_id = m.user_id
  where public.is_admin()
  group by m.user_id, p.alias, p.avatar_url, u.email, a.status
  order by max(m.created_at) desc;
$$;
grant execute on function public.support_inbox() to authenticated;
