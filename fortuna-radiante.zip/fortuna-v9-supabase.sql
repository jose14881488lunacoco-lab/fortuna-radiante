-- =====================================================================
-- Fortuna Radiante · v9: REACCIONES a los mensajes del chat (👍 ❤️ 😂 🔥 😮 🎯 💰 🚀)
-- Supabase → SQL Editor → New query → pega TODO → Run. Se puede repetir.
-- =====================================================================
create table if not exists public.message_reactions (
  message_id bigint not null references public.messages (id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  emoji text not null check (emoji in ('👍', '❤️', '😂', '🔥', '😮', '🎯', '💰', '🚀')),
  created_at timestamptz not null default now(),
  primary key (message_id, user_id, emoji)
);
create index if not exists message_reactions_msg on public.message_reactions (message_id);
alter table public.message_reactions enable row level security;
drop policy if exists "ver reacciones" on public.message_reactions;
create policy "ver reacciones" on public.message_reactions for select to authenticated using (public.has_access('comunidad'));
drop policy if exists "poner reacciones" on public.message_reactions;
create policy "poner reacciones" on public.message_reactions for insert to authenticated
  with check (user_id = auth.uid() and public.has_access('comunidad') and not exists (select 1 from public.bans b where b.user_id = auth.uid()));
drop policy if exists "quitar reacciones" on public.message_reactions;
create policy "quitar reacciones" on public.message_reactions for delete to authenticated using (user_id = auth.uid() or public.is_admin());
grant select, insert, delete on public.message_reactions to authenticated;
