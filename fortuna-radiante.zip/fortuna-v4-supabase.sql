-- =====================================================================
-- Fortuna Radiante · v4: clases grabadas, modo práctica, perfil verificado,
-- calendario económico con aviso, directos y canal #directo del chat.
-- Supabase → SQL Editor → New query → pega TODO → Run. Se puede repetir.
-- Necesita haber ejecutado antes fortuna-todo-en-uno.sql, precios-avisos-supabase.sql
-- y noticias-supabase.sql.
-- =====================================================================

-- 1) Canal #directo en el chat
alter table public.messages drop constraint if exists messages_channel_check;
alter table public.messages add constraint messages_channel_check
  check (channel in ('general', 'xauusd', 'analisis', 'mentorias', 'directo'));

-- 2) Clases grabadas (las sube el admin; se desbloquean con la XP de la liga)
create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 3 and 90),
  level text not null default 'principiante' check (level in ('principiante', 'intermedio', 'avanzado')),
  url text not null check (url ~ '^https://'),
  description text check (char_length(description) <= 500),
  min_xp int not null default 0 check (min_xp >= 0),
  sort int not null default 0,
  created_at timestamptz not null default now()
);
alter table public.lessons enable row level security;
drop policy if exists "ver clases" on public.lessons;
create policy "ver clases" on public.lessons for select to authenticated using (public.has_access('mentorias'));
drop policy if exists "admin clases" on public.lessons;
create policy "admin clases" on public.lessons for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.lessons to authenticated;

-- 3) Modo práctica (replay): cada partida guarda los pips conseguidos
create table if not exists public.practice_runs (
  id bigserial primary key,
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  symbol text not null default 'XAUUSD',
  tf int not null default 60,
  trades int not null default 0 check (trades between 0 and 200),
  wins int not null default 0 check (wins >= 0),
  pips numeric not null default 0 check (pips between -20000 and 20000),
  created_at timestamptz not null default now()
);
create index if not exists practice_runs_created on public.practice_runs (created_at desc);
alter table public.practice_runs enable row level security;
drop policy if exists "ver practica" on public.practice_runs;
create policy "ver practica" on public.practice_runs for select to authenticated using (public.has_access());
drop policy if exists "guardar practica" on public.practice_runs;
create policy "guardar practica" on public.practice_runs for insert to authenticated
  with check (user_id = auth.uid() and public.has_access());
grant select, insert on public.practice_runs to authenticated;
grant usage, select on sequence public.practice_runs_id_seq to authenticated;

create or replace function public.practice_ranking(p_days int default 30)
returns table (user_id uuid, alias text, avatar_url text, runs bigint, pips numeric, best numeric)
language sql stable security definer set search_path = public as $$
  select r.user_id, p.alias, p.avatar_url, count(*), round(sum(r.pips), 1), round(max(r.pips), 1)
  from public.practice_runs r join public.profiles p on p.id = r.user_id
  where public.has_access() and r.created_at > now() - make_interval(days => greatest(1, least(p_days, 365)))
  group by r.user_id, p.alias, p.avatar_url
  order by sum(r.pips) desc limit 50;
$$;
grant execute on function public.practice_ranking(int) to authenticated;

-- 4) Perfil de trader verificado: estadísticas reales del robot de MT (sin enseñar el saldo)
create or replace function public.verified_stats()
returns table (user_id uuid, trades bigint, win_rate numeric, profit_factor numeric, ret30 numeric, last_trade timestamptz)
language sql stable security definer set search_path = public as $$
  with t as (
    select x.user_id, count(*) n, count(*) filter (where profit > 0) w,
           sum(profit) filter (where profit > 0) gw, -sum(profit) filter (where profit < 0) gl,
           sum(profit) filter (where close_time > now() - interval '30 days') p30, max(close_time) lt
    from public.trades x where x.source = 'ea' group by x.user_id
  ), b as (select user_id, sum(balance) bal from public.mt_accounts group by user_id)
  select t.user_id, t.n, round(100.0 * t.w / nullif(t.n, 0), 1),
         round(coalesce(t.gw, 0) / nullif(t.gl, 0), 2),
         round(100 * coalesce(t.p30, 0) / nullif(b.bal - coalesce(t.p30, 0), 0), 1),
         t.lt
  from t left join b on b.user_id = t.user_id
  where public.has_access();
$$;
grant execute on function public.verified_stats() to authenticated;

-- 5) Calendario económico (lo rellena la función «noticias» cada hora) y aviso 15 min antes
create table if not exists public.econ_events (
  id text primary key,
  title text not null,
  country text not null,
  impact text not null,
  at timestamptz not null,
  forecast text, previous text,
  notified boolean not null default false,
  updated_at timestamptz not null default now()
);
create index if not exists econ_events_at on public.econ_events (at);
alter table public.econ_events enable row level security;
drop policy if exists "ver calendario" on public.econ_events;
create policy "ver calendario" on public.econ_events for select to authenticated using (public.has_access());
grant select on public.econ_events to authenticated;

create or replace function public.econ_tick() returns void
language plpgsql security definer set search_path = public as $$
declare e record;
begin
  for e in
    update public.econ_events set notified = true
    where not notified and impact = 'High' and country = 'USD'
      and at > now() and at <= now() + interval '16 minutes'
    returning *
  loop
    perform public.notify_push(jsonb_build_object('type', 'econ', 'record', to_jsonb(e)));
  end loop;
  delete from public.econ_events where at < now() - interval '14 days';
end $$;
revoke all on function public.econ_tick() from public, anon, authenticated;

do $$
begin
  create extension if not exists pg_cron;
  if exists (select 1 from cron.job where jobname = 'calendario-fortuna') then perform cron.unschedule('calendario-fortuna'); end if;
  perform cron.schedule('calendario-fortuna', '* * * * *', 'select public.econ_tick()');
exception when others then
  raise notice 'No se pudo programar el aviso del calendario (%). Activa pg_cron en Database → Extensions y vuelve a ejecutar este archivo.', sqlerrm;
end $$;

-- 6) Directo: cuando el admin enciende el directo en la app, se avisa a todos
create or replace function public.on_live_change() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.key = 'app' and coalesce((new.value -> 'live' ->> 'on')::boolean, false)
     and (tg_op = 'INSERT' or not coalesce((old.value -> 'live' ->> 'on')::boolean, false)) then
    perform public.notify_push(jsonb_build_object('type', 'live', 'record', new.value -> 'live'));
  end if;
  return new;
end $$;
drop trigger if exists on_live_change on public.app_config;
create trigger on_live_change after insert or update on public.app_config
  for each row execute function public.on_live_change();
