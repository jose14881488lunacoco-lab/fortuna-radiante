-- =====================================================================
-- Fortuna Radiante · Precios reales de Vantage (MT5) y notificaciones
-- Pega TODO este texto en Supabase → SQL Editor → New query → Run.
-- Ejecútalo DESPUÉS de comunidad-supabase.sql. Se puede repetir sin problema.
-- (Las claves privadas van en otro archivo que NO se sube a GitHub.)
-- =====================================================================

create extension if not exists pg_net;
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;
create table if not exists private.settings (key text primary key, value text not null);

-- 1) Precios al segundo y velas, que envía el robot de MT5
create table if not exists public.prices (
  symbol text primary key,
  bid double precision not null,
  ask double precision not null,
  ts timestamptz not null default now()
);
create table if not exists public.candles (
  symbol text not null,
  tf int not null,              -- minutos: 1, 5, 15, 60, 240, 1440
  t bigint not null,            -- apertura de la vela, segundos UTC
  o double precision not null, h double precision not null, l double precision not null, c double precision not null,
  primary key (symbol, tf, t)
);
alter table public.candles add column if not exists v double precision;   -- volumen (ticks)
alter table public.prices enable row level security;
alter table public.candles enable row level security;
drop policy if exists "precios visibles" on public.prices;
create policy "precios visibles" on public.prices for select using (true);
drop policy if exists "velas visibles" on public.candles;
create policy "velas visibles" on public.candles for select using (true);
grant select on public.prices, public.candles to anon, authenticated;

-- 2) Alertas de precio de cada miembro
create table if not exists public.alerts (
  id bigint generated always as identity primary key,
  user_id uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  symbol text not null,
  price double precision not null,
  above boolean not null,       -- true: avisar cuando suba hasta el precio; false: cuando baje
  active boolean not null default true,
  created_at timestamptz not null default now(),
  triggered_at timestamptz
);
alter table public.alerts enable row level security;
drop policy if exists "mis alertas" on public.alerts;
create policy "mis alertas" on public.alerts for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
grant select, insert, update, delete on public.alerts to authenticated;
grant usage, select on sequence public.alerts_id_seq to authenticated;

-- 3) Móviles suscritos a las notificaciones
create table if not exists public.push_subscriptions (
  endpoint text primary key,
  user_id uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  p256dh text not null,
  auth text not null,
  chat_pref text not null default 'mentions' check (chat_pref in ('all', 'mentions', 'none')),
  created_at timestamptz not null default now()
);
alter table public.push_subscriptions enable row level security;
drop policy if exists "mis avisos" on public.push_subscriptions;
create policy "mis avisos" on public.push_subscriptions for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
grant select, insert, update, delete on public.push_subscriptions to authenticated;

-- 4) Envío de notificaciones (llama a la función "notify" de Supabase)
create or replace function public.notify_push(payload jsonb) returns void language plpgsql security definer set search_path = public as $$
declare u text; tok text;
begin
  select value into u from private.settings where key = 'notify_url';
  select value into tok from private.settings where key = 'notify_token';
  if u is null or tok is null then return; end if;
  perform net.http_post(url := u, body := payload, headers := jsonb_build_object('Content-Type', 'application/json', 'x-notify-token', tok));
exception when others then
  raise warning 'notify_push: %', sqlerrm;   -- nunca bloquea el chat ni los precios
end $$;
revoke all on function public.notify_push(jsonb) from public, anon, authenticated;

create or replace function public.on_new_message() returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.notify_push(jsonb_build_object('type', 'message', 'record', to_jsonb(new)));
  return new;
end $$;
drop trigger if exists notify_new_message on public.messages;
create trigger notify_new_message after insert on public.messages for each row execute function public.on_new_message();

-- 5) Entrada de precios desde MT5 (protegida con una clave del robot)
create or replace function public.push_prices(p_token text, p_prices jsonb default '[]', p_candles jsonb default '[]')
returns int language plpgsql security definer set search_path = public as $$
declare a record; n int := 0;
begin
  if p_token is null or p_token is distinct from (select value from private.settings where key = 'feed_token') then
    raise exception 'Clave del robot incorrecta';
  end if;
  insert into public.prices (symbol, bid, ask, ts)
    select x ->> 's', (x ->> 'b')::float8, (x ->> 'a')::float8, coalesce(to_timestamp((x ->> 't')::float8), now())
    from jsonb_array_elements(p_prices) x
  on conflict (symbol) do update set bid = excluded.bid, ask = excluded.ask, ts = excluded.ts;
  if jsonb_array_length(p_candles) > 0 then
    insert into public.candles (symbol, tf, t, o, h, l, c, v)
      select x ->> 's', (x ->> 'f')::int, (x ->> 't')::bigint, (x ->> 'o')::float8, (x ->> 'h')::float8, (x ->> 'l')::float8, (x ->> 'c')::float8, (x ->> 'v')::float8
      from jsonb_array_elements(p_candles) x
    on conflict (symbol, tf, t) do update set o = excluded.o, h = excluded.h, l = excluded.l, c = excluded.c, v = excluded.v;
    -- guarda solo las ~700 últimas velas de cada mercado y temporalidad
    delete from public.candles cc using (
      select x ->> 's' s, (x ->> 'f')::int f, max((x ->> 't')::bigint) mt from jsonb_array_elements(p_candles) x group by 1, 2
    ) z where cc.symbol = z.s and cc.tf = z.f and cc.t < z.mt - z.f * 60 * 700;
  end if;
  -- alertas de precio que se cumplen
  for a in
    update public.alerts al set active = false, triggered_at = now()
    from public.prices p
    where al.active and p.symbol = al.symbol and ((al.above and p.bid >= al.price) or (not al.above and p.bid <= al.price))
    returning al.id, al.user_id, al.symbol, al.price, al.above, p.bid
  loop
    perform public.notify_push(jsonb_build_object('type', 'alert', 'record', to_jsonb(a)));
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.push_prices(text, jsonb, jsonb) from public;
grant execute on function public.push_prices(text, jsonb, jsonb) to anon, authenticated;
