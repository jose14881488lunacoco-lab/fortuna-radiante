-- =====================================================================
-- Fortuna Radiante · v8: el administrador crea, renombra, ordena y borra
-- las secciones (canales) del chat. Supabase → SQL Editor → pega TODO → Run.
-- Necesita haber ejecutado antes fortuna-v7-supabase.sql.
-- =====================================================================
create table if not exists public.chat_channels (
  id text primary key check (id ~ '^[a-z0-9_-]{2,30}$'),
  name text not null check (char_length(name) between 1 and 30),
  icon text not null default '#' check (char_length(icon) <= 8),
  description text check (char_length(description) <= 120),
  admin_only boolean not null default false,     -- solo el equipo escribe (por ejemplo, Anuncios)
  sort int not null default 0,
  created_at timestamptz not null default now()
);
alter table public.chat_channels enable row level security;
drop policy if exists "ver canales" on public.chat_channels;
create policy "ver canales" on public.chat_channels for select to anon, authenticated using (true);
drop policy if exists "admin canales" on public.chat_channels;
create policy "admin canales" on public.chat_channels for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select on public.chat_channels to anon, authenticated;
grant insert, update, delete on public.chat_channels to authenticated;

insert into public.chat_channels (id, name, icon, sort) values
  ('general', 'General', '#', 0), ('xauusd', 'XAUUSD', '#', 1), ('analisis', 'Análisis', '#', 2),
  ('mentorias', 'Mentorías', '#', 3), ('directo', 'Directo', '🔴', 4)
on conflict (id) do nothing;

-- los mensajes ya no tienen una lista fija: tienen que ir a un canal que exista
alter table public.messages drop constraint if exists messages_channel_check;
create or replace function public.message_channel_ok() returns trigger
language plpgsql security definer set search_path = public as $$
declare c public.chat_channels;
begin
  select * into c from public.chat_channels where id = new.channel;
  if c.id is null then raise exception 'Ese canal no existe'; end if;
  if c.admin_only and not (public.is_admin() or public.has_perm('moderate')) then raise exception 'En este canal solo escribe el equipo'; end if;
  return new;
end $$;
drop trigger if exists message_channel_ok on public.messages;
create trigger message_channel_ok before insert on public.messages for each row execute function public.message_channel_ok();

-- al borrar un canal se borran sus mensajes
create or replace function public.on_channel_delete() returns trigger
language plpgsql security definer set search_path = public as $$
begin delete from public.messages where channel = old.id; return old; end $$;
drop trigger if exists on_channel_delete on public.chat_channels;
create trigger on_channel_delete after delete on public.chat_channels for each row execute function public.on_channel_delete();
