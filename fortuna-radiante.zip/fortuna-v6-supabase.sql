-- =====================================================================
-- Fortuna Radiante · v6: guarda más historia de velas (1100 por mercado y temporalidad)
-- para ver más horas de gráfico. Supabase → SQL Editor → New query → pega TODO → Run.
-- =====================================================================
create or replace function public.push_prices(p_token text, p_prices jsonb default '[]', p_candles jsonb default '[]')
returns int language plpgsql security definer set search_path = public as $$
declare a record; n int := 0;
begin
  if p_token is null or p_token is distinct from (select value from private.settings where key = 'feed_token') then
    raise exception 'Clave del robot incorrecta';
  end if;
  insert into public.prices (symbol, bid, ask, ts)
    select x ->> 's', (x ->> 'b')::float8, (x ->> 'a')::float8, coalesce(to_timestamp((x ->> 't')::float8), now())
    from jsonb_array_elements(p_prices) x
  on conflict (symbol) do update set bid = excluded.bid, ask = excluded.ask, ts = excluded.ts;
  if jsonb_array_length(p_candles) > 0 then
    insert into public.candles (symbol, tf, t, o, h, l, c, v)
      select x ->> 's', (x ->> 'f')::int, (x ->> 't')::bigint, (x ->> 'o')::float8, (x ->> 'h')::float8, (x ->> 'l')::float8, (x ->> 'c')::float8, (x ->> 'v')::float8
      from jsonb_array_elements(p_candles) x
    on conflict (symbol, tf, t) do update set o = excluded.o, h = excluded.h, l = excluded.l, c = excluded.c, v = excluded.v;
    -- guarda solo las ~1100 últimas velas de cada mercado y temporalidad
    delete from public.candles cc using (
      select x ->> 's' s, (x ->> 'f')::int f, max((x ->> 't')::bigint) mt from jsonb_array_elements(p_candles) x group by 1, 2
    ) z where cc.symbol = z.s and cc.tf = z.f and cc.t < z.mt - z.f * 60 * 1100;
  end if;
  -- alertas de precio que se cumplen
  for a in
    update public.alerts al set active = false, triggered_at = now()
    from public.prices p
    where al.active and p.symbol = al.symbol and ((al.above and p.bid >= al.price) or (not al.above and p.bid <= al.price))
    returning al.id, al.user_id, al.symbol, al.price, al.above, p.bid
  loop
    perform public.notify_push(jsonb_build_object('type', 'alert', 'record', to_jsonb(a)));
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.push_prices(text, jsonb, jsonb) from public;
grant execute on function public.push_prices(text, jsonb, jsonb) to anon, authenticated;
