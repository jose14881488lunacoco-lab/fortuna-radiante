-- =====================================================================
-- Fortuna Radiante · v3: GESTIÓN DE USUARIOS, ROLES, SEÑALES, DIARIO MT Y LIGA DE RETOS
-- Supabase → SQL Editor → New query → pega TODO → Run.
-- Antes tienen que estar ejecutados comunidad-supabase.sql, precios-avisos-supabase.sql
-- y admin-supabase.sql. Se puede ejecutar más de una vez sin borrar nada.
-- =====================================================================

-- 0) Las secciones nuevas (Señales, Liga y Diario) se activan para quien ya estaba aprobado
update public.access set sections = sections || '{"senales": true, "liga": true, "diario": true}'::jsonb
where status = 'aprobado' and not (sections ? 'senales');

-- 1) ROLES DE LA COMUNIDAD (los crea y reparte el admin)
create table if not exists public.roles (
  id text primary key check (id ~ '^[a-z0-9_-]{2,24}$'),
  name text not null check (char_length(name) between 2 and 24),
  color text not null default '#D9A21B' check (color ~ '^#[0-9A-Fa-f]{6}$'),
  icon text not null default '⭐' check (char_length(icon) <= 4),
  sort int not null default 0,
  can_signals boolean not null default false,   -- puede publicar señales
  can_moderate boolean not null default false,  -- puede borrar mensajes del chat
  created_at timestamptz not null default now()
);
create table if not exists public.user_roles (
  user_id uuid not null references auth.users (id) on delete cascade,
  role_id text not null references public.roles (id) on delete cascade on update cascade,
  primary key (user_id, role_id)
);
alter table public.roles enable row level security;
alter table public.user_roles enable row level security;
drop policy if exists "ver roles" on public.roles;
create policy "ver roles" on public.roles for select to authenticated using (true);
drop policy if exists "admin roles" on public.roles;
create policy "admin roles" on public.roles for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "ver roles de usuarios" on public.user_roles;
create policy "ver roles de usuarios" on public.user_roles for select to authenticated using (true);
drop policy if exists "admin reparte roles" on public.user_roles;
create policy "admin reparte roles" on public.user_roles for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.roles, public.user_roles to authenticated;

insert into public.roles (id, name, color, icon, sort, can_signals, can_moderate) values
  ('fundador', 'Fundador', '#F2C14E', '👑', 0, true, true),
  ('analista', 'Analista', '#3DDC97', '📡', 1, true, false),
  ('mentor', 'Mentor', '#7C9CFF', '🎓', 2, false, false),
  ('moderador', 'Moderador', '#FF8A65', '🛡️', 3, false, true),
  ('vip', 'VIP', '#B388FF', '💎', 4, false, false),
  ('trader', 'Trader', '#D9A21B', '📈', 5, false, false),
  ('novato', 'Novato', '#8BC34A', '🌱', 6, false, false)
on conflict (id) do nothing;

create or replace function public.has_perm(p text) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_admin() or exists (
    select 1 from public.user_roles ur join public.roles r on r.id = ur.role_id
    where ur.user_id = auth.uid() and ((p = 'signals' and r.can_signals) or (p = 'moderate' and r.can_moderate)));
$$;
grant execute on function public.has_perm(text) to authenticated;

-- los moderadores también pueden borrar mensajes
drop policy if exists "moderadores borran mensajes" on public.messages;
create policy "moderadores borran mensajes" on public.messages for delete to authenticated using (public.has_perm('moderate'));

-- 2) GESTIÓN DE USUARIOS PARA EL ADMIN (ve el correo de cada uno)
create or replace function public.admin_users()
returns table (id uuid, email text, alias text, avatar_url text, created_at timestamptz, last_sign_in_at timestamptz,
               status text, sections jsonb, indicators jsonb, broker text, mt5_server text, mt5_login text, balance numeric,
               investor_pw text, proof_path text, note text, submitted_at timestamptz, roles text[], muted boolean, is_admin boolean)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Solo el administrador'; end if;
  return query
    select u.id, u.email::text, p.alias, p.avatar_url, u.created_at, u.last_sign_in_at,
           a.status, a.sections, a.indicators, a.broker, a.mt5_server, a.mt5_login, a.balance, a.investor_pw, a.proof_path, a.note, a.submitted_at,
           coalesce((select array_agg(ur.role_id order by ur.role_id) from public.user_roles ur where ur.user_id = u.id), '{}'::text[]),
           exists (select 1 from public.bans b where b.user_id = u.id),
           exists (select 1 from public.admins ad where ad.user_id = u.id)
    from auth.users u
    left join public.profiles p on p.id = u.id
    left join public.access a on a.user_id = u.id
    order by u.created_at desc;
end $$;
revoke all on function public.admin_users() from public, anon;
grant execute on function public.admin_users() to authenticated;

-- borrar la cuenta de un usuario por completo (perfil, mensajes, diario, accesos…)
create or replace function public.admin_delete_user(p_user uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Solo el administrador'; end if;
  if p_user = auth.uid() then raise exception 'No puedes eliminar tu propia cuenta desde aquí'; end if;
  if exists (select 1 from public.admins where user_id = p_user) then raise exception 'No se puede eliminar a un administrador'; end if;
  delete from auth.users where id = p_user;
end $$;
revoke all on function public.admin_delete_user(uuid) from public, anon;
grant execute on function public.admin_delete_user(uuid) to authenticated;

-- 3) SEÑALES FORTUNA
create table if not exists public.signals (
  id uuid primary key default gen_random_uuid(),
  created_by uuid references auth.users (id) on delete set null,
  symbol text not null check (char_length(symbol) between 2 and 20),
  side text not null check (side in ('compra', 'venta')),
  kind text not null default 'mercado' check (kind in ('mercado', 'limite', 'stop')),
  entry numeric not null, entry_to numeric, sl numeric, tp1 numeric, tp2 numeric, tp3 numeric,
  timeframe text, note text check (char_length(note) <= 600),
  status text not null default 'activa' check (status in ('pendiente', 'activa', 'tp1', 'tp2', 'tp3', 'sl', 'be', 'cerrada', 'cancelada')),
  result_pips numeric,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), closed_at timestamptz
);
create index if not exists signals_created on public.signals (created_at desc);
alter table public.signals enable row level security;
drop policy if exists "ver señales" on public.signals;
create policy "ver señales" on public.signals for select to authenticated using (public.has_access('senales'));
drop policy if exists "publicar señales" on public.signals;
create policy "publicar señales" on public.signals for all to authenticated using (public.has_perm('signals')) with check (public.has_perm('signals'));
grant select, insert, update, delete on public.signals to authenticated;

create or replace function public.on_signal() returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.updated_at := now();
  if tg_op = 'UPDATE' and new.status is distinct from old.status and new.status in ('tp3', 'sl', 'be', 'cerrada', 'cancelada') and new.closed_at is null then new.closed_at := now(); end if;
  return new;
end $$;
drop trigger if exists signal_touch on public.signals;
create trigger signal_touch before update on public.signals for each row execute function public.on_signal();

create or replace function public.on_signal_push() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' or new.status is distinct from old.status then
    perform public.notify_push(jsonb_build_object('type', 'signal', 'event', lower(tg_op), 'record', to_jsonb(new)));
  end if;
  return new;
end $$;
drop trigger if exists signal_push on public.signals;
create trigger signal_push after insert or update on public.signals for each row execute function public.on_signal_push();

-- 4) DIARIO DE OPERACIONES CONECTADO A METATRADER
create or replace function public.pip_size(s text) returns numeric language sql immutable as $$
  select case
    when upper(s) like 'XAU%' or upper(s) like 'GOLD%' then 0.1
    when upper(s) like 'XAG%' or upper(s) like 'SILVER%' then 0.01
    when upper(s) like 'BTC%' or upper(s) like 'ETH%' then 1
    when upper(s) like '%OIL%' or upper(s) like 'XTI%' or upper(s) like 'WTI%' or upper(s) like 'XBR%' then 0.01
    when upper(s) like 'DXY%' or upper(s) like 'USDX%' then 0.01
    when upper(s) like '%JPY%' then 0.01
    when upper(s) ~ '^(US30|US500|NAS|SPX|GER|DE40|UK100|JP225|US100)' then 1
    else 0.0001 end;
$$;

create table if not exists public.trades (
  id bigserial primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  account text not null default 'manual',
  ticket bigint,
  symbol text not null,
  side text not null check (side in ('compra', 'venta')),
  lots numeric not null default 0,
  open_time timestamptz, close_time timestamptz not null default now(),
  open_price numeric, close_price numeric, sl numeric, tp numeric,
  profit numeric not null default 0,
  pips numeric,
  source text not null default 'manual' check (source in ('ea', 'manual')),
  note text check (char_length(note) <= 1000),
  created_at timestamptz not null default now(),
  unique (user_id, account, ticket)
);
create index if not exists trades_user_close on public.trades (user_id, close_time);
alter table public.trades enable row level security;
drop policy if exists "ver mis operaciones" on public.trades;
create policy "ver mis operaciones" on public.trades for select to authenticated using (user_id = auth.uid() or public.is_admin());
drop policy if exists "añadir operación manual" on public.trades;
create policy "añadir operación manual" on public.trades for insert to authenticated with check (user_id = auth.uid() and source = 'manual');
drop policy if exists "editar mis operaciones" on public.trades;
create policy "editar mis operaciones" on public.trades for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "borrar mis manuales" on public.trades;
create policy "borrar mis manuales" on public.trades for delete to authenticated using (user_id = auth.uid() and source = 'manual');
grant select, insert, update, delete on public.trades to authenticated;
grant usage, select on sequence public.trades_id_seq to authenticated;

-- las operaciones que llegan de MetaTrader no se pueden falsear: solo se puede cambiar la nota
create or replace function public.trades_guard() returns trigger language plpgsql as $$
declare n text;
begin
  if tg_op = 'UPDATE' and current_user = 'authenticated' then
    if old.source = 'ea' then n := new.note; new := old; new.note := n; end if;
    new.user_id := old.user_id; new.source := old.source;
  end if;
  if new.pips is null and new.open_price is not null and new.close_price is not null then
    new.pips := round((new.close_price - new.open_price) / public.pip_size(new.symbol) * (case when new.side = 'compra' then 1 else -1 end), 1);
  end if;
  return new;
end $$;
drop trigger if exists trades_guard on public.trades;
create trigger trades_guard before insert or update on public.trades for each row execute function public.trades_guard();

create table if not exists public.mt_accounts (
  user_id uuid not null references auth.users (id) on delete cascade,
  account text not null, server text, balance numeric, equity numeric, currency text,
  updated_at timestamptz not null default now(),
  primary key (user_id, account)
);
alter table public.mt_accounts enable row level security;
drop policy if exists "ver mis cuentas" on public.mt_accounts;
create policy "ver mis cuentas" on public.mt_accounts for select to authenticated using (user_id = auth.uid() or public.is_admin());
grant select on public.mt_accounts to authenticated;

create table if not exists public.journal_keys (
  user_id uuid primary key references auth.users (id) on delete cascade,
  token text not null unique,
  created_at timestamptz not null default now()
);
alter table public.journal_keys enable row level security;  -- solo se lee con las funciones de abajo

create or replace function public.my_journal_key(p_new boolean default false) returns text
language plpgsql security definer set search_path = public as $$
declare t text;
begin
  if auth.uid() is null then raise exception 'Inicia sesión primero'; end if;
  if not public.has_access('diario') then raise exception 'No tienes acceso al diario'; end if;
  select token into t from public.journal_keys where user_id = auth.uid();
  if t is null or p_new then
    t := 'fr_' || encode(sha256((gen_random_uuid()::text || clock_timestamp()::text || random()::text)::bytea), 'hex');
    t := left(t, 43);
    insert into public.journal_keys (user_id, token) values (auth.uid(), t)
      on conflict (user_id) do update set token = excluded.token, created_at = now();
  end if;
  return t;
end $$;
revoke all on function public.my_journal_key(boolean) from public, anon;
grant execute on function public.my_journal_key(boolean) to authenticated;

-- lo llama el robot FortunaDiario desde MetaTrader con la clave personal del usuario
create or replace function public.push_trades(p_token text, p_account text, p_server text default null, p_balance numeric default null,
                                              p_equity numeric default null, p_currency text default null, p_deals jsonb default '[]')
returns int language plpgsql security definer set search_path = public as $$
declare uid uuid; n int := 0;
begin
  select user_id into uid from public.journal_keys where token = p_token;
  if uid is null then raise exception 'Clave del diario incorrecta'; end if;
  if coalesce(p_account, '') !~ '^[0-9]{3,15}$' then raise exception 'Cuenta no válida'; end if;
  insert into public.mt_accounts (user_id, account, server, balance, equity, currency, updated_at)
    values (uid, p_account, left(p_server, 80), p_balance, p_equity, left(p_currency, 8), now())
    on conflict (user_id, account) do update set server = excluded.server, balance = excluded.balance, equity = excluded.equity,
      currency = excluded.currency, updated_at = now();
  if jsonb_typeof(p_deals) = 'array' and jsonb_array_length(p_deals) > 0 then
    insert into public.trades (user_id, account, ticket, symbol, side, lots, open_time, close_time, open_price, close_price, sl, tp, profit, source)
      select uid, p_account, (x ->> 'k')::bigint, left(x ->> 's', 20), case when x ->> 'd' = 'sell' then 'venta' else 'compra' end,
             (x ->> 'v')::numeric, to_timestamp((x ->> 'ot')::float8), to_timestamp((x ->> 'ct')::float8),
             (x ->> 'op')::numeric, (x ->> 'cp')::numeric, nullif((x ->> 'sl')::numeric, 0), nullif((x ->> 'tp')::numeric, 0), (x ->> 'p')::numeric, 'ea'
      from (select x from jsonb_array_elements(p_deals) x limit 500) q
    on conflict (user_id, account, ticket) do update set profit = excluded.profit, close_time = excluded.close_time,
      close_price = excluded.close_price, lots = excluded.lots, sl = excluded.sl, tp = excluded.tp;
    get diagnostics n = row_count;
  end if;
  return n;
end $$;
revoke all on function public.push_trades(text, text, text, numeric, numeric, text, jsonb) from public;
grant execute on function public.push_trades(text, text, text, numeric, numeric, text, jsonb) to anon, authenticated;

-- 5) LIGA DE RETOS
create table if not exists public.challenges (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 3 and 60),
  description text check (char_length(description) <= 300),
  icon text not null default '🏆',
  kind text not null check (kind in ('beneficio', 'racha', 'dias_verdes', 'winrate', 'con_sl', 'operaciones', 'manual')),
  target numeric not null default 1,
  min_trades int not null default 0,
  xp int not null default 100 check (xp between 0 and 10000),
  starts_at timestamptz not null default now(),
  ends_at timestamptz not null,
  created_at timestamptz not null default now()
);
create table if not exists public.challenge_joins (
  challenge_id uuid not null references public.challenges (id) on delete cascade,
  user_id uuid not null references auth.users (id) on delete cascade,
  joined_at timestamptz not null default now(),
  manual_done boolean not null default false,
  primary key (challenge_id, user_id)
);
create table if not exists public.xp_awards (
  id bigserial primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  xp int not null, reason text not null check (char_length(reason) <= 120),
  created_at timestamptz not null default now()
);
alter table public.challenges enable row level security;
alter table public.challenge_joins enable row level security;
alter table public.xp_awards enable row level security;
drop policy if exists "ver retos" on public.challenges;
create policy "ver retos" on public.challenges for select to authenticated using (public.has_access('liga'));
drop policy if exists "admin retos" on public.challenges;
create policy "admin retos" on public.challenges for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "ver inscritos" on public.challenge_joins;
create policy "ver inscritos" on public.challenge_joins for select to authenticated using (public.has_access('liga'));
drop policy if exists "apuntarme" on public.challenge_joins;
create policy "apuntarme" on public.challenge_joins for insert to authenticated with check (user_id = auth.uid() and manual_done = false and public.has_access('liga'));
drop policy if exists "borrarme" on public.challenge_joins;
create policy "borrarme" on public.challenge_joins for delete to authenticated using (user_id = auth.uid() or public.is_admin());
drop policy if exists "admin valida retos" on public.challenge_joins;
create policy "admin valida retos" on public.challenge_joins for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "ver xp" on public.xp_awards;
create policy "ver xp" on public.xp_awards for select to authenticated using (public.has_access('liga'));
drop policy if exists "admin da xp" on public.xp_awards;
create policy "admin da xp" on public.xp_awards for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.challenges, public.challenge_joins, public.xp_awards to authenticated;
grant usage, select on sequence public.xp_awards_id_seq to authenticated;

-- progreso de un usuario en un reto (solo cuentan las operaciones verificadas que llegan de MetaTrader)
create or replace function public.challenge_value(p_ch uuid, p_user uuid) returns numeric
language plpgsql stable security definer set search_path = public as $$
declare c public.challenges; v numeric := 0; tot int; w int; bal numeric; since numeric; win numeric; best int := 0; cur int := 0; t record;
begin
  select * into c from public.challenges where id = p_ch;
  if c.id is null then return 0; end if;
  if c.kind = 'manual' then
    select case when manual_done then 1 else 0 end into v from public.challenge_joins where challenge_id = p_ch and user_id = p_user;
    return coalesce(v, 0);
  end if;
  select count(*), count(*) filter (where profit > 0), coalesce(sum(profit), 0) into tot, w, win
    from public.trades where user_id = p_user and source = 'ea' and close_time >= c.starts_at and close_time <= least(c.ends_at, now());
  if c.kind = 'operaciones' then return tot; end if;
  if tot < c.min_trades then return 0; end if;
  if c.kind = 'winrate' then return case when tot > 0 then round(100.0 * w / tot, 1) else 0 end; end if;
  if c.kind = 'con_sl' then
    return case when tot > 0 then round(100.0 * (select count(*) from public.trades where user_id = p_user and source = 'ea' and sl is not null
      and close_time >= c.starts_at and close_time <= least(c.ends_at, now())) / tot, 1) else 0 end;
  end if;
  if c.kind = 'dias_verdes' then
    select count(*) into v from (select date_trunc('day', close_time) d, sum(profit) s from public.trades
      where user_id = p_user and source = 'ea' and close_time >= c.starts_at and close_time <= least(c.ends_at, now()) group by 1) q where s > 0;
    return v;
  end if;
  if c.kind = 'racha' then
    for t in select profit from public.trades where user_id = p_user and source = 'ea' and close_time >= c.starts_at and close_time <= least(c.ends_at, now()) order by close_time loop
      if t.profit > 0 then cur := cur + 1; best := greatest(best, cur); else cur := 0; end if;
    end loop;
    return best;
  end if;
  if c.kind = 'beneficio' then
    select balance into bal from public.mt_accounts where user_id = p_user order by updated_at desc limit 1;
    select coalesce(sum(profit), 0) into since from public.trades where user_id = p_user and source = 'ea' and close_time >= c.starts_at;
    if bal is null or bal - since <= 0 then return 0; end if;
    return round(100.0 * win / (bal - since), 2);
  end if;
  return 0;
end $$;

create or replace function public.league_challenge(p_ch uuid)
returns table (user_id uuid, alias text, avatar_url text, value numeric, done boolean, joined_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
declare tg numeric;
begin
  if not public.has_access('liga') then raise exception 'Sin acceso a la liga'; end if;
  select target into tg from public.challenges where id = p_ch;
  return query select j.user_id, p.alias, p.avatar_url, v.val, v.val >= tg, j.joined_at
    from public.challenge_joins j
    join public.profiles p on p.id = j.user_id
    cross join lateral (select public.challenge_value(p_ch, j.user_id) as val) v
    where j.challenge_id = p_ch
    order by v.val desc, j.joined_at;
end $$;

create or replace function public.league_ranking()
returns table (user_id uuid, alias text, avatar_url text, xp bigint, retos bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_access('liga') then raise exception 'Sin acceso a la liga'; end if;
  return query
    with done as (
      select j.user_id, c.xp from public.challenge_joins j join public.challenges c on c.id = j.challenge_id
      where public.challenge_value(c.id, j.user_id) >= c.target
    ), tot as (
      select d.user_id, sum(d.xp)::bigint xp, count(*)::bigint retos from done d group by d.user_id
      union all
      select a.user_id, sum(a.xp)::bigint, 0::bigint from public.xp_awards a group by a.user_id
    )
    select t.user_id, p.alias, p.avatar_url, sum(t.xp)::bigint, sum(t.retos)::bigint
    from tot t join public.profiles p on p.id = t.user_id
    group by t.user_id, p.alias, p.avatar_url
    order by 4 desc;
end $$;
grant execute on function public.league_challenge(uuid), public.league_ranking() to authenticated;
revoke all on function public.challenge_value(uuid, uuid) from public, anon;
grant execute on function public.challenge_value(uuid, uuid) to authenticated;
