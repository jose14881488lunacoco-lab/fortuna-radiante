# Instaladores de Fortuna Radiante para Android e iPhone

La carpeta `movil/` convierte la app en una app nativa (con Capacitor) con tu logo como icono y pantalla de inicio.

**Antes de empezar:** publica el servidor (`server/`) en una dirección HTTPS, por ejemplo `https://app.fortunaradiante.com`. La app instalada se conecta a esa dirección para los precios reales, Fortunaty, el chat y la liga. Sin servidor, la app funciona igual pero en **modo demo**, con datos simulados.

---

## Android: el archivo .apk

No necesitas instalar nada en tu ordenador: GitHub fabrica el instalador gratis en la nube.

1. **Crea una cuenta en GitHub** (https://github.com) y un repositorio **privado**, por ejemplo `fortuna-radiante`.
2. **Sube todo el contenido del zip**: botón *Add file → Upload files* y arrastra las carpetas `server`, `movil` y `.github` y los archivos `.md`.
   - La carpeta `.github` está oculta: en Mac pulsa `Cmd + Mayús + .` para verla; en Windows, en el Explorador, activa *Vista → Elementos ocultos*.
3. **Indica tu servidor** (opcional, si no, queda en modo demo): *Settings → Secrets and variables → Actions → pestaña Variables → New variable*: nombre `FR_API_URL`, valor `https://app.tudominio.com`.
4. **Fabrica el instalador**: pestaña *Actions → Android · instalador APK → Run workflow*. Tarda unos 10 minutos.
5. **Descárgalo**: entra en la ejecución terminada → apartado *Artifacts* → `FortunaRadiante-Android`. Dentro está **`FortunaRadiante.apk`**.
6. **Instálalo en el móvil**: envía el .apk al teléfono (WhatsApp, Telegram, Google Drive o cable), ábrelo y acepta *Permitir instalar aplicaciones de esta fuente*.

Cada vez que cambies algo en `server/public` o `movil` y lo subas, GitHub vuelve a fabricar el APK solo.

### Para publicarla en Google Play

Google Play pide la app **firmada** en formato `.aab` y una cuenta de Google Play Console (pago único).

1. Crea tu llave de firma una sola vez (guárdala muy bien: sin ella no podrás actualizar la app):
   ```bash
   keytool -genkey -v -keystore fortuna.jks -alias fortuna -keyalg RSA -keysize 2048 -validity 10000
   base64 -i fortuna.jks | pbcopy        # Mac: copia la llave en texto
   ```
2. En GitHub, *Settings → Secrets and variables → Actions → Secrets*, añade:
   `ANDROID_KEYSTORE_BASE64` (el texto copiado), `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` (`fortuna`) y `ANDROID_KEY_PASSWORD`.
3. Vuelve a lanzar el proceso: en *Artifacts* aparecerán también `FortunaRadiante-GooglePlay.aab` (para subir a Play Console) y `FortunaRadiante-firmada.apk`.

---

## iPhone

Apple no permite instalar apps en un iPhone con un archivo suelto como en Android. Hay tres caminos:

### A) Sin Apple Developer, ya mismo: instalarla desde Safari
Con el servidor publicado en HTTPS, abre la dirección en **Safari** → botón **Compartir** → **Añadir a pantalla de inicio**. Queda con tu icono, a pantalla completa y con el mismo aspecto. Es la forma más rápida de dársela a tus usuarios.

### B) App de verdad para tus usuarios: TestFlight y App Store
Necesitas una cuenta del **Apple Developer Program** (cuota anual).

1. En https://appstoreconnect.apple.com crea la app con el identificador **`com.fortunaradiante.app`**.
2. En *Usuarios y acceso → Integraciones → App Store Connect API*, crea una llave con rol **Admin** y descarga el archivo `.p8`.
3. En GitHub, *Settings → Secrets and variables → Actions → Secrets*, añade:
   - `APPLE_TEAM_ID`: tu Team ID (está en developer.apple.com → Membership)
   - `ASC_KEY_ID` y `ASC_ISSUER_ID`: aparecen junto a la llave creada
   - `ASC_KEY_P8_BASE64`: el contenido del `.p8` en base64 (`base64 -i AuthKey_XXXX.p8 | pbcopy`)
4. *Actions → iPhone · TestFlight → Run workflow*. GitHub compila la app en un Mac y la sube a App Store Connect.
5. En unos minutos aparece en **TestFlight**: invita a tus usuarios por correo o con un enlace público, y se la instalan con la app TestFlight. Cuando quieras, envíala a revisión para el App Store.

### C) Con un Mac propio y Xcode
```bash
cd movil
npm install
FR_API_URL=https://app.tudominio.com npm run ios
```
Se abre Xcode: elige tu equipo en *Signing & Capabilities*, conecta el iPhone y pulsa ▶. Con un Apple ID gratuito funciona, pero la instalación caduca a los 7 días.

---

## Requisitos de las tiendas que ya cumple la app

- Opción **Eliminar mi cuenta** dentro de la app (*Más → Mi cuenta*), que Apple y Google exigen si hay registro.
- Avisos de que la app es informativa y no da asesoramiento financiero.

Te faltará preparar: **política de privacidad** (una página web), capturas de pantalla, descripción, y en Google Play el formulario de *Seguridad de los datos*. Las apps relacionadas con trading suelen revisarse con más detalle: deja claro que la app no ejecuta operaciones ni gestiona dinero.
