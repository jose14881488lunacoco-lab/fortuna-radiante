// Fortuna Radiante · función "notify": envía las notificaciones push a los móviles.
// Supabase → Edge Functions → Deploy a new function → Via Editor → nombre: notify → pega este código → Deploy.
// Después, en sus ajustes, desactiva "Enforce JWT verification" (la protege NOTIFY_TOKEN).
// Secretos necesarios (Edge Functions → Secrets): VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, NOTIFY_TOKEN
// y, para la app de Android (APK), FCM_SERVICE_ACCOUNT con el JSON de la cuenta de servicio de Firebase.
import webpush from "npm:web-push@3.6.7";
import { createClient } from "npm:@supabase/supabase-js@2";

const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
webpush.setVapidDetails("mailto:avisos@fortunaradiante.app", Deno.env.get("VAPID_PUBLIC_KEY")!, Deno.env.get("VAPID_PRIVATE_KEY")!);


// ---------- Firebase Cloud Messaging (app de Android) ----------
const b64url = (b: Uint8Array | string) => btoa(typeof b === "string" ? b : String.fromCharCode(...b)).replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
let fcmCache: { token: string; project: string; exp: number } | null = null;
async function fcmAuth() {
  const raw = Deno.env.get("FCM_SERVICE_ACCOUNT"); if (!raw) return null;
  if (fcmCache && fcmCache.exp > Date.now() + 60_000) return fcmCache;
  const sa = JSON.parse(raw), now = Math.floor(Date.now() / 1000);
  const unsigned = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" })) + "." + b64url(JSON.stringify({ iss: sa.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging", aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600 }));
  const der = Uint8Array.from(atob(sa.private_key.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "")), (ch) => ch.charCodeAt(0));
  const key = await crypto.subtle.importKey("pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = new Uint8Array(await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(unsigned)));
  const r = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: "grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=" + unsigned + "." + b64url(sig) });
  const j = await r.json(); if (!j.access_token) { console.error("FCM auth", j); return null; }
  fcmCache = { token: j.access_token, project: sa.project_id, exp: Date.now() + 3_500_000 }; return fcmCache;
}
async function sendFcm(token: string, p: Record<string, string>) {
  const a = await fcmAuth(); if (!a) return "sin-config";
  const r = await fetch(`https://fcm.googleapis.com/v1/projects/${a.project}/messages:send`, { method: "POST", headers: { Authorization: "Bearer " + a.token, "Content-Type": "application/json" }, body: JSON.stringify({ message: { token, notification: { title: p.title, body: p.body }, data: { url: p.url ?? "#inicio" }, android: { priority: "HIGH", notification: { tag: p.tag, channel_id: "avisos", color: "#D9A21B", icon: "ic_stat_notify", default_sound: true } } } }) });
  if (r.ok) return "ok";
  const t = await r.text(); return r.status === 404 || t.includes("UNREGISTERED") || t.includes("INVALID_ARGUMENT") && t.includes("token") ? "baja" : "error";
}

type Sub = { endpoint: string; user_id: string; p256dh: string; auth: string; chat_pref: string };
const CANAL: Record<string, string> = { general: "General", xauusd: "XAUUSD", analisis: "Análisis", mentorias: "Mentorías", directo: "Directo" };

Deno.serve(async (req) => {
  if (req.headers.get("x-notify-token") !== Deno.env.get("NOTIFY_TOKEN")) return new Response("No autorizado", { status: 401 });
  const { type, record, event } = await req.json();
  let targets: Sub[] = [];
  let payload: Record<string, string> = {};

  if (type === "message") {
    const { data: author } = await sb.from("profiles").select("alias").eq("id", record.user_id).single();
    const { data: subs } = await sb.from("push_subscriptions").select("*").neq("user_id", record.user_id);
    const list = (subs ?? []) as Sub[];
    const ids = [...new Set(list.map((s) => s.user_id))];
    const { data: profs } = ids.length ? await sb.from("profiles").select("id,alias").in("id", ids) : { data: [] };
    const alias = new Map((profs ?? []).map((p: { id: string; alias: string }) => [p.id, p.alias.toLowerCase()]));
    const body = String(record.body ?? "").toLowerCase();
    const mentioned = (uid: string) => !!alias.get(uid) && body.includes("@" + alias.get(uid));
    targets = list.filter((s) => s.chat_pref === "all" || (s.chat_pref === "mentions" && mentioned(s.user_id)));
    const texto = record.kind === "image" ? "📷 Foto" : record.kind === "audio" ? "🎤 Audio" : String(record.body ?? "").slice(0, 140);
    payload = { title: `${author?.alias ?? "Comunidad"} · #${CANAL[record.channel] ?? record.channel}`, body: texto, url: "#comunidad", tag: "chat-" + record.channel };
  } else if (type === "alert") {
    const { data: subs } = await sb.from("push_subscriptions").select("*").eq("user_id", record.user_id);
    targets = (subs ?? []) as Sub[];
    payload = { title: `🔔 ${record.symbol} ${record.above ? "ha subido a" : "ha bajado a"} ${record.price}`, body: `Precio actual: ${record.bid}`, url: "#grafico", tag: "alerta-" + record.id };
  } else if (type === "signal") {
    // señal nueva o cambio de estado: a todos los que tienen acceso a Señales (y a los admins)
    const { data: acc } = await sb.from("access").select("user_id, sections").eq("status", "aprobado");
    const { data: adm } = await sb.from("admins").select("user_id");
    const ok = new Set([...(acc ?? []).filter((a: { sections: Record<string, boolean> }) => a.sections && a.sections.senales).map((a: { user_id: string }) => a.user_id), ...(adm ?? []).map((a: { user_id: string }) => a.user_id)]);
    const { data: subs } = await sb.from("push_subscriptions").select("*");
    targets = ((subs ?? []) as Sub[]).filter((s) => ok.has(s.user_id) && s.user_id !== record.created_by);
    const lado = record.side === "venta" ? "🔴 VENTA" : "🟢 COMPRA";
    const est: Record<string, string> = { tp1: "✅ TP1 alcanzado", tp2: "✅ TP2 alcanzado", tp3: "🏆 TP3 alcanzado", sl: "❌ Stop loss", be: "⚖️ A break even", cerrada: "Cerrada", cancelada: "Cancelada", activa: "Activada", pendiente: "Pendiente" };
    const ev = event;
    payload = ev === "insert"
      ? { title: `📡 Señal Fortuna · ${lado} ${record.symbol}`, body: `Entrada ${record.entry}${record.sl ? " · SL " + record.sl : ""}${record.tp1 ? " · TP " + record.tp1 : ""}`, url: "#senales", tag: "senal-" + record.id }
      : { title: `📡 ${record.symbol} ${lado.split(" ")[1]} · ${est[record.status] ?? record.status}`, body: record.result_pips != null ? `Resultado: ${record.result_pips} pips` : "Señal actualizada", url: "#senales", tag: "senal-" + record.id };
  } else if (type === "econ" || type === "live") {
    // dato económico fuerte en 15 min, o directo empezando: a todos los miembros aprobados y admins
    const sec = type === "econ" ? "mercado" : "comunidad";
    const { data: acc } = await sb.from("access").select("user_id, sections").eq("status", "aprobado");
    const { data: adm } = await sb.from("admins").select("user_id");
    const ok = new Set([...(acc ?? []).filter((a: { sections: Record<string, boolean> }) => a.sections && a.sections[sec]).map((a: { user_id: string }) => a.user_id), ...(adm ?? []).map((a: { user_id: string }) => a.user_id)]);
    const { data: subs } = await sb.from("push_subscriptions").select("*");
    targets = ((subs ?? []) as Sub[]).filter((s) => ok.has(s.user_id));
    payload = type === "econ"
      ? { title: `⏰ En 15 min: ${record.title} (${record.country})`, body: `Previsión ${record.forecast || "—"} · Anterior ${record.previous || "—"}. Puede mover mucho el oro: cuidado con el riesgo.`, url: "#mercado", tag: "econ-" + record.id }
      : { title: `🔴 Directo ahora · ${record.title || "Fortuna Radiante"}`, body: "Entra ya: análisis del oro en directo con el equipo.", url: "#comunidad", tag: "directo" };
  } else if (type === "support") {
    // chat de soporte: si escribe el admin, a esa persona; si escribe la persona, a los administradores
    const { data: subs } = await sb.from("push_subscriptions").select("*");
    if (record.from_admin) targets = ((subs ?? []) as Sub[]).filter((s) => s.user_id === record.user_id);
    else { const { data: adm } = await sb.from("admins").select("user_id"); const ok = new Set((adm ?? []).map((a: { user_id: string }) => a.user_id)); targets = ((subs ?? []) as Sub[]).filter((s) => ok.has(s.user_id)); }
    payload = record.from_admin
      ? { title: "💬 Soporte Fortuna Radiante", body: String(record.body || ""), url: "#soporte", tag: "soporte" }
      : { title: `💬 Soporte · ${record.alias || "Nuevo usuario"}`, body: String(record.body || ""), url: "#soporte", tag: "soporte-" + record.user_id };
  } else if (type === "feed") {
    // el robot de precios lleva más de 10 min sin enviar: solo a los administradores
    const { data: adm } = await sb.from("admins").select("user_id");
    const ok = new Set((adm ?? []).map((a: { user_id: string }) => a.user_id));
    const { data: subs } = await sb.from("push_subscriptions").select("*");
    targets = ((subs ?? []) as Sub[]).filter((s) => ok.has(s.user_id));
    payload = { title: "⚠️ El robot de precios se ha parado", body: "MetaTrader lleva más de 10 minutos sin enviar precios. Revisa que esté abierto (o el VPS) y que el robot siga en el gráfico.", url: "#inicio", tag: "robot" };
  } else if (type === "weekly") {
    const { data: acc } = await sb.from("access").select("user_id").eq("status", "aprobado");
    const { data: adm } = await sb.from("admins").select("user_id");
    const ok = new Set([...(acc ?? []).map((a: { user_id: string }) => a.user_id), ...(adm ?? []).map((a: { user_id: string }) => a.user_id)]);
    const { data: subs } = await sb.from("push_subscriptions").select("*");
    targets = ((subs ?? []) as Sub[]).filter((s) => ok.has(s.user_id));
    payload = { title: "📊 " + (record.title || "Resumen semanal"), body: String(record.body || "").slice(0, 180), url: "#noticias", tag: "semanal" };
  } else {
    return new Response("Tipo desconocido", { status: 400 });
  }

  let sent = 0;
  await Promise.all(targets.map(async (s) => {
    if (s.endpoint.startsWith("fcm:")) {
      const res = await sendFcm(s.endpoint.slice(4), payload);
      if (res === "ok") sent++; else if (res === "baja") await sb.from("push_subscriptions").delete().eq("endpoint", s.endpoint);
      return;
    }
    try {
      await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, JSON.stringify(payload), { TTL: 3600 });
      sent++;
    } catch (e) {
      const code = (e as { statusCode?: number }).statusCode;
      if (code === 404 || code === 410) await sb.from("push_subscriptions").delete().eq("endpoint", s.endpoint); // móvil dado de baja
    }
  }));
  return new Response(JSON.stringify({ sent }), { headers: { "Content-Type": "application/json" } });
});
