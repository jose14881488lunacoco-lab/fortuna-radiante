// Fortuna Radiante · función "noticias": lee el canal público de Telegram (con permiso de su dueño),
// traduce las publicaciones nuevas al español y las guarda en la tabla news.
// La llama la base de datos cada 10 minutos (x-notify-token) o el admin con «Actualizar ahora».
// Secretos: ANTHROPIC_API_KEY (el de Fortunaty) y NOTIFY_TOKEN (el de las notificaciones).
import { createClient } from "npm:@supabase/supabase-js@2";

const MODEL = Deno.env.get("NEWS_MODEL") || "claude-haiku-5-5";
const TOPICS = ["oro", "dolar", "bolsa", "cripto", "petroleo", "bancos", "economia", "geopolitica", "mercados"];
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...cors, "content-type": "application/json" } });

function clean(html: string) {
  return html.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&#039;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n)).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/\n{3,}/g, "\n\n").trim();
}
function parse(html: string, channel: string) {
  const out: { id: string; post_id: number; text: string; posted_at: string; has_media: boolean; link: string }[] = [];
  const parts = html.split('data-post="').slice(1);
  for (const p of parts) {
    const ref = p.slice(0, p.indexOf('"')); const [ch, num] = ref.split("/");
    if (!num || ch.toLowerCase() !== channel.toLowerCase()) continue;
    const tm = p.match(/<div class="tgme_widget_message_text[^"]*"[^>]*>([\s\S]*?)<\/div>/);
    const text = tm ? clean(tm[1]) : "";
    const dt = p.match(/<time[^>]*datetime="([^"]+)"/);
    if (!text) continue;
    out.push({ id: ref, post_id: +num, text, posted_at: dt ? new Date(dt[1]).toISOString() : new Date().toISOString(), has_media: /tgme_widget_message_(photo|video)/.test(p), link: `https://t.me/${ch}/${num}` });
  }
  return out;
}

// trae y traduce las publicaciones nuevas de UN canal; devuelve cuántas guardó o un texto de aviso
async function oneChannel(sb: ReturnType<typeof createClient>, KEY: string, channel: string): Promise<number | string> {
  const r = await fetch(`https://t.me/s/${channel}`, { headers: { "user-agent": "Mozilla/5.0 (FortunaRadiante noticias)", "accept-language": "es,en" } });
  if (!r.ok) return `Telegram respondió ${r.status}. ¿El canal es público?`;
  const posts = parse(await r.text(), channel);
  if (!posts.length) return "No se encontraron publicaciones con texto. ¿El canal es público y el nombre es correcto?";
  const { data: have } = await sb.from("news").select("id").in("id", posts.map((p) => p.id));
  const known = new Set((have ?? []).map((x: { id: string }) => x.id));
  const fresh = posts.filter((p) => !known.has(p.id)).slice(-15);
  if (!fresh.length) return 0;
  const prompt = `Traduce al español de España estas publicaciones de un canal de noticias financieras. Tono natural y claro para traders. No añadas ni quites información; respeta cifras, tickers, horas y emojis.
Para cada una devuelve: "id" (igual), "titulo" (titular corto en español, máx. 90 caracteres), "texto" (traducción completa) y "tema" (uno de: ${TOPICS.join(", ")}).
Responde SOLO con un array JSON válido, sin texto antes ni después.
${JSON.stringify(fresh.map((p) => ({ id: p.id, texto: p.text.slice(0, 3000) })))}`;
  const ar = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers: { "x-api-key": KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" }, body: JSON.stringify({ model: MODEL, max_tokens: 8000, messages: [{ role: "user", content: prompt }] }) });
  const aj = await ar.json().catch(() => ({}));
  if (!ar.ok) return "No se pudo traducir: " + ((aj.error && aj.error.message) || ar.status);
  const raw = (aj.content || []).filter((b: { type: string }) => b.type === "text").map((b: { text: string }) => b.text).join("").replace(/^```(json)?|```$/gm, "").trim();
  let tr: { id: string; titulo: string; texto: string; tema: string }[] = [];
  try { tr = JSON.parse(raw.slice(raw.indexOf("["), raw.lastIndexOf("]") + 1)); } catch (_) { return "La traducción no llegó en el formato esperado. Se reintentará en 10 minutos."; }
  const byId = new Map(tr.map((t) => [t.id, t]));
  const rows = fresh.map((p) => { const t = byId.get(p.id); return t ? { id: p.id, channel, post_id: p.post_id, posted_at: p.posted_at, title: String(t.titulo || "").slice(0, 140), body: String(t.texto || p.text), body_orig: p.text, topic: TOPICS.includes(t.tema) ? t.tema : "mercados", has_media: p.has_media, link: p.link } : null; }).filter(Boolean);
  if (rows.length) { const { error } = await sb.from("news").upsert(rows); if (error) return error.message; }
  return rows.length;
}

// calendario económico de la semana (fuente pública de Forex Factory), como mucho una vez por hora
async function syncCalendar(sb: ReturnType<typeof createClient>, force: boolean) {
  try {
    if (!force) {
      const { data: last } = await sb.from("econ_events").select("updated_at").order("updated_at", { ascending: false }).limit(1);
      if (last && last.length && Date.now() - new Date(last[0].updated_at).getTime() < 55 * 60e3) return "reciente";
    }
    const r = await fetch("https://nfs.faireconomy.media/ff_calendar_thisweek.json", { headers: { "user-agent": "Mozilla/5.0 (FortunaRadiante calendario)" } });
    if (!r.ok) return "error " + r.status;
    const list = await r.json() as { title: string; country: string; date: string; impact: string; forecast?: string; previous?: string }[];
    const now = new Date().toISOString();
    const rows = list.filter((e) => e && e.title && e.date && ["High", "Medium"].includes(e.impact)).map((e) => ({
      id: `${e.country}|${e.date}|${e.title}`.slice(0, 200), title: e.title, country: e.country, impact: e.impact,
      at: new Date(e.date).toISOString(), forecast: e.forecast || null, previous: e.previous || null, updated_at: now,
    }));
    if (rows.length) await sb.from("econ_events").upsert(rows, { onConflict: "id", ignoreDuplicates: false });
    return rows.length;
  } catch (e) { return "error " + (e as Error).message; }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  let body: { source?: string; calendar?: boolean } = {};
  try { body = await req.json(); } catch (_) { /* sin cuerpo */ }
  // permiso: la base de datos (token) o el administrador desde la app
  let ok = !!req.headers.get("x-notify-token") && req.headers.get("x-notify-token") === Deno.env.get("NOTIFY_TOKEN");
  const jwt = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!ok && jwt) {
    // 1) con la clave de servicio
    try { const { data: u } = await sb.auth.getUser(jwt); if (u && u.user) { const { data: a } = await sb.from("admins").select("user_id").eq("user_id", u.user.id).maybeSingle(); ok = !!a; } } catch (_) { /* sigue */ }
    // 2) preguntando a la base de datos como el propio usuario (sirve con las claves nuevas de Supabase)
    if (!ok) { try { const key = req.headers.get("apikey") || Deno.env.get("SUPABASE_ANON_KEY") || ""; const us = createClient(Deno.env.get("SUPABASE_URL")!, key, { auth: { persistSession: false }, global: { headers: { Authorization: "Bearer " + jwt } } }); const { data } = await us.rpc("is_admin"); ok = data === true; } catch (_) { /* sigue */ } }
  }
  // el calendario económico es público: cualquiera puede pedir que se refresque (como mucho 1 vez por hora; forzar solo el admin)
  if (body.calendar) return json({ ok: true, calendario: await syncCalendar(sb, ok), admin: ok });
  if (!ok) return json({ error: "No autorizado" }, 401);
  await syncCalendar(sb, false);
  const KEY = Deno.env.get("ANTHROPIC_API_KEY");
  if (!KEY) return json({ error: "Falta ANTHROPIC_API_KEY en los secretos de Supabase (la misma de Fortunaty).", code: "no_key" }, 503);

  const { data: cfg } = await sb.from("app_config").select("value").eq("key", "app").maybeSingle();
  const nw = (cfg && cfg.value && cfg.value.news) || {};
  if (nw.on === false) return json({ ok: true, paused: true });
  const clean = (s: unknown) => String(s || "").replace(/^@|^https?:\/\/t\.me\/(s\/)?/i, "").replace(/\/.*$/, "").trim();
  const channels = [...new Set([clean(nw.channel), clean(nw.channel2)].filter((c) => /^[A-Za-z0-9_]{4,64}$/.test(c)))];
  if (!channels.length) return json({ error: "Escribe el nombre del canal en Noticias → Ajustes de noticias." }, 400);
  let total = 0; const avisos: string[] = [];
  for (const channel of channels) {
    const res = await oneChannel(sb, KEY, channel);
    if (typeof res === "number") total += res; else avisos.push(`@${channel}: ${res}`);
  }
  return json({ ok: true, nuevas: total, aviso: avisos.length ? avisos.join(" · ") : undefined });
});
