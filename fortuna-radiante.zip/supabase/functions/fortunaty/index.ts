// Fortuna Radiante · función "fortunaty": la IA del oro con búsqueda de noticias.
// Necesita el secreto ANTHROPIC_API_KEY (console.anthropic.com). Solo responde a usuarios aprobados con Fortunaty activado (y al admin).
import { createClient } from "npm:@supabase/supabase-js@2";

const MODEL = Deno.env.get("FORTUNATY_MODEL") || "claude-sonnet-5-5";
const PER_HOUR = Number(Deno.env.get("FORTUNATY_PER_HOUR") || 30);
const SYS = `Eres Fortunaty, la inteligencia artificial de la app Fortuna Radiante, especializada en el oro (XAUUSD) y en los mercados relacionados (DXY, Bitcoin, petróleo WTI).
Respondes siempre en español, con tono cercano, claro y profesional, pensado para leerse en el móvil: frases cortas, títulos breves con ###, listas con guiones y cifras concretas tomadas de los DATOS que acompañan a cada pregunta. Máximo unas 250 palabras salvo que pidan más.
Para un análisis técnico usa: ### Resumen · ### Tendencia (H1, H4, D1) · ### Niveles clave · ### Escenarios (alcista y bajista, con qué confirmaría cada uno) · ### Riesgos.
Tienes búsqueda web. Úsala siempre que pregunten por noticias, eventos, datos macro, la Reserva Federal o "qué está pasando": busca noticias recientes del oro y del dólar (prioriza Reuters, Bloomberg, Kitco, FXStreet, Investing.com, CNBC), indica la fecha de cada noticia y explica cómo puede afectar al XAUUSD. No inventes titulares ni cifras.
Nunca garantices resultados ni des órdenes personalizadas de compra o venta; describe escenarios y niveles. Termina los análisis con: "Esto es información, no asesoramiento financiero."
En los DATOS, zonasCompra/zonasVenta vienen del indicador ProZones del usuario como [desde, hasta, temporalidad, FVG o VI, fuerza]: úsalas como zonas de compra y venta. Recuerda que el oro suele moverse al revés que el DXY.`;
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...cors, "content-type": "application/json" } });

async function claude(key: string, body: unknown) {
  const r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" }, body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((j.error && j.error.message) || "Error " + r.status);
  return j;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Método no permitido" }, 405);
  const KEY = Deno.env.get("ANTHROPIC_API_KEY");
  if (!KEY) return json({ error: "Fortunaty no está configurado: falta el secreto ANTHROPIC_API_KEY en Supabase.", code: "no_key" }, 503);
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  const jwt = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  const { data: u } = await sb.auth.getUser(jwt);
  const uid = u && u.user && u.user.id;
  if (!uid) return json({ error: "Inicia sesión para usar Fortunaty." }, 401);
  const { data: adm } = await sb.from("admins").select("user_id").eq("user_id", uid).maybeSingle();
  if (!adm) {
    const { data: ac } = await sb.from("access").select("status, sections").eq("user_id", uid).maybeSingle();
    if (!ac || ac.status !== "aprobado" || !(ac.sections && ac.sections.fortunaty)) return json({ error: "No tienes acceso a Fortunaty. Pídeselo al administrador." }, 403);
    const since = new Date(Date.now() - 3600e3).toISOString();
    const { count } = await sb.from("ai_usage").select("id", { count: "exact", head: true }).eq("user_id", uid).gte("at", since);
    if ((count || 0) >= PER_HOUR) return json({ error: "Has llegado al límite de preguntas por hora. Vuelve en un rato." }, 429);
  }
  await sb.from("ai_usage").insert({ user_id: uid });

  let body: any = {}; try { body = await req.json(); } catch (_) { /* vacío */ }
  let msgs = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
  msgs = msgs.filter((m: any) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim()).map((m: any) => ({ role: m.role, content: m.content.slice(0, 4000) }));
  while (msgs.length && msgs[0].role !== "user") msgs.shift();
  const clean: any[] = []; for (const m of msgs) { if (clean.length && clean[clean.length - 1].role === m.role) clean[clean.length - 1] = m; else clean.push(m); }
  if (!clean.length || clean[clean.length - 1].role !== "user") return json({ error: "Falta la pregunta." }, 400);
  const snap = JSON.stringify(body.snapshot || {}).slice(0, 20000);
  const { data: pr } = await sb.from("prices").select("*").limit(20);
  const extra = pr && pr.length ? `\nPRECIOS EN TIEMPO REAL (Vantage): ${JSON.stringify(pr)}` : "";
  clean[clean.length - 1] = { role: "user", content: `DATOS DE MERCADO ACTUALES (JSON): ${snap}${extra}\n\nPREGUNTA: ${clean[clean.length - 1].content}` };
  try {
    const req2: any = { model: MODEL, max_tokens: 1600, system: SYS, messages: clean, tools: [{ type: "web_search_20250305", name: "web_search", max_uses: 4 }] };
    let j = await claude(KEY, req2), content = [...j.content];
    for (let k = 0; j.stop_reason === "pause_turn" && k < 3; k++) { req2.messages = [...clean, { role: "assistant", content }]; j = await claude(KEY, req2); content = [...content, ...j.content]; }
    const text = content.filter((b: any) => b.type === "text").map((b: any) => b.text).join("").trim();
    const seen = new Set(), sources: any[] = [];
    for (const b of content) for (const c of (b.type === "text" && b.citations) || []) if (c.url && !seen.has(c.url) && /^https:\/\//.test(c.url)) { seen.add(c.url); sources.push({ title: c.title || c.url, url: c.url }); }
    return json({ text: text || "No he podido generar una respuesta. Prueba a reformular la pregunta.", sources: sources.slice(0, 6) });
  } catch (e) {
    console.warn("[fortunaty]", (e as Error).message);
    return json({ error: "Fortunaty no está disponible ahora mismo: " + (e as Error).message }, 502);
  }
});
