-- =====================================================================
-- Fortuna Radiante · Comunidad (registro, perfiles, chat con fotos y audios)
-- Pega TODO este texto en Supabase → SQL Editor → New query → Run.
-- Se puede ejecutar más de una vez sin problema.
-- =====================================================================

-- 1) Perfiles de los miembros (uno por cuenta)
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  alias text not null check (char_length(alias) between 3 and 20),
  avatar_url text,
  bio text not null default '' check (char_length(bio) <= 140),
  role text not null default 'user' check (role in ('user', 'mentor')),
  created_at timestamptz not null default now()
);
create unique index if not exists profiles_alias_lower on public.profiles (lower(alias));
alter table public.profiles enable row level security;
drop policy if exists "perfiles visibles" on public.profiles;
create policy "perfiles visibles" on public.profiles for select using (true);
drop policy if exists "editar mi perfil" on public.profiles;
create policy "editar mi perfil" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Nadie puede hacerse mentor a sí mismo (solo desde el panel de Supabase)
create or replace function public.keep_role() returns trigger language plpgsql as $$
begin
  if new.role is distinct from old.role and current_user not in ('postgres', 'supabase_admin', 'service_role') then
    new.role := old.role;
  end if;
  return new;
end $$;
drop trigger if exists keep_role on public.profiles;
create trigger keep_role before update on public.profiles for each row execute function public.keep_role();

-- Al registrarse se crea su perfil con el alias elegido
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, alias)
  values (new.id, coalesce(nullif(new.raw_user_meta_data ->> 'alias', ''), 'trader_' || substr(new.id::text, 1, 6)));
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- 2) Mensajes del chat
create table if not exists public.messages (
  id bigint generated always as identity primary key,
  channel text not null check (channel in ('general', 'xauusd', 'analisis', 'mentorias')),
  user_id uuid not null references public.profiles (id) on delete cascade,
  kind text not null default 'text' check (kind in ('text', 'image', 'audio')),
  body text check (char_length(body) <= 1000),
  media_url text,
  duration real,
  created_at timestamptz not null default now()
);
create index if not exists messages_channel_id on public.messages (channel, id desc);
alter table public.messages enable row level security;
drop policy if exists "leer mensajes" on public.messages;
create policy "leer mensajes" on public.messages for select to authenticated using (true);
drop policy if exists "escribir mis mensajes" on public.messages;
create policy "escribir mis mensajes" on public.messages for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "borrar mis mensajes" on public.messages;
create policy "borrar mis mensajes" on public.messages for delete to authenticated using (
  auth.uid() = user_id or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'mentor')
);

-- Mensajes en tiempo real
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null; end $$;

-- 3) Fotos de perfil y archivos del chat
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('avatars', 'avatars', true, 2097152, array['image/jpeg', 'image/png', 'image/webp']),
  ('chat', 'chat', true, 10485760, array['image/jpeg', 'image/png', 'image/webp', 'audio/mp4', 'audio/m4a', 'audio/x-m4a', 'audio/aac', 'audio/webm', 'audio/ogg', 'audio/mpeg'])
on conflict (id) do update set public = excluded.public, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;
drop policy if exists "subir a mi carpeta" on storage.objects;
create policy "subir a mi carpeta" on storage.objects for insert to authenticated
  with check (bucket_id in ('avatars', 'chat') and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "cambiar en mi carpeta" on storage.objects;
create policy "cambiar en mi carpeta" on storage.objects for update to authenticated
  using (bucket_id in ('avatars', 'chat') and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "borrar de mi carpeta" on storage.objects;
create policy "borrar de mi carpeta" on storage.objects for delete to authenticated
  using (bucket_id in ('avatars', 'chat') and (storage.foldername(name))[1] = auth.uid()::text);

-- 4) Borrar mi cuenta (lo exigen Apple y Google)
create or replace function public.delete_my_account() returns void language sql security definer set search_path = public as $$
  delete from auth.users where id = auth.uid();
$$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- Listo. Para nombrar a un mentor: Table Editor → profiles → columna role → escribe mentor.
