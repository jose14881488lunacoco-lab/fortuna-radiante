-- =====================================================================
-- Fortuna Radiante · ADMINISTRADOR + AJUSTES DE LA APP
-- Supabase → SQL Editor → New query → pega TODO → cambia tu correo
-- en la ÚLTIMA línea → Run. Se puede ejecutar más de una vez.
-- Antes tienes que haberte registrado en la app con ese correo.
-- =====================================================================

-- 1) Quién es administrador (solo se cambia desde aquí, nunca desde la app)
create table if not exists public.admins (
  user_id uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admins enable row level security;
drop policy if exists "ver admins" on public.admins;
create policy "ver admins" on public.admins for select using (true);

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

-- 2) Ajustes de la app que el admin cambia desde dentro (Beta, anuncio, mentorías, enlaces…)
create table if not exists public.app_config (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.app_config enable row level security;
drop policy if exists "leer ajustes" on public.app_config;
create policy "leer ajustes" on public.app_config for select using (true);
drop policy if exists "admin cambia ajustes" on public.app_config;
create policy "admin cambia ajustes" on public.app_config for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
insert into public.app_config (key, value) values ('app', '{}'::jsonb) on conflict (key) do nothing;

-- 3) Moderación del chat: el admin borra cualquier mensaje y puede bloquear usuarios
drop policy if exists "admin borra mensajes" on public.messages;
create policy "admin borra mensajes" on public.messages for delete to authenticated using (public.is_admin());

create table if not exists public.bans (
  user_id uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.bans enable row level security;
drop policy if exists "ver bloqueos" on public.bans;
create policy "ver bloqueos" on public.bans for select to authenticated using (true);
drop policy if exists "admin bloquea" on public.bans;
create policy "admin bloquea" on public.bans for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
-- un usuario bloqueado no puede escribir en el chat
drop policy if exists "bloqueados no escriben" on public.messages;
create policy "bloqueados no escriben" on public.messages as restrictive for insert to authenticated
  with check (not exists (select 1 from public.bans b where b.user_id = auth.uid()));


-- 5) ACCESO A LA APP: registro → vincular MT5 → el admin comprueba el saldo y aprueba
create table if not exists public.access (
  user_id uuid primary key references auth.users (id) on delete cascade,
  email text, alias text,
  status text not null default 'pendiente' check (status in ('pendiente', 'aprobado', 'rechazado', 'expulsado')),
  broker text, mt5_server text, mt5_login text, investor_pw text, balance numeric, proof_path text,
  note text,
  sections jsonb not null default '{}'::jsonb,
  indicators jsonb not null default '{}'::jsonb,
  submitted_at timestamptz, reviewed_at timestamptz, updated_at timestamptz not null default now()
);
alter table public.access enable row level security;
drop policy if exists "ver mi acceso" on public.access;
create policy "ver mi acceso" on public.access for select to authenticated using (user_id = auth.uid() or public.is_admin());
drop policy if exists "admin gestiona accesos" on public.access;
create policy "admin gestiona accesos" on public.access for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.access to authenticated;

-- al revisar una solicitud se borra la contraseña de inversor (ya no hace falta guardarla)
create or replace function public.access_review() returns trigger language plpgsql as $$
begin
  if new.status is distinct from old.status then
    new.reviewed_at := now();
    if new.status <> 'pendiente' then new.investor_pw := null; end if;
  end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists access_review on public.access;
create trigger access_review before update on public.access for each row execute function public.access_review();

-- el usuario solo puede enviar sus datos de MT5 con esta función (no puede aprobarse a sí mismo)
create or replace function public.submit_access(p_broker text, p_server text, p_login text, p_investor text, p_balance numeric, p_proof text)
returns text language plpgsql security definer set search_path = public as $$
declare st text; uid uuid := auth.uid();
begin
  if uid is null then raise exception 'Inicia sesión primero'; end if;
  select status into st from public.access where user_id = uid;
  if st = 'expulsado' then raise exception 'Tu acceso ha sido retirado por el administrador'; end if;
  if st = 'aprobado' then raise exception 'Tu cuenta ya está aprobada'; end if;
  if coalesce(trim(p_login), '') !~ '^[0-9]{4,12}$' then raise exception 'Número de cuenta MT5 no válido'; end if;
  if coalesce(trim(p_server), '') = '' then raise exception 'Falta el servidor de MT5'; end if;
  if p_proof is not null and p_proof !~ ('^' || uid::text || '/') then raise exception 'Captura no válida'; end if;
  insert into public.access (user_id, email, alias, status, broker, mt5_server, mt5_login, investor_pw, balance, proof_path, note, submitted_at)
  values (uid, (select email from auth.users where id = uid), (select alias from public.profiles where id = uid), 'pendiente',
          left(p_broker, 60), left(trim(p_server), 80), trim(p_login), nullif(left(p_investor, 64), ''), p_balance, p_proof, null, now())
  on conflict (user_id) do update set status = 'pendiente', email = excluded.email, alias = excluded.alias, broker = excluded.broker,
    mt5_server = excluded.mt5_server, mt5_login = excluded.mt5_login, investor_pw = excluded.investor_pw, balance = excluded.balance,
    proof_path = coalesce(excluded.proof_path, public.access.proof_path), note = null, submitted_at = now();
  return 'pendiente';
end $$;
revoke all on function public.submit_access(text, text, text, text, numeric, text) from public, anon;
grant execute on function public.submit_access(text, text, text, text, numeric, text) to authenticated;

create or replace function public.has_access(sec text default null) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_admin() or exists (select 1 from public.access a where a.user_id = auth.uid() and a.status = 'aprobado'
         and (sec is null or coalesce((a.sections ->> sec)::boolean, false)));
$$;
grant execute on function public.has_access(text) to anon, authenticated;

-- capturas del saldo (privadas: solo las ve su dueño y el admin)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('proofs', 'proofs', false, 5242880, array['image/jpeg', 'image/png', 'image/webp']) on conflict (id) do nothing;
drop policy if exists "subir mi captura" on storage.objects;
create policy "subir mi captura" on storage.objects for insert to authenticated
  with check (bucket_id = 'proofs' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "ver capturas" on storage.objects;
create policy "ver capturas" on storage.objects for select to authenticated
  using (bucket_id = 'proofs' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));
drop policy if exists "admin borra capturas" on storage.objects;
create policy "admin borra capturas" on storage.objects for delete to authenticated using (bucket_id = 'proofs' and public.is_admin());

-- 6) Sin acceso aprobado no se lee ni se escribe en la comunidad
drop policy if exists "solo aprobados leen chat" on public.messages;
create policy "solo aprobados leen chat" on public.messages as restrictive for select to anon, authenticated using (public.has_access('comunidad'));
drop policy if exists "solo aprobados escriben" on public.messages;
create policy "solo aprobados escriben" on public.messages as restrictive for insert to authenticated with check (public.has_access('comunidad'));
drop policy if exists "sin registro no ve perfiles" on public.profiles;
create policy "sin registro no ve perfiles" on public.profiles as restrictive for select to anon using (false);

-- 7) Límite de preguntas a Fortunaty (lo usa la función fortunaty)
create table if not exists public.ai_usage (id bigserial primary key, user_id uuid not null, at timestamptz not null default now());
create index if not exists ai_usage_user_at on public.ai_usage (user_id, at);
alter table public.ai_usage enable row level security;

-- 4) Permisos
grant select on public.admins, public.app_config to anon, authenticated;
grant insert, update, delete on public.app_config to authenticated;
grant select, insert, delete on public.bans to authenticated;
grant execute on function public.is_admin() to anon, authenticated;

-- 8) TÚ ERES EL ADMIN: cambia el correo por el que usaste al registrarte en la app
insert into public.admins (user_id) select id from auth.users where lower(email) = lower('TU_CORREO@gmail.com') on conflict do nothing;
