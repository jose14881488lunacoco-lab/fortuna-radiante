-- =====================================================================
-- Fortuna Radiante · ADMINISTRADOR + AJUSTES DE LA APP
-- Supabase → SQL Editor → New query → pega TODO → cambia tu correo
-- en la ÚLTIMA línea → Run. Se puede ejecutar más de una vez.
-- Antes tienes que haberte registrado en la app con ese correo.
-- =====================================================================

-- 1) Quién es administrador (solo se cambia desde aquí, nunca desde la app)
create table if not exists public.admins (
  user_id uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admins enable row level security;
drop policy if exists "ver admins" on public.admins;
create policy "ver admins" on public.admins for select using (true);

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

-- 2) Ajustes de la app que el admin cambia desde dentro (Beta, anuncio, mentorías, enlaces…)
create table if not exists public.app_config (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.app_config enable row level security;
drop policy if exists "leer ajustes" on public.app_config;
create policy "leer ajustes" on public.app_config for select using (true);
drop policy if exists "admin cambia ajustes" on public.app_config;
create policy "admin cambia ajustes" on public.app_config for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
insert into public.app_config (key, value) values ('app', '{}'::jsonb) on conflict (key) do nothing;

-- 3) Moderación del chat: el admin borra cualquier mensaje y puede bloquear usuarios
drop policy if exists "admin borra mensajes" on public.messages;
create policy "admin borra mensajes" on public.messages for delete to authenticated using (public.is_admin());

create table if not exists public.bans (
  user_id uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.bans enable row level security;
drop policy if exists "ver bloqueos" on public.bans;
create policy "ver bloqueos" on public.bans for select to authenticated using (true);
drop policy if exists "admin bloquea" on public.bans;
create policy "admin bloquea" on public.bans for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
-- un usuario bloqueado no puede escribir en el chat
drop policy if exists "bloqueados no escriben" on public.messages;
create policy "bloqueados no escriben" on public.messages as restrictive for insert to authenticated
  with check (not exists (select 1 from public.bans b where b.user_id = auth.uid()));

-- 4) Permisos
grant select on public.admins, public.app_config to anon, authenticated;
grant insert, update, delete on public.app_config to authenticated;
grant select, insert, delete on public.bans to authenticated;
grant execute on function public.is_admin() to anon, authenticated;

-- 5) TÚ ERES EL ADMIN: cambia el correo por el que usaste al registrarte en la app
insert into public.admins (user_id) select id from auth.users where lower(email) = lower('TU_CORREO@gmail.com') on conflict do nothing;
