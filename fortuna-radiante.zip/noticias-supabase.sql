-- =====================================================================
-- Fortuna Radiante · NOTICIAS FORTUNA (canal de Telegram traducido, con permiso del dueño)
-- Supabase → SQL Editor → New query → pega TODO → Run. Se puede repetir.
-- Necesita haber ejecutado antes fortuna-todo-en-uno.sql y precios-avisos-supabase.sql.
-- =====================================================================
update public.access set sections = sections || '{"noticias": true}'::jsonb
where status = 'aprobado' and not (sections ? 'noticias');

create table if not exists public.news (
  id text primary key,                     -- canal/número de publicación
  channel text not null,
  post_id bigint,
  posted_at timestamptz not null default now(),
  title text,
  body text not null,
  body_orig text,
  topic text not null default 'mercados',
  has_media boolean not null default false,
  link text,
  created_at timestamptz not null default now()
);
create index if not exists news_posted on public.news (posted_at desc);
alter table public.news enable row level security;
drop policy if exists "ver noticias" on public.news;
create policy "ver noticias" on public.news for select to authenticated using (public.has_access('noticias'));
drop policy if exists "admin noticias" on public.news;
create policy "admin noticias" on public.news for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.news to authenticated;

-- cada 10 minutos se llama a la función «noticias» para traer y traducir lo nuevo
create or replace function public.noticias_tick() returns void
language plpgsql security definer set search_path = public as $$
declare u text; tok text;
begin
  select value into u from private.settings where key = 'notify_url';
  select value into tok from private.settings where key = 'notify_token';
  if u is null then return; end if;
  perform net.http_post(url := replace(u, '/functions/v1/notify', '/functions/v1/noticias'), body := '{"source":"cron"}'::jsonb,
                        headers := jsonb_build_object('Content-Type', 'application/json', 'x-notify-token', tok));
end $$;
revoke all on function public.noticias_tick() from public, anon, authenticated;

do $$
begin
  create extension if not exists pg_cron;
  if exists (select 1 from cron.job where jobname = 'noticias-fortuna') then perform cron.unschedule('noticias-fortuna'); end if;
  perform cron.schedule('noticias-fortuna', '*/10 * * * *', 'select public.noticias_tick()');
exception when others then
  raise notice 'No se pudo programar la actualización automática (%). Activa pg_cron en Database → Extensions y vuelve a ejecutar este archivo.', sqlerrm;
end $$;
